
   
//____________________________________________________________________

// Choudhary, Suresh Sujaram (Cognizant)    
fun playWithExperiemntQuery01() {
    var list2 : MutableList<Int> = mutableListOf(1,2,4,5,6) // MutableList<Int>
    list2.add(5)
    println("list2 of int : ${list2}")
    println( list2 )
 
    // Inferred Type Of RHS Is MutableList<String>
    //      But LHS Type Is MutableList<Int>
    //      Hence Type Mismatch Will Happen
    list2 = mutableListOf("hello","jone","jack") // MutableList<String>
    // error: assignment type mismatch: 
    //      actual type is 'MutableList<String>', 
    //      but 'MutableList<Int>' was expected

    println( list2 )

    // Inferred Type Of RHS Is // MutableList<String>
    var list3 : MutableList<String> = mutableListOf("hello","jone","jack") // MutableList<String>
}

//____________________________________________________________________

// Kotlin has the following collections for grouping items:

// Collection Type   Description
// -----------------------------------------------------------------------
// Lists             Ordered collections of items
// Sets              Unique unordered collections of items
// Maps              Sets of key-value pairs where keys are unique and map to only one value

// Each collection type can be mutable or read only.

//____________________________________________________________________

________________________________________________________________________________________

ADD YOUR QUESTIONS AND QUERIES HERE
________________________________________________________________________________________
________________________________________________________________________________________

ADD YOUR QUESTIONS AND QUERIES HERE
________________________________________________________________________________________

01. NAME: Sri Ram Kumar
Date: 05 March, 2026
    Q 01: Is there any memory overflow in Kotlin?    
    Q 02: In class variables are declared. 
We want to access member variables?
            class Person {
                val age: Int
                println( age ) // You can call function like this in Class
            }
    Q 03: Pointer Substraction
            It Can Be Used To Find The Number Of Elements In Array. Please Explain...

    Q 04: Explain Default Constructor/Memberwise Initialiser In Kotlin
            What Compiler Will Generate?

Date: 09 March, 2026
    Q 05:
         How we will return the the combination of string(Sentence) in lambda function

   var lambdaUppercase = { var txt: String -> txt.uppercase() }
   
            val lambdaStr = lambdaUppercase(" ram Kumar Cts")
            println("Uppercase using lambda:  $lambdaStr")

error: too many arguments for 'fun invoke(): Unit'.
            val lambdaStr = lambdaUppercase(" ram Kumar Cts")


02. NAME: Anurag Das 
Date: 05 March, 2026
    Q 01 : mutableMapOf, mutableListOf Function And Using val To Make Immutable
        It looks like contradictory 
        val list : MutableList<String> = mutableListOf("hello","jone","jack")

Date: 09 March, 2026
    Q 01 : Why does Kotlin force me to use ?. or !! or any kind of null check when
 calling a method on something that I know is not null? Ex: like why the following is not compiling: val name: String? = userName()
         Val len = name.length
         //error: only safe (?.) or non-null asserted (!!.) calls are allowed on a         nullable receiver of type String?
val len = name.length 

03. NAME: Debasish Sahoo
Date: 05 March, 2026
    Q 01: Using Lambda In Filter Function
                   When To Declare Data Type In Lambda?

    Q 02: What Happens With Empty String, Empty List, 0, 0.0 etc…
Can We Check bool( Expression ) Like in Python
            Zero Of Type
    Q 03: What is trailing Lambda and 
What is the difference between Normal Lambda and trailing Lambda.

04. NAME: Suresh Sujaram
Date: 05 March, 2026

    Q 01: Do we have the String Pool concept in Kotlin Similar To In Java?
    Q 02: In Kotlin All Types Are Object Type
            In Java Primitive Types Are Stored In Stack and 
Non-Primitive Are Stored In Heap
            How Are These Things In Kotlin?

05. NAME: Asish Baral
Date: 05 March, 2026
Q 01: In Java Class Create Member Variables/Constants
        When You Print Object It Prints Object Reference
            Implement toString() Function 
To Print Member Variables/Constants Values

        In Kotlin How It Is?
Q 02 : It is easy to take user input( like integer , string ) in java , 
How can we do this using kotlin?
Date: 09 March, 2026
    Q 01: In java when we execute code if some exception comes then we can handle that by using try , catch block and throw and throws keyword ,  but in kotlin if the same exception will come how can we handle it , is there any block or keyword to handle it.

06. NAME: Bishal Rawani
Date: 05 March, 2026
    Q 01: How Memory Management Happens In Kotlin?

Date: 09 march 2026
     Q1: what is null safety in kotlin and how it is managed?
 
07. NAME: Sumit Ganesh Dhage
Date: 05 March, 2026
    Q 01: How to Create Threads In Kotlin?
Date: 09 March, 2026
    Q 01: What is the difference between interface and abstract class in kotlin?

08. NAME: Aaron Jain
Date: 05 March, 2026
    Q 01: What are the advantages of using Kotlin over other 
programming languages for android development
Why do we prefer Kotlin?

09. NAME: Atharva Hamdapure
Date: 05 March, 2026
Q 01: If kotlin already has null safety, why does it allow nullable types?

Date: 09 March, 2026
    Q 01: How do we decide whether to use a normal class or data class?

10. NAME: Priyanshu tripathi
Date: 05 March, 2026
Q 01:Is there a singleton class in kotlin?

11. NAME: Naman Raj Purohit
Date: 05 March, 2026

Q 01:in c++ we have a destructor that is called when an object 
is no longer needed. 
Does kotlin have something similar?

Date: 09 March, 2026
      Q 02:Does Kotlin support multiple inheritance ? if not how does
                 kotlin handel?




12. NAME: Sameer Gonde
Date: 05 March, 2026
Q 01:Does Kotlin Have Any Abstract Class Concept?
Date: 09 March, 2026
    Q 02:Which programming languages have the potential to replace Kotlin in the future?

13. NAME: Ranjit Raj Nahak
Date: 05 March, 2026
Q 01: Can a Map having key value pairs(Any, Null) be created?
    Why cannot we add a new pair(String key, Null value) to a Map of (String, Int)?
Date: 09 March, 2026
    Q 01:What are Sealed classes in kotlin and why are they used?

14. NAME: Abhimanyu Giri
Date: 05 March, 2026
    Q 01 : What Kotlin features help reduce android crashes?
    Q 02 : High Order functions in kotlin?

Date: 09 March, 2026 
    Q.3 Is it easy to switch from Android Development to Ios Development.
    Q.4 How does Android manage background services and battery optimization.

15. NAME: S Vishnu Teja
Date: 05 March, 2026
Q 01: In C# we have extension functions concept 
Can Kotlin support the same concept
Date: 09 March, 2026
    Q 01: Is kotlin language a platform independent language like java.

16. NAME: Vidyasagar
Date: 05 March, 2026
Q 01: How are data classes useful in kotlin And 
 When do we have to use data classes?
         How does kotlin implement OOP differently compared to java?

17. NAME: Manjusha Shinde
Date: 05 March, 2026
Q 01: What is null safety in kotlin that java does not have?
      Q 03: Can lambda expressions replace all functions in kotlin ?

18. NAME: Rozina
Date: 05 March, 2026
Q 01: In kotlin how does the compiler internally handle null safety 
and smart casting?
      Q 02 : What is the difference between a lambda function and an anonymous function               in kotlin?

19. NAME: Sumit Kumar Dubey 
Date: 05 March, 2026
Q 01: Does kotlin support call by reference?
If not then why does java and kotlin not support it?
    Q 02:   How memory management in kotlin happens !?

20. NAME: AKSHAT CHANDRAVANSHI
Date: 05 March, 2026
    Q 01: When to use lambda functions over traditional loops ?

21. NAME: Sarthak Ghosle
Date: 05 March, 2026


22. NAME: Nishesh Patil
Date: 09 March, 2026


    Q 01: How does Kotlin handle mutability between MutableList and List?
    Q 02: Why is Array<INT> not the same as IntArray in Kotlin?




________________________________________________________________________________________
________________________________________________________________________________________
________________________________________________________________________________________


//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________

fun main() {
    println("\nFunction: playWithExperiemntQuery01")
    playWithExperiemntQuery01()

    // println("\nFunction: ")
    // println("\nFunction: ")
    // println("\nFunction: ")
    // println("\nFunction: ")
    // println("\nFunction: ")
    // println("\nFunction: ")
    // println("\nFunction: ")
}

//____________________________________________________________________
//____________________________________________________________________

