/*
1. Compiling Kotlin Code
	kotlinc KotlinFundamentals.kt -include-runtime -d fundamentals.ja

2. Running Compiled Code
	java -jar fundamentals.jar
*/

//____________________________________________________________________

// Created Function
//		It Takes No Arguments
//		And Returns Default Unit Value Of Unit Type 
fun helloWorld() {
	println("Hello World!!!")
}

//____________________________________________________________________

fun playWithConstantsAndVariables() {
	// Immutable State
	// Using val Creating Constants
	val price = 50.99
	val customers = 20
	val greeting = "Good Evening!!!"

	println( price )
	println( customers )
	println( greeting )

	// price = 99.99 // error: 'val' cannot be reassigned.
	// println( price )

	// Mutable State
	// Using var Creating Variables
	var priceAgain = 50.99
	var customersAgain = 20
	var greetingAgain = "Good Evening!!!"

	println( priceAgain )
	println( customersAgain )
	println( greetingAgain )

	priceAgain = 99.99
	println( priceAgain )	
}


//____________________________________________________________________


fun playWithStringInterpolation() {
	// Using val Creating Constants
	val price = 50.99
	val customers = 20
	val greeting = "Good Evening!!!"

	// String Interpolation
	//		Values Of Identifiers Can Be Substituted In String
	//		Using $ Symbol
	println( "Price 	: $price" )
	println( "Customer 	: $customers" )
	println( "Greeting 	: $greeting" )

	println( "Increased Price : ${ price + 11.10 }" )
}

//____________________________________________________________________

fun playWithMathematicalAssignmentOperator() {
	var customers = 10

	// Some customers leave the queue
	customers = 8

	customers = customers + 3 // Example of addition: 11
	customers += 7            // Example of addition: 18
	customers -= 3            // Example of subtraction: 15
	customers *= 2            // Example of multiplication: 30
	customers /= 3            // Example of division: 10

	println(customers) // 10
}


//____________________________________________________________________

// BEST PRACTICE
//		Variables/Constant/Objects Must Be Initialised To Valid Values

fun playWithInitialisation() {
	// val d
	// var something
	// error: this variable must either have an explicit type or be initialized.

	// Type Annotation
	// Explicitly Annotating Type Of Identifiers
	val d : Int 
	var something: String

	val d1 = 90
	var something1 = "Good Evening!"

	// println( d ) 		 // error: variable 'd' must be initialized.
	// println( something ) // error: variable 'something' must be initialized.

	d = 99
	something = "Good Good!"
	println( d )
	println( something )		

	println( d1 )
	println( something1 )		
}

//____________________________________________________________________

fun playWithTypeInferrencingAndBinding() {
	// 1. Type Is Inferred From RHS Is Int
	// 2. Inferred Type Is Binded To LHS Is Int
	val something = 99 // 99 Default Type Is Int
	println( something )

	val somethingAgain: Int = 99 // 99 Default Type Is Int
	println( somethingAgain )

	// 1. Type Is Inferred From RHS Is String
	// 2. Inferred Type Is Binded To LHS Is String
	val greeting = "Good Afternoon!"
	println( greeting )

	val greetingAgain : String = "Good Afternoon!"
	println( greetingAgain )

	val marks = 90.99 // 90.99 Default Type Is Double
	println( marks )

	val marksAgain: Double = 90.99 // 90.99 Default Type Is Double
	println( marksAgain )

	// val marks1 : Float = 90.99 // 90.99 Default Type Is Double
	// error: initializer type mismatch: expected 'Float', actual 'Double'.
	val marks1 : Float = 90.99F // 90.99F Type Is Float
	println( marks1 )
}

//____________________________________________________________________

fun playWithListCollections() {
	// Creates Immutable List
	val shapes1 = listOf("Triangle", "Square", "Circle" )
	// val shapes1 : ???? = listOf("Triangle", "Square", "Circle" )
	println( shapes1 )

	val shapes2 : List<String> = listOf("Triangle", "Square", "Circle" )
	println( shapes2 )
	// shapes2.add( "Hexagon" ) // error: unresolved reference 'add'.
	// println( shapes2 )

	// var Creates Immutable ???
	val shapes3 : MutableList<String> = mutableListOf("Triangle", "Square", "Circle" )
 	println( shapes3 )
	shapes3.add( "Hexagon" )
	shapes3.add( "Pentagon" )
	println( shapes3 )

	shapes3.remove( "Circle" )
	println( shapes3 )

	println( "Circle" in shapes1 )
	println( "Circle" in shapes3 )

	println( shapes1.count() )
	println( shapes2.count() )
	println( shapes3.count() )
}

//____________________________________________________________________

fun playWithSetCollections() {
	// Read-only set
	val readOnlyFruit = setOf("apple", "banana", "apple", "cherry", "cherry")
	println(readOnlyFruit)
	// [apple, banana, cherry]
	
	// Mutable set with explicit type declaration
	val fruit: MutableSet<String> = mutableSetOf("apple", "banana", "apple", "cherry", "cherry")
	println( fruit )

	println("This set has ${fruit.count()} items")
	// This set has 3 items

	fruit.add("dragonfruit")    // Add "dragonfruit" to the set
	println(fruit)              // [apple, banana, cherry, dragonfruit]
	println("This set has ${fruit.count()} items")

	fruit.remove("dragonfruit") // Remove "dragonfruit" from the set
	println(fruit) 
	println("This set has ${fruit.count()} items")
}


//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________


fun main() {
	println("\nFunction: helloWorld")
	helloWorld()

	println("\nFunction: playWithConstantsAndVariables")
	playWithConstantsAndVariables()

	println("\nFunction: playWithStringInterpolation")
	playWithStringInterpolation()

	println("\nFunction: playWithMathematicalAssignmentOperator")
	playWithMathematicalAssignmentOperator()

	println("\nFunction: helloWorldAferMain")
	helloWorldAferMain()

	println("\nFunction: playWithInitialisation")
	playWithInitialisation()

	println("\nFunction: playWithTypeInferrencingAndBinding")
	playWithTypeInferrencingAndBinding()

	println("\nFunction: playWithListCollections")
	playWithListCollections()

	println("\nFunction: playWithSetCollections")
	playWithSetCollections()
	
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
}

//____________________________________________________________________

// Function Definition
fun helloWorldAferMain(){
    println("Hello World After Main!!")
}
 
//____________________________________________________________________

