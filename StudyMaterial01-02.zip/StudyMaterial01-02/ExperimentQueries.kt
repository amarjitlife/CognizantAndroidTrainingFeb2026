   
//____________________________________________________________________

// Choudhary, Suresh Sujaram (Cognizant)    
fun playWithExperiemntQuery01() {
    var list2 : MutableList<Int> = mutableListOf(1,2,4,5,6) // MutableList<Int>
    list2.add(5)
    println("list2 of int : ${list2}")
    println( list2 )
 
    list2 = mutableListOf("hello","jone","jack") // MutableList<String>
    // error: assignment type mismatch: actual type is 'MutableList<String>', but 'MutableList<Int>' was expected
    println( list2 )

    var list3 : MutableList<String> = mutableListOf("hello","jone","jack") // MutableList<String>

}


//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________

fun main() {
    println("\nFunction: playWithExperiemntQuery01")
    playWithExperiemntQuery01()

    // println("\nFunction: ")
    // println("\nFunction: ")
    // println("\nFunction: ")
    // println("\nFunction: ")
    // println("\nFunction: ")
    // println("\nFunction: ")
    // println("\nFunction: ")
}

//____________________________________________________________________
//____________________________________________________________________