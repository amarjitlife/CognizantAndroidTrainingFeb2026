_______________________________________________________________________________________

TODAY'S ASSIGNMENTS
DAY 01 + DAY 02 :: 27th February, 2026 + 02nd March, 2026
_______________________________________________________________________________________

	Assignment A1 : Reading, Thinking Assignment
		Chapter 02: Types, Operators And Expressions
		Chapter 05: Pointers and Arrays [ MUST MUST MUST ]
			Read, Understand and Experiment Code In Above Chapters

		Reference : The C Programming Language, 2nd Edition
			By Brian Kernigham and Dennis Ritchie

	Assignment A2 : Code, Practice and Experiment Kotlin Code In Class
		Practice and Experiment Kotlin Code Till Now Done!!

	Assignment A3 : Read, Code, Practice and Experiment Kotlin Code
		Chapter 01: Kotlin What and Why?
			Read, Understand and Experiment Code In Above ChaptersCode

		Reference : 
			1.  Kotlin in Action 2nd Edition
				Sebastian Aigner, Roman Elizarov, Svetlana Isakova, and Dmitry Jemerov
	
_______________________________________________________________________________________

TOMORROWS ASSIGNMENTS
DAY 03 :: 03rd March, 2026
_______________________________________________________________________________________

	Assignment A2 : Code, Practice and Experiment Kotlin Code In Class
		Practice and Experiment Kotlin Code Till Now Done!!

	Assignment A3 : Read, Code, Practice and Experiment Kotlin Code

		Reference : 
			1.  Kotlin in Action 2nd Edition
				Sebastian Aigner, Roman Elizarov, Svetlana Isakova, and Dmitry Jemerov

	Assignment A4 : Code, Practice and Experiment Java Code
		Reference : 
			1. Core Java for the Impatient 26 February 2025 by Cay Horstmann
				Primary Book For Java Language: 
					It Covers Java Concepts Deeply
					It's An Intermediate Level Book

			2. Java: The Complete Reference, 13th Edition 
					by Herbert Schildt (Author), Dr Danny Coward (Author) 
				Seconday Book: This covers Java Syntax with Small Examples

_______________________________________________________________________________________
_______________________________________________________________________________________
_______________________________________________________________________________________
_______________________________________________________________________________________
_______________________________________________________________________________________
_______________________________________________________________________________________
_______________________________________________________________________________________

