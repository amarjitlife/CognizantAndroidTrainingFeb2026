
//____________________________________________________________________
// EXCERCISE :: Write Following Equivalent Code In Java

/*
// Kotlin Code Example

class Customer

class Person( val name: String, val age: Int )

fun playWithClassesAndObjects() {
	// Calling Customer Constructor
	//		This Constructor Takes No Arguments
	val customer = Customer()
	println( customer ) // Printing customer Object

	val person = Person( name = "Gabbar Singh", age = 33 )
	println( person ) 		// Printing person Object
	println( person.name )  // Accessing name Property
	println( person.age ) 	// Accessing age Property 0
}
*/

//____________________________________________________________________

class Customer {
	
}

class Person {
	int id; 						// Mutable Member Variable
	int age;						// Mutable Member Variable
	final String name = "Unknown";  // Immutable Member Variable

	Person( int id, int age ) {
		this.id 	= id;
		this.age  	= age;
	}
}

class Human { 
	String name;
	int age;

	Human( String name, int age ) {
		this.name 	= name;
		this.age  	= age;
	}
}

//____________________________________________________________________
// Creating Singleton Class
//		A Class Whoes Only 1 Instance Can Be Created


// Java program implementing Singleton class
// with using  getInstance() method

// Helper class
class SingletonExample {
	// Static variable reference of single_instance
	// of type Singleton
	private static SingletonExample singletoInstance = null;

	// Declaring a variable of type String
	public String data;

	// Constructor
	// Here we will be creating private constructor
	// restricted to this class itself
	private SingletonExample() { data = "Hello! Singleton";  }

	// Static Method
	//		Class/Type Members
	//			Methods Which Called Using Class Name 
	//			Rather Than Objec/Instance Name
	// Static Method to create instance of Singleton class
	public static synchronized SingletonExample getInstance() {
		if (singletoInstance == null)
			singletoInstance = new SingletonExample(); // Allocate New Object

		return singletoInstance; // Otherwise Return Existing Object
	}
}

//____________________________________________________________________
//____________________________________________________________________


class InstanceAndClassMembersExample {
	// Non-Static Members Are Instance/Object Members
	//		To Be Accessed Using Instance/Object
	//		
	// Instance Member Variable
	//		To Be Accessed Using Instance/Object
	public String instanceMemberVariable = "Instance Member Variable";
	// Instance Member Function
	//		To Be Accessed Using Instance/Object
	public void instanceMemberMethod() {
		System.out.println("Instance Member Method Called...");
	}

	// Static Members Are Class/Type Members
	//		To Be Accessed Using Class/Type

	// Class/Type Member Variable
	//		To Be Accessed Using Class Name
	static public String classMemberVariable = "Class Member Variable";

	// Class/Type Member Function
	//		To Be Accessed Using Class Name
	static public void classMemberMethod() {
		System.out.println("Class Member Method Called...");
	}
}

//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________


public class Experiments {

//____________________________________________________________________

	// In Java/C/C++
	//		All References and Object's Members Are Mutable By Default
	// 		In Java To Make References And/Or Object's Members Immutable Use final Keyword
	//		In C/C++ To Make References And/Or Object's Members Immutable Use const Keyword

	// In Kotlin
	//		Most of Things Are Immutable By Default
	//		Or You Can Make Mutable/Immutable References And/Or Object's Members 
	//			Using var And val Keywords

	public static void playWithCustomerClassAndObject() {
		// In Java
		// Here co Is Not Customer Object
		//		Rather co Is Address/Reference/Pointer To Customer Object Allocated At Heap
		// 			 RHS Customer Object Allocated At Heap
		// LHS co Is Reference/Address/Pointer To Object Of Customer Type
		Customer co = new Customer();
		System.out.println( co );
	}

//____________________________________________________________________

	public static void playWithOnePersonObjectAndTwoReferences() {
		// Here po Is Reference/Pointer To Object Of Person Type With id =101 and age = 33
		Person po = new Person( 101 , 33 );
		
		// Reference/Address/Pointer Assignment Assignment
		//		Note Following Is Not Full Copy Of The Object
		Person poc = po;

		System.out.println( po );
		System.out.println( poc );

		System.out.println( po.id );
		System.out.println( po.age );
		System.out.println( poc.id );
		System.out.println( poc.age );

		poc.age = 44;

		System.out.println( po.id );
		System.out.println( po.age );
		System.out.println( poc.id );
		System.out.println( poc.age );
	}

//____________________________________________________________________

	public static void playWithTwoPersonObjectsAndOneReference() {
		// Here po Is Reference/Pointer To Object Of Person Type With id =101 and age = 33
		Person po = new Person( 101 , 33 ); // RHS 1st Person Object
		System.out.println( po );
		System.out.println( po.id );
		System.out.println( po.age );

		// Here po Is Reference/Pointer To New Object Of Person Type With id =111 and age = 55
		po = new Person( 111 , 55 ); // RHS 2nd Person Object

		// Person po = new Person( 111 , 55 ); // RHS 2nd Person Object
		//		error: variable po is already defined

		System.out.println( po );
		System.out.println( po.id );
		System.out.println( po.age );

		// What Happened To 1st Person Object With id =101 and age = 33
		//		It Will Get Deallocated
	}

//____________________________________________________________________

	public static void playWithTwoPersonObjectsAndTwoReferences() {
		// Here po Is Reference/Pointer To Object Of Person Type With id =101 and age = 33
		Person po = new Person( 101 , 33 ); // RHS 1st Person Object

		// Here pon Is Reference/Pointer To New Object Of Person Type With id =101 and age = 33
		Person pon = new Person( 101 , 33 ); // RHS 2nd Person Object

		// Following Lines Will Print Two Different Addreses/References/Pointers
		System.out.println( po );
		System.out.println( pon );

		System.out.println( po.id );
		System.out.println( po.age );

		System.out.println( pon.id );
		System.out.println( pon.age );
	}

//____________________________________________________________________

	public static void playWithUnderstandingObjectAndReferences() {
		// Person person = new Person( );
		// In Java
		// Here po Is Not Person Object
		//		Rather po Address/Reference/Pointer To Person Object Allocated At Heap
						// Person Object Allocated At Heap
		// In Java Reference/Address/Pointer To Object Of Person Type Is Mutable By Default
		//		Similar To var po = Person( 101, 33 ) In Kotlin
		Person po = new Person( 101 , 33 );
		System.out.println( po );	
		System.out.println( po.id );
		System.out.println( po.age );

		po.id 	= 999;
		po.age 	= 333;

		System.out.println( po.id );
		System.out.println( po.age );

		po = new Person( 111 , 333 );
		System.out.println( po );	
		System.out.println( po.id );
		System.out.println( po.age );
		System.out.println( po.name );
		
		// In Java
		// 		Here pon Is Reference/Address/Pointer To Object Of Person Type 
		//		And To Make It Immutable Use final Keyword
		// In Kotlin 
		//		It's Similar To val pon = Person( 101, 33 )
		final Person pon = new Person( 101 , 33 );
		System.out.println( pon );	
		System.out.println( pon.id );
		System.out.println( pon.age );
		System.out.println( pon.name );

		// pon Reference/Address/Pointer To Object Is Immutable
		// pon = new Person( 111 , 333 ); // error: cannot assign a value to final variable pon

		pon.id 		= 888;
		pon.age 	= 444;
		// pon.name 	= "Gabbar Singh"; // error: cannot assign a value to final variable name

		System.out.println( pon );	
		System.out.println( pon.id );
		System.out.println( pon.age );
		System.out.println( pon.name );
		
		// In Kotlin
		// val Makes Reference/Address/Pointer To Object Of Type Person Is Immutable
		// val po = Person( 101, 33 )

		// var Makes Reference/Address/Pointer To Object Of Type Person Is Mmutable
		// var po = Person( 101, 33 )
		
		/*
		// In C/C++
			Person * p = ( Person * ) malloc( sizeof( Person ) );
			
			// Intialisation Logic
			po -> name = "Gabbar Singh";
			po -> age  = 33;
	
		// In Java new Operator Calls malloc Internally
		//		It Returns Starting Address/Reference/Pointer Of Object Allocated At Heap Memory 
		*/
	}

//____________________________________________________________________

	// In Java/Kotlin
	//		All Objects Are Passed By Reference
	
	public static void doChange( Human hu ) {
		hu.name = "Gabbar Singh";
		hu.age 	= 99;
	}

	public static void doChangeAgain( Human hu ) {
		hu = new Human( "Gabbar Singh Ramgarh", 500000 );
	}

	static void playWithHumanObject() {
		Human h = new Human( "Gabbar", 33 );

		System.out.println( h.name );
		System.out.println( h.age );

		doChange( h );

		System.out.println( h.name );
		System.out.println( h.age );

		doChangeAgain( h );

		System.out.println( h.name );
		System.out.println( h.age );
	}


//____________________________________________________________________
//____________________________________________________________________


	public static void playWithSingletonExample() {
		// Instantiating Singleton class with variable x
		SingletonExample x = SingletonExample.getInstance();

		// Instantiating Singleton class with variable y
		SingletonExample y = SingletonExample.getInstance();

		// Instantiating Singleton class with variable z
		SingletonExample z = SingletonExample.getInstance();

		// Printing the hash code for above variable as
		// declared
		System.out.println("Hashcode of x is "
						   + x.hashCode());
		System.out.println("Hashcode of y is "
						   + y.hashCode());
		System.out.println("Hashcode of z is "
						   + z.hashCode());

		if ( x == y && y == z && x == z ) {
			System.out.println("All References Are Pointing To Same Object");
		} else {
			System.out.println("All References Are Pointing To Different Objects");

		}

		System.out.println( x.data );
		System.out.println( y.data );
		System.out.println( z.data );

		// SingletonExample some = new SingletonExample();
		// error: SingletonExample() has private access in SingletonExample
	}


//____________________________________________________________________
//____________________________________________________________________

	public static void playWithInstanceAndClassMembersExample() {
		
		String value = InstanceAndClassMembersExample.classMemberVariable;
		System.out.println( "Class Member Variable Value: " + value );
		InstanceAndClassMembersExample.classMemberMethod();


		InstanceAndClassMembersExample instance = new InstanceAndClassMembersExample();

		System.out.println( "Instance Member Variable Value: " + instance.instanceMemberVariable );
		instance.instanceMemberMethod();


	}

//____________________________________________________________________
//____________________________________________________________________

	public static void main( String[] args ) {
		System.out.println("\nFunction : playWithCustomerClassAndObject");
		playWithCustomerClassAndObject();

		System.out.println("\nFunction : playWithOnePersonObjectAndTwoReferences");
		playWithOnePersonObjectAndTwoReferences();

		System.out.println("\nFunction : playWithTwoPersonObjectsAndOneReference");
		playWithTwoPersonObjectsAndOneReference();

		System.out.println("\nFunction : playWithTwoPersonObjectsAndTwoReferences");
		playWithTwoPersonObjectsAndTwoReferences();

		System.out.println("\nFunction : playWithUnderstandingObjectAndReferences");
		playWithUnderstandingObjectAndReferences();

		System.out.println("\nFunction : playWithHumanObject");
		playWithHumanObject();

		System.out.println("\nFunction : playWithSingletonExample");
		playWithSingletonExample();

		System.out.println("\nFunction : playWithInstanceAndClassMembersExample");
		playWithInstanceAndClassMembersExample();

		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
	}
}


