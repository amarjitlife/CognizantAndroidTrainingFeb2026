/*
kotlinc 10KotlinClassesAdvanced -include-runtime -d advancedClasses.jar
java -jar advancedClasses.jar
*/

package learnKotlin

import java.util.Comparator
import java.io.File

// ____________________________________________________

// _____________________________________________________
// Experiment Folloiwng Code, Moment Done >>> RAISE HAND!

// Object Classes
// 		Singleton Classes
// 			Singleton Class Having Only One Instance
//		object Classes Are Singleton Classes In Kotlin
// 			Will Define Singleton Named Class
//			Create One Unique Instance of It.
//			You Can Access Unique Instance With Class Name.

// Object Class
//		Class Name Starting With object Keyword
//		This Singleton Class Hence Only 1 Instance Will Exists
//		That Instance Name Will Be Same As Class Name

object SingletonExample {
	var data: String = "Unknown Value"
}

object X {
	var data = 0
}


fun playWithObjectClasses() {
	var value: String = SingletonExample.data

	println("Value Stored In Singleton : $value")

	println( X.data )
	
	SingletonExample.data = "Kotlin Is Great Language!"
	
	X.data = 9000

	value = SingletonExample.data
	println("Value Stored In Singleton : $value")
	println( X.data )

}

// _____________________________________________________
// Implement India Singleton Class In Kotlin


// Singleton Class With Unique Object
//	Object Is Accessed Using Class Name

// India Is A Singleton Class
//		Hence It's Only One Instance Get Created
//		That Instance Name Is India ( ie.. Class Name Itself )
object India {
	var name : String = "India"

	fun getStates() : List<String> {
		return listOf("Karnatka", "Jammu & Kashmir", "Punjab", "Gujrat", "Tamilnadu",
			"Bihar", "Uttar Pradesh", "Maharastra", "Kerala")		
	}

	fun decoratedName() : String {
		return "Country Name : $name"
	}
}

fun playWithIndia() {
	println( India.name )
	
	India.name = "Bharat"
	println( India.name )

	India.name = "Hindustan!"
	println( India.name )

	println( India.getStates())
	println( India.decoratedName())	
}

// ______________________________________________________
// Experiment Folloiwng Code, Moment Done >>> RAISE HAND!

// In Kotlin companion object Members Are 
// 		Similar To static Members In Java

class InstanceAndClassMembersExample {
	// Non-Companion Members Are Instance/Object Members
	//		To Be Accessed Using Instance/Object
	//		
	// Instance Member Variable
	//		To Be Accessed Using Instance/Object
	var instanceMemberVariable = "Instance Member Variable"
	// Instance Member Function
	//		To Be Accessed Using Instance/Object
	fun instanceMemberMethod() {
		println("Instance Member Method Called...")
	}

	// Companion Object Members Are Class/Type Members
	//		To Be Accessed Using Class/Type
	companion object {
		// Class/Type Member Variable
		//		To Be Accessed Using Class Name
		var classMemberVariable = "Class Member Variable"

		// Class/Type Member Function
		//		To Be Accessed Using Class Name
		fun classMemberMethod() {
			println("Class Member Method Called...")
		}
	}
}


fun playWithInstanceAndClassMembersExample() {
	val value = InstanceAndClassMembersExample.classMemberVariable
	println( "Class Member Variable Value: " + value )
	InstanceAndClassMembersExample.classMemberMethod()

	val instance = InstanceAndClassMembersExample()
	println( "Instance Member Variable Value: " + instance.instanceMemberVariable )
	instance.instanceMemberMethod()

}

// ______________________________________________________
// Experiment Folloiwng Code, Moment Done >>> RAISE HAND!

data class Student3(val id: Int, val firstName: String, val lastName: String) {
	val fullName = "$lastName, $firstName"
}

// Singleton Class
object StudentRegistry {
	val allStudents = mutableListOf<Student3>()

	fun addStudent(student: Student3) {
		allStudents.add(student)
	}

	fun removeStudent(student: Student3) {
		allStudents.remove(student)
	}

	fun listAllStudents() {
		allStudents.forEach( { println(it.fullName) } )
	}
}

fun playWithStudentRegistry() {
	val marie 	= Student3(100, "Marie", "Curie")
	val albert 	= Student3(101, "Albert", "Einsein")
	val alice 	= Student3(102, "Alice", "Carol")

	StudentRegistry.addStudent(marie)
	StudentRegistry.addStudent(albert)
	StudentRegistry.addStudent(alice)

	StudentRegistry.listAllStudents()
}


// ______________________________________________________
// Experiment Folloiwng Code, Moment Done >>> RAISE HAND!

// Creating Class/Type Members In Kotlin

// Companions Objects
//		Companions Objects Members Are Class Members
//			i.e. Can Be Accessed Using Enclosing Class/Type

class TypeMember1 {
	// Companion Object Class Name Optional
	//		Companion Will Be Default Class For Companion Object
	companion object {
		fun doMagic() {
			println("Companion Object Member Called... Doing Magic")
		}
	}
} 

class TypeMember2 {
	// Companion Object Class Name Mentioned
	companion object Magician {
		fun doMagic() {
			println("Companion Object Member Called... Doing Magic")
		}
	}
} 

fun playWithCompanionObjects() {

	// Following Two Lines Of Code Are Equivalent
	TypeMember1.doMagic()
	TypeMember1.Companion.doMagic()

	// Following Two Lines Of Code Are Equivalent
	TypeMember2.doMagic()
	// TypeMember2.Companion.doMagic()
	TypeMember2.Magician.doMagic()
}


// ____________________________________________________

// class Client1( val name: String, var postalCode: Int ) {
class Client1( val name: String, val postalCode: Int ) {
	val fullname = name
}

class Client2( val name: String, val postalCode: Int ) {
	val fullname = name
	override fun toString() = "Client1(name=$name, postalCode=$postalCode)"
}

class Client3( val name: String, val postalCode: Int ) {
	val fullname = name
	override fun toString() = "Client1(name=$name, postalCode=$postalCode)"

	override fun equals( other: Any? ) : Boolean {
		if ( other == null || other !is Client1 ) return false
		return name == other.name && postalCode == other.postalCode
	}

	// Best Practice
	// Similary Implement hashCode Method for equal
}

// Data Classes
//		For Classes Compiler Will Generate Following Functions
//		1. toString() Method Code
//		2. equals() Method Code
//		3. hashCode() Method Code
//		4. copy Method Code

data class Client4( val name: String, val postalCode: Int ) {
	val fullName = name
}

fun playWithClients() {
	val gabbar11 = Client1( name = "Gabbar Singh", postalCode = 111111 )	
	val gabbar12 = Client1( name = "Gabbar Singh", postalCode = 111111 )

	println( gabbar11 ) // gabbar.toString()
	println( gabbar12 ) // gabbar.toString()

	println( gabbar11 == gabbar12 )

	val gabbar21 = Client2( name = "Gabbar Singh", postalCode = 111111 )	
	val gabbar22 = Client2( name = "Gabbar Singh", postalCode = 111111 )

	println( gabbar21 ) // gabbar.toString()
	println( gabbar22 ) // gabbar.toString()

	println( gabbar11 == gabbar22 )

	val gabbar31 = Client3( name = "Gabbar Singh", postalCode = 111111 )	
	val gabbar32 = Client3( name = "Gabbar Singh", postalCode = 111111 )

	println( gabbar31 ) // gabbar31..toString()
	println( gabbar32 ) // gabbar32..toString()

	println( gabbar31 == gabbar32 )


	val gabbar41 = Client4( name = "Gabbar Singh", postalCode = 111111 )	
	val gabbar42 = Client4( name = "Gabbar Singh", postalCode = 111111 )

	println( gabbar41 ) // gabbar31..toString()
	println( gabbar42 ) // gabbar32..toString()

	println( gabbar41 == gabbar42 )
}

// ____________________________________________________


// Data Classes
// Compiler Will Generate Following Methods
//		1. Will Generate toString Method With All The Properties In Contructor
//		2. Will Generate equals Method, Comparing All The Properties In Constructor
//		3. Will Generate hashCode Method Also
//		4. Will Generate copy Method To Coyy All The Properties In Constructor

data class Student2(var firstName: String, var lastName: String, var id: Int) {
	// var fullName: String
	// 		get() {
	// 			return "$lastName, $firstName"
	// 		}

	// Following Is Getter Body After Assignment Statement
	// And It's Equivalent To Above Code
	val fullName = "$lastName, $firstName"

	// Overriding toString Method, Hence will be Not Be Generated
	override fun toString() : String {
		println("Student 2 Method Called... : toString")
		return "Student1(firstName=$firstName, lastName=$lastName, id=$id)"
	}
}

fun playWithStudent2Equality() {
	val alice1 = Student2(firstName = "Alice", lastName = "Carols", id = 100)
	val alice2 = Student2(firstName = "Alice", lastName = "Carols", id = 100)

	val johnny = Student2(firstName = "Jonny", lastName = "Jaamil", id = 999)

	println(alice1.fullName)
	println(alice1.toString() ) 
	println(alice2.fullName)
	println(alice2.toString() ) 
	println(johnny.fullName)
	println(johnny.toString()) 

	println( alice1 === alice2 ) 
	println( alice1 == alice2 ) 
	println( alice1 == johnny )
	println( alice2 == johnny )	

}

fun playWithStudent2Copying() {
	val alice1 = Student2(firstName = "Alice", lastName = "Carols", id = 100)
	val alice2 = alice1

	val alice3 = alice1.copy()

	val someone = alice1.copy( lastName = "Someone", id = 200)
	val someoneElse = alice1.copy( lastName = "SomeoneElse", id = 300)
	val someoneElseAgain = alice1.copy( firstName = "Alisha", lastName = "SomeoneElseAgain", id = 400)

	alice2.firstName = "Alonza"
	println(alice1) // Compiler Will Convert To println( alice1.toString() )
	println(alice2) // Compiler Will Convert To println( alice2.toString() )
	println(alice3)
	println(someone)
	println(someoneElse)
	println(someoneElseAgain)

	println( alice1 == alice2 )  
	println( alice1 === alice2 ) // Equality of References 
	println( alice1 == alice3 ) 
	println( alice1 === alice3 ) // Equality of References
	println( alice1 == someone )
	println( alice1 === someone ) // Equality of References
	println( alice1 == someoneElse ) // alice1.equals( someoneElse )
	println( alice1 === someoneElse ) // Equality of References
}


//_____________________________________________________________

// import java.util.Comparator
// import java.io.File

data class Human(val firstName: String, val middleName: String, val lastName: String )

// Creating Singleton Class For CaseInsenstiveComparison Login On File Type Data
//		We Will Use This As Criteria For Sorting In Sorting Function
object CaseInsensitiveFileComparator : Comparator<File> {
	override fun compare( file1: File, file2: File ) : Int {
		return file1.path.compareTo( file2.path, ignoreCase = true )
	}
}

object CaseInsensitiveHumanFirstnameComparator : Comparator<Human> {
	override fun compare( h1: Human, h2: Human ) : Int {
		return h1.firstName.compareTo( h2.firstName, ignoreCase = true )
	}
}

object CaseInsensitiveHumanMiddlenameComparator : Comparator<Human> {
	override fun compare( h1: Human, h2: Human ) : Int {
		return h1.middleName.compareTo( h2.middleName, ignoreCase = true )
	}
}

object CaseInsensitiveHumanLastnameComparator : Comparator<Human> {
	override fun compare( h1: Human, h2: Human ) : Int {
		return h1.lastName.compareTo( h2.lastName, ignoreCase = true )
	}
}

fun playWithObjectClassesAgain() {
	println( CaseInsensitiveFileComparator.compare(
		File("/User"), File("/user")) )

	// What Will Be files Type?
	val files : List<File> = listOf( File("/User"), File("/user") )
	//		We Are Using CaseInsensitiveFileComparator As Criteria For Sorting In Sorting Function
	//						   Comparision Criteria We Are Passing To sortedWith Function
	println( files.sortedWith( CaseInsensitiveFileComparator ) )

	val humans = listOf( 
			Human("Gabbar", "", "Singh"), Human("Veeru", "", ""), 
			Human("Narendra", "Damodar", "Modi"), Human("Alice", "Micheal", "Carol"),
			Human("Abhimanyu", "Arjun", "Giri"), Human("Ranjit", "Raj", "Nahak"),
			Human("Sumit", "Kumar", "Dubey") 
		)

	println("\nHuman In List Order...")
	println( humans )

	// sortedWith Function Configured With Criteria Of Sorting
	println("\nHuman In Sorted Order : Based On firstName...")
	println( humans.sortedWith( CaseInsensitiveHumanFirstnameComparator ) )

	println("\nHuman In Sorted Order : Based On middleName...")
	println( humans.sortedWith( CaseInsensitiveHumanMiddlenameComparator ) )

	println("\nHuman In Sorted Order : Based On lastName...")
	println( humans.sortedWith( CaseInsensitiveHumanLastnameComparator ) )
}


//_____________________________________________________________


data class Person( val name: String ) {

	// Change Code To Sort With firstName
	object NameComparator : Comparator<Person> {
		override fun compare( person1: Person, person2: Person ) : Int {
			return person1.name.compareTo( person2.name )
		}
	}

	// Change Code To Sort With middleName

	// Change Code To Sort With lastName
}

fun playWithObjectClassesOnceAgain() {
	val persons = listOf( Person("Bob"), Person("Gabbar"), Person("Alice") )
	println( persons.sortedWith( Person.NameComparator ) )
}


//_____________________________________________________________


fun getFacebookName( accountID: Int ) = "FB:$accountID"

// Making Contructor Private Means
//		Limiting The Object Creation Ways

// Making Constructor Private
//		Such That No One Should Be Able To Use Constructors To Make Objects
//		But You Need Object To Make Class Usable
//		Hence Need Mechanism To Create Objects
//			For That We Provide Special Methods Whose Role To Create Only Objects
// 			And Such Methods Becomes Class/Type Member and These Methods Are Called Factory Method
//				In Java 	: Use static To Make Class/Type Member
//				In Kotlin 	: Use companion object To Make Class/Type Member

class UserAgain private constructor( val nickname: String ) {

	companion object {
		// Factory Methods: To Create Object With Given/Passed Configuration
		fun newSubscribingUser( email: String ) : UserAgain {
			return UserAgain( email.substringBefore('@') )
		}

		fun newFacebookUser( accountID: Int ) : UserAgain {
			return  UserAgain( getFacebookName( accountID ) )
		}
	}
}

fun playWithCompanionObjectsAgain() {
	val subscribingUser = UserAgain.newSubscribingUser("gabbar@gmail.com")
	val facebookUser = UserAgain.newFacebookUser(420)

	println( subscribingUser.nickname )
	println( facebookUser.nickname )
}



//_____________________________________________________________
// DESIGN PRINCIPLE
//      Design Towards Determinism Rather Than Non Determinism
//      Avoid Writing Contextual Code

enum class Color {
	RED, GREEN, BLUE, ORANGE
}

// when Is Type Safe Expression
fun getMnemonic(color: Color) = when (color) {
		Color.RED       -> "Red Color"
		Color.GREEN     -> "Green Color"
 		Color.BLUE      -> "Blue Color"
		Color.ORANGE    -> "Orange Color"
		// else         -> "Uknown Color"
		//     error: 'when' expression must be exhaustive. 
		//			Add the 'BLUE' branch or an 'else' branch.
}

fun playWithColors() {
	println( getMnemonic( Color.RED ) )
	println( getMnemonic( Color.GREEN ) )   
	println( getMnemonic( Color.BLUE ) )    
}


//_____________________________________________________________
// DESIGN PRINCIPLE
//      Exceptions Are Not Exceptional Such That It Breaks Your Design

interface Expr
class Num(val value: Int) : Expr
class Sum(val left: Expr, val right: Expr) : Expr
// class Sub(val left: Expr, val right: Expr) : Expr

fun evaluate(e: Expr): Int = when (e) {
	is Num  ->  e.value
	is Sum  ->  evaluate(e.right) + evaluate(e.left)
	// error: 'when' expression must be exhaustive. Add an 'else' branch.
	else    ->  throw IllegalArgumentException("Unknown expression")
	// is Expr -> 99
}

fun playWithEvaluate() {
	println("\nFunction: evalWhen")
	println( evaluate(Sum(Num(1), Num(2))))    
}

// ____________________________________________________

// Sealed Classes
//		You Can Inherit Classes Within Same File!
//		In Another File You Can't Do Inheritance

// Limited Inheritance Diagram

sealed class Expr1 {
	class Num(val value: Int) : Expr1()
	class Sum(val left: Expr1, val right: Expr1) : Expr1()
}

fun evaluateAgain(e: Expr1): Int = when (e) {
	is Expr1.Num  ->    e.value
	is Expr1.Sum  ->    evaluateAgain(e.right) + evaluateAgain(e.left)
	// error: 'when' expression must be exhaustive. Add an 'else' branch.
	// else     ->  throw IllegalArgumentException("Unknown expression")
}

fun playWithEvaluateAgain() {
	println("\nFunction: evaluateAgain")
	println( evaluateAgain( Expr1.Sum( Expr1.Num(1), Expr1.Num(2)) ) )    
}

// ____________________________________________________
// ____________________________________________________
// ____________________________________________________
// ____________________________________________________
// ____________________________________________________
// Experiment Following Code and THAN RAISE YOUR HAND!!


fun main() {
	println("\nFunction : playWithObjectClasses")
	playWithObjectClasses()

	println("\nFunction : playWithIndia")
	playWithIndia()

	println("\nFunction : playWithInstanceAndClassMembersExample")
	playWithInstanceAndClassMembersExample()

	println("\nFunction : playWithStudentRegistry")
	playWithStudentRegistry()

	println("\nFunction : playWithCompanionObjects")
	playWithCompanionObjects()

	println("\nFunction : playWithClients")
	playWithClients()

	println("\nFunction : playWithStudent2Equality")
	playWithStudent2Equality()

	println("\nFunction : playWithStudent2Copying")
	playWithStudent2Copying()

	println("\nFunction : playWithObjectClassesAgain")
	playWithObjectClassesAgain()

	println("\nFunction : playWithObjectClassesOnceAgain")
	playWithObjectClassesOnceAgain()

	println("\nFunction : playWithCompanionObjectsAgain")
	playWithCompanionObjectsAgain()

	println("\nFunction : playWithColors")
	playWithColors()

	println("\nFunction : playWithEvaluate")
	playWithEvaluate()

	println("\nFunction : playWithEvaluateAgain")
	playWithEvaluateAgain()

	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
}


