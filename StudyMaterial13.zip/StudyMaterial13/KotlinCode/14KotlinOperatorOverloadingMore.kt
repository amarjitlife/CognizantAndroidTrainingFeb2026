
package learnKotlin

class Company(val name: String) {

    private val departments: ArrayList<Department> = arrayListOf()

    val allEmployees: List<Employee>
        get() = arrayListOf<Employee>().apply {
            departments.forEach { addAll(it.employees) }
            sort()
        }

    operator fun plusAssign(department: Department) {
        departments.add(department)
    }

    operator fun minusAssign(department: Department) {
        departments.remove(department)
    }
}

class Department(val name: String) : Iterable<Employee> {

    val employees: ArrayList<Employee> = arrayListOf()

    operator fun plusAssign(employee: Employee) {
        employees.add(employee)
        println("${employee.name} hired to $name department")
    }

    operator fun minusAssign(employee: Employee) {
        if (employees.contains(employee)) {
            employees.remove(employee)
            println("${employee.name} fired from $name department")
        }
    }

    fun add(newEmployees: List<Employee>) {
        employees.addAll(newEmployees)
    }

    operator fun get(index: Int): Employee? { // [0]
        return if (index < employees.size) {
            employees[index]
        } else {
            null
        }
    }

    operator fun set(index: Int, employee: Employee) { // [0] = EmployeeObject
        if (index < employees.size) {
            employees[index] = employee
        }
    }

    operator fun contains(employee: Employee) = employees.contains(employee)

    override fun iterator() = employees.iterator()
}

data class Employee(val company: Company, val name: String, var salary: Int) : Comparable<Employee> {

    operator fun plusAssign(increaseSalary: Int) {
        salary += increaseSalary
        println("$name got a raise to $$salary")
    }

    operator fun minusAssign(decreaseSalary: Int) {
        salary -= decreaseSalary
        println("$name's salary decreased to $$salary")
    }

    operator fun plus(employee: Employee): List<Employee> {
        return listOf(this, employee)
    }

    operator fun dec(): Employee {
        salary -= 5000
        println("$name's salary decreased to $$salary")
        return this
    }

    operator fun inc(): Employee {
        salary += 5000
        println("$name got a raise to $$salary")
        return this
    }

    operator fun rangeTo(other: Employee): List<Employee> {
        val currentIndex = company.allEmployees.indexOf(this)
        val otherIndex = company.allEmployees.indexOf(other)

        if (currentIndex >= otherIndex) {
            return emptyList()
        }

        return company.allEmployees.slice(currentIndex..otherIndex)
    }

    override operator fun compareTo(other: Employee): Int {
        return when (other) {
            this -> 0
            else -> name.compareTo(other.name)
        }
    }
}

fun main() {
    // your company
    val company = Company("MyOwnCompany")

    // departments
    val developmentDepartment = Department("Development")
    val qaDepartment = Department("Quality Assurance")
    val hrDepartment = Department("Human Resources")

    // employees
    var Julia = Employee(company, "Julia", 100_000)
    var John = Employee(company, "John", 86_000)
    var Peter = Employee(company, "Peter", 100_000)

    var Sandra = Employee(company, "Sandra", 75_000)
    var Thomas = Employee(company, "Thomas", 73_000)
    var Alice = Employee(company, "Alice", 70_000)

    var Bernadette = Employee(company, "Bernadette", 66_000)
    var Mark = Employee(company, "Mark", 66_000)

    company += developmentDepartment // company.plusAssign( developmentDepartment )
    company += qaDepartment          // company.plusAssign( qaDepartment )
    company += hrDepartment          // company.plusAssign( hrDepartment )

    developmentDepartment += Julia   // developmentDepartment.plusAssign( Julia )
    developmentDepartment += John    // developmentDepartment.plusAssign( John )
    developmentDepartment += Peter   // developmentDepartment.plusAssign( Peter )

    qaDepartment += Sandra           // qaDepartment.plusAssign( Sandra )
    qaDepartment += Thomas           // qaDepartment.plusAssign( Thomas )   
    qaDepartment += Alice            // qaDepartment.plusAssign( Alice )

    hrDepartment += Bernadette       // hrDepartment.plusAssign( Bernadette )
    hrDepartment += Mark             // hrDepartment.plusAssign( Mark )

    qaDepartment -= Thomas           // qaDepartment.plusAssign( Thomas )

    if (Thomas !in qaDepartment) {   // !(qaDeparment.contains( Thomas) )
        println("${Thomas.name} no longer works here")
    }

    ++Julia         // Julia.inc()
    --Peter         // Peter.dec()
    Mark += 2500    // Mark.plusAssign( 2500 )
    Alice -= 2000   // Alice.plusAssign( 2000 )

    print(  (Alice..Mark).joinToString { it.name }   )
}

