
/*
kotlinc KotlinNullability.kt -include-runtime -d nullability.jar
java -jar nullability.jar
*/

package learnKotlin

// _____________________________________________________
// Experiment Folloiwng Code, Moment Done RAISE HAND!

fun playWithNullabilityAndNonNullability() {
	
	// String, Int, Float, Double etc... Are NON NULLABLE Types
	//		i.e. You CAN'T Assign null Value To These Types Variables
	var name: String = "Alice Carol"
	var age: Int = 30
	var occupation: String = "Software Engineer"

	println("$name $age $occupation")
	name = "Alice Carol Mcmillan"
	age = 40
	age = age + 1
	occupation = "Sr. Software Engineer"
	println("$name $age $occupation")	

	// Following 3 Lines Of Code Will Give Compilation Error
	// name = null  		// error: null can not be a value of a non-null type String
	// age = null 	 		// error: null can not be a value of a non-null type Int
	// occupation = null 	// error: null can not be a value of a non-null type String

	// Nullabe Types Are Also Called Optional Types
	// String?, Int?, Float?, Double? etc... Are NULLABLE Types
	//		i.e. You CAN Assign null Value To These Types Variables
	var name1: String? = "Alice Carol"
	var age1: Int? = 30
	var occupation1: String? = "Software Engineer"

	println("$name1 $age1 $occupation1")
	name1 = "Alice Carol Mcmillan"
	age1 = 40
	age1 = age1 + 1
	occupation1 = "Sr. Software Engineer"
	println("$name1 $age1 $occupation1")	

	name1 = null  		
	age1 = null 	 	
	occupation1 = null 	
	println("$name1 $age1 $occupation1")
}

// _____________________________________________________
// Experiment Folloiwng Code, Moment Done RAISE HAND!

fun playWithNullabilityAndNonNullabilityAgain() {
	var authorName: String? = "Joe Howard"
    var authorAge: Int? = 24

    println(authorName)
    println(authorAge)

    // error: operator call corresponds to a dot-qualified call 
    // 'authorAge.plus(1)' which is not allowed on a nullable receiver 'authorAge'.
    // val ageAfterBirthday = authorAge + 1 	// authorAge.plus(1)

    // error: only safe (?.) or 
    // non-null asserted (!!.) calls are allowed on a 
    // nullable receiver of type Int?
    
    // ?. is Safe Calls Operator

    val ageAfterBirthday0 = authorAge?.plus(1)
    println("After their next birthday, author will be $ageAfterBirthday0")

    // !! Not Recommended,  It's Used In Rarest Rare Scenarios 
    val ageAfterBirthday1 = authorAge!! + 1    
    println("After their next birthday, author will be $ageAfterBirthday1")

	authorAge = null
    println("After two birthdays, author will be $authorAge")
    // val ageAfterBirthday2 = authorAge!! + 1    

	var nonNullableAuthor: String = ""
    var nullableAuthor: String? = ""

    if (authorName != null) {
        nonNullableAuthor = authorName
    } else {
        nullableAuthor = authorName
    }

    println(nonNullableAuthor)
    println(nullableAuthor)

    // Nullable Types Members Cann't Be Accessed Using . Operator
    //		Use ?. or !! Operator

	// error: only safe (?.) or non-null asserted (!!.) calls are allowed 
	// on a nullable receiver of type String?
    // var nameLength = authorName.length
 
    // ?. is Safe Calls Operator
    var nameLength = authorName?.length
    // Above Line Of Code Is Equvalent To Following Line Of Code
    // 		if (authorName != null) authorName else null
    println("Author's name has length $nameLength.")

    val nameLengthPlus5 = authorName?.length?.plus(5)
    println("Author's name length plus 5 is $nameLengthPlus5.")
}

// _____________________________________________________
// Experiment Folloiwng Code, Moment Done RAISE HAND!

fun playWithElvisOperator() {	
	var something: String? = "Good Morning!"
	println(something)
	// something = null
	// println(something)

	// Coding Style 1
	// Nullable Types Data Must Accessed After Checking For null Value
	if (something != null ) {
		val upperValue = something.uppercase()
		println("$upperValue")
	} else {
		println("It Contains >>> Null Value...")
	}

	// Coding Style 2 
	val upperSomething0 = if (something != null) something else "" 
	
	// Coding Style 3 Using Elvis Operator 
	// ?: is Called Elvis Operator
	//		Default Values Written After This
	val upperSomething1 = something ?: "" // ?: DEAFULT VALUE
	// Above Line Of Code Is Equivalent To if (something != null) something else "" 

	println( upperSomething0.uppercase() )
	println( upperSomething1.uppercase() )

	var nullableValue: Int? = 10
	
	var mustHaveValue0 = if (nullableValue != null) nullableValue else 0
	println(mustHaveValue0)
	//	Above Two Lines and Below Two Lines Of Code Are Eqivalent
	var mustHaveValue1  = nullableValue ?: 0
	println(mustHaveValue1)

	nullableValue = null
	mustHaveValue0 = nullableValue ?: 0
	println(mustHaveValue0)
}

// _____________________________________________________
// _____________________________________________________
// _____________________________________________________
// _____________________________________________________

fun main() {
	println("\nFunction : playWithNullabilityAndNonNullability")
	playWithNullabilityAndNonNullability()

	println("\nFunction : playWithNullabilityAndNonNullabilityAgain")
	playWithNullabilityAndNonNullabilityAgain()

	println("\nFunction : playWithElvisOperator")
	playWithElvisOperator()

	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
}
