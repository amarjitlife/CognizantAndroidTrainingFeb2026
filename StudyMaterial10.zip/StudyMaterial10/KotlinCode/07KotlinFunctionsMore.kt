//____________________________________________________________________

/**** Run Following Commands
kotlinc 07KotlinFunctionsMore.kt -include-runtime -d functions.jar
java -jar functions.jar
****/

//____________________________________________________________________

package learnKotlin


//____________________________________________________________________

// Using Function Overloading
//		To Write Multiple Function Just Changing Type
fun printValue(value: String) {
	println("Value: $value")
}

fun printValue(value: Int) {
	println("Value: $value")
}

fun printValue(value: Double) {
	println("Value: $value")
}

fun playWithPrintValue() {
	printValue( "Gabbar Singh" )
	printValue( 99 )
	printValue( 99.99 )
}

//____________________________________________________________________

// Generics
//		A Code Template Used By Compiler To Generate Code

// Generic Function
//	 Here T is Type Placeholder OR Type Parameter
//		Specified In <> e.g. <T>
//	 T Will Be Substituted With Type At Compile Time
//		And Compiler Will Generate Code After Substiting T

fun <T> printValue(value: T) {
	println("Value: $value")
}

fun playWithPrintValueAgain() {
	// Based On Usage
	// Compiler Will Infer Type Of Argument As String
	//		At Compile Time
	//	T Type Placeholder 
	//		Will Be Substituted With String	And Corresponding FunctionCode Generated
	printValue( "Gabbar Singh" ) 

	// Compiler Will Infer Type Of Argument As Int
	//		At Compile Time
	//	T Type Placeholder 
	//		Will Be Substituted With Int And Corresponding FunctionCode Generated
	printValue( 99 )

	// Compiler Will Infer Type Of Argument As Double
	//		At Compile Time
	//	T Type Placeholder 
	//		Will Be Substituted With Double	And Corresponding FunctionCode Generated
	printValue( 99.99 )

	// Compiler Will Infer Type Of Argument As Double
	//		At Compile Time
	//	T Type Placeholder 
	//		Will Be Substituted With Float And Corresponding FunctionCode Generated
	printValue( 99.99F )

	printValue( 'A' )
}

//____________________________________________________________________
// Generic Function
// 	With Multiple K And V Type Placeholder
//		Specified In <> e.g. <K, V>
//	 K, V Will Be Substituted With Type At Compile Time
//		And Compiler Will Generate Code After Substiting K And V

fun <K, V> createMap(key: K, value: V): Map<K, V> {
	return mapOf(key to value)
}

fun playWithCreateMapGenericFunction() {
	val map1 = createMap( 99, "Good" )
	val map2 = createMap( "greeting", "Good Morning!!!" )
	val map3 = createMap( "temperator", 37.9 )

	println( map1 )
	println( map2 )
	println( map3 )	
}

//____________________________________________________________________
// MOMENT DONE FOLLOWING CODE, RAISE YOUR HANDS!!!

// Created Human Class/Type with Three Instance Properties
//		firstName, lastName and fullName Are Instance Properties (Immutable)
class Human(val firstName: String, val lastName: String) {
	val fullName = "$firstName $lastName"

	// Instance Member Function
	fun doMagic() = println("Human Doing Magic...")

	// Instance Member Function
	fun doSinging() { println("Human Doing Singing...") } 
}

// Extension Function On Type Human
fun Human.doSomething() {
	println("doSomething Extension Function On Type Human")
}

// Extension Function On Type Human
fun Human.doDance() {
	println("doDance Extension Function On Type Human")
}

fun playWithHumanExtensionFunctions() {
	// Created human Object Of Human Type
	val human = Human("Alice", "Carols")

	// Accessing Properties i.e. Properties Getters Getting Called
	println(human.firstName) 
	println(human.lastName)
	println(human.fullName)

	// Invoking Instance Member Function
	human.doMagic()
	human.doSinging()

	// Invoking Extension Functions Like Instance Member Function
	human.doSomething()
	human.doDance()
}

//____________________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

fun lastChar(string : String) : Char {
	return string.get( string.length - 1 )
}

// Extension Function
//		Are Written Using ClassName Dot Followed By functionName
//			fun ClassName.functionName() { /*Function Body*/ }
//		Extension Functions Are Accessed Using Object Of Class
//		Extension Functions Behave Like Member Functions
//		lastCharacter Is Extention Function Over Class/Type String

// Adding Extension Function In Existing String Class/Type
fun String.lastCharacter() : Char {
	return this.get( this.length - 1 )
}

fun playWithExtensionFunction() {
	println( lastChar("Hello World!") )
	println( lastChar("House No: #420") )

	// Extension Functions Are Accessed Using Object Of Class
	println( "Hello World!".lastCharacter() )
	println( "House No: #420".lastCharacter() )
}

//____________________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

// T Is Type Placeholder
fun <T> joinToString(
	collection : Collection<T>,
	seperator: String = ", ", 	// Parameter With Default Value
	prefix: String = "", 		// Parameter With Default Value
	postfix: String = "" 		// Parameter With Default Value
) : String {

	// Using StringBuilder To Create String Buffer Object
	//		String Buffer Object Is Used To Modfiy The String
	//			Here We Are Appending String Object In The String Buffer
	val result = StringBuilder( prefix )

	for ( (index, element) in collection.withIndex() ) {
		if ( index > 0 ) result.append( seperator )
		result.append( element )
	}

	result.append( postfix )
	// Getting String Object From String Buffer Object 
	return result.toString()
}

fun playWithJoinToString() {
	val names = listOf("Ding", "Dong", "Ting", "Tong")
	println( joinToString( names ))
	println( joinToString( names, " : " ))
	println( joinToString( names, " : ", " >>>> " ))
	println( joinToString( names, " # ", " >>> ", " <<< " ))
	println( joinToString( names, " ## ", " [ ", " ] " ))

	val numbers = listOf(10, 20, 30, 40, 50)
	println( joinToString( numbers ))
	println( joinToString( numbers, " : " ))
	println( joinToString( numbers, " : ", " >>>> " ))
	println( joinToString( numbers, " # ", " >>> ", " <<< " ))
	println( joinToString( numbers, " ## ", " [ ", " ] " ))
}

//____________________________________________________________________

// Extension Function On Collection<T>
//		It Can Access Collection<T> Members Using this

// T Is Type Placeholder
fun <T> Collection<T>.joinToStringExtension(
	seperator: String = ", ", 	// Parameter With Default Value
	prefix: String = "", 		// Parameter With Default Value
	postfix: String = "" 		// Parameter With Default Value
) : String {

	// Using StringBuilder To Create String Buffer Object
	//		String Buffer Object Is Used To Modfiy, Append The String
	//			Here We Are Appending String Object In The String Buffer
	val result = StringBuilder( prefix )

	for ( (index, element) in this.withIndex() ) {
		if ( index > 0 ) result.append( seperator )
		result.append( element )
	}

	result.append( postfix )
	// Getting String Object From String Buffer Object 
	return result.toString()
}

fun playWithJoinToStringExtensionFunction() {
	val names = listOf("Ding", "Dong", "Ting", "Tong")
	println( names.joinToStringExtension( ))
	println( names.joinToStringExtension( " : " ))
	println( names.joinToStringExtension( " : ", " >>>> " ))
	println( names.joinToStringExtension( " # ", " >>> ", " <<< " ))
	println( names.joinToStringExtension( " ## ", " [ ", " ] " ))

	val numbers = listOf(10, 20, 30, 40, 50)
	println( numbers.joinToStringExtension( ))
	println( numbers.joinToStringExtension( " : " ))
	println( numbers.joinToStringExtension( " : ", " >>>> " ))
	println( numbers.joinToStringExtension( " # ", " >>> ", " <<< " ))
	println( numbers.joinToStringExtension( " ## ", " [ ", " ] " ))
}

//____________________________________________________________________

fun Collection<String>.join(
		separator: String = ", ",
		prefix: String = "",
		postfix: String = ""
) = joinToStringExtension(separator, prefix, postfix)


fun playWithBetterJoinExtension() {
	val names = listOf("Ding", "Dong", "Ting", "Tong")
	println( names.join() )
	println( names.join( " : " ) )
	println( names.join( " : ", " >>>> " ))
	println( names.join( " # ", " >>> ", " <<< " ))
	println( names.join( " ## ", " [ ", " ] " ))
}

//____________________________________________________________________

fun parsePath(path: String) {
	val directory = path.substringBeforeLast("/")
	val fullName = path.substringAfterLast("/")

	val fileName = fullName.substringBeforeLast(".")
	val extension = fullName.substringAfterLast(".")

	println("Dir: $directory, name: $fileName, ext: $extension")
}

fun multilineTriplequotedStrings() {
	val kotlinLogo = """
						.| //
						.|//
						.|\\
					 """

	println(kotlinLogo.trimMargin("."))
}

fun playWithStringFunctions() {
	parsePath("/Users/yole/kotlin-book/chapter.adoc")
	multilineTriplequotedStrings()
}

// Write Code To Experiment With Few More String Build In Functions In Kotlin
// 		https://kotlinlang.org/docs/strings.html
// 		https://www.geeksforgeeks.org/kotlin/kotlin-string/
//		https://medium.com/@nachare.reena8/kotlin-strings-c4ccae7642c7
// 		https://www.baeldung.com/kotlin/string-extension-functions

//____________________________________________________________________


class User(val id: Int, val name: String, val address: String)

// Design 01 : Good
fun saveUser( user: User ) {
	// Validation
	if (user.name.isEmpty()) {
		throw IllegalArgumentException(
			"Can't save user ${user.id}: empty Name")
	}

	if (user.address.isEmpty()) {
		throw IllegalArgumentException(
			"Can't save user ${user.id}: empty Address")
	}

	// Save user to the database
	println("Saving User : ${ user.id }  ${ user.name } ...")
}

fun functionValidateUser() {
	saveUser( User(420, "Gabbar Singh", "Ramgarh") )
}

//____________________________________________________________________

// class User(val id: Int, val name: String, val address: String)

// Design 02 : Better
fun saveUserWithLocalValidationFunction(user: User) {
	// Local Function
	//		Function Defined Inside Function
	fun validate(user: User, value: String, fieldName: String) {
		if (value.isEmpty()) {
			throw IllegalArgumentException("Can't save user ${user.id}: Empty $fieldName")
		}
	}

	validate(user, user.name, "Name")
	validate(user, user.address, "Address")

	// Save user to the database
	println("Saving User : ${ user.id }  ${ user.name } ...")
}

fun functionValidateUserLocal() {
//    saveUser(User(1, "", ""))
	saveUserWithLocalValidationFunction(User(101, "Ram", "Rahim"))
}

//____________________________________________________________________

// Design 03 : Best
// save() Is Extension Function On User Class/Type

fun User.save() {
	// Local Function
	//		Function Defined Inside Function
	fun validate(value: String, fieldName: String) {
		if (value.isEmpty()) {
			throw IllegalArgumentException(
			   "Can't save user $id: empty $fieldName")
		}
	}

	validate(name, "Name")
	validate(address, "Address")

	println("Saving User : ${ this.id }  ${ this.name } ...")
}

fun functionSaveUserLocalExtension(user: User) {
	user.save()
	// Save user to the database
}

fun functionValidateUserLocalExtension() {
//    saveUser(User(1, "", ""))
	functionSaveUserLocalExtension( User(101, "Ram", "Rahim") )
}

//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________


fun main() {
	println("\nFunction: playWithPrintValue")
	playWithPrintValue()

	println("\nFunction: playWithPrintValueAgain")
	playWithPrintValueAgain()

	println("\nFunction: playWithCreateMapGenericFunction")
	playWithCreateMapGenericFunction()

	println("\nFunction: playWithHumanExtensionFunctions")
	playWithHumanExtensionFunctions()
	
	println("\nFunction: playWithExtensionFunction")
	playWithExtensionFunction()

	println("\nFunction: playWithJoinToString")
	playWithJoinToString()

	println("\nFunction: playWithJoinToStringExtensionFunction")
	playWithJoinToStringExtensionFunction()

	println("\nFunction: playWithBetterJoinExtension")
	playWithBetterJoinExtension()

	println("\nFunction: playWithStringFunctions")
	playWithStringFunctions()

	println("\nFunction: functionValidateUser")
	functionValidateUser()

	println("\nFunction: functionValidateUserLocal")
	functionValidateUserLocal()

	println("\nFunction: functionValidateUserLocalExtension")
	functionValidateUserLocalExtension()

	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
}

//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________


