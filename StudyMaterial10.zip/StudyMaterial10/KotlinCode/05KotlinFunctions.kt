
//____________________________________________________________________

/**** Run Following Commands
kotlinc 05KotlinFunctions.kt -include-runtime -d functions.jar
java -jar functions.jar
****/

//____________________________________________________________________

package learnKotlin


//____________________________________________________________________


fun playWithKotlinCollections() {
	val set 	= hashSetOf(1, 7, 53) 
	val list 	= arrayListOf(1, 7, 53) 
	val map 	= hashMapOf(1 to "one", 7 to "seven", 53 to "fifty-three")

    println( set.javaClass)
    println( list.javaClass)
    println( map.javaClass)

    val strings = listOf("first", "second", "fourteenth")
    println( map.javaClass)
    println(strings.last())
    val numbers = setOf(1, 14, 2)
    println(numbers.javaClass)

    //println(numbers.max())
    println(numbers.maxOrNull())

	val shapes1 = listOf("Triangle", "Square", "Circle" )
	println( shapes1 )
	println( shapes1.javaClass )

	val shapes2 : MutableList<String> = mutableListOf("Triangle", "Square", "Circle" )
	println( shapes2 )
	println( shapes2.javaClass )

	val readOnlyFruit = setOf("apple", "banana", "apple", "cherry", "cherry")
	println(readOnlyFruit)
	println(readOnlyFruit.javaClass)
	
	val fruit: MutableSet<String> = mutableSetOf("apple", "banana", "apple", "cherry", "cherry")
	println( fruit )
	println( fruit.javaClass )

	val readOnlyJuiceMenu = mapOf("apple" to 100, "kiwi" to 190, "orange" to 100)
	println( readOnlyJuiceMenu )
	println( readOnlyJuiceMenu.javaClass )

	val juiceMenu: MutableMap<String, Int> = mutableMapOf("apple" to 100, "kiwi" to 190, "orange" to 100)
	println( juiceMenu )
	println( juiceMenu.javaClass )
}


//____________________________________________________________________
// MOMENT DONE FOLLOWING CODE, RAISE YOUR HANDS!!!


// Function Taking 1 Argument And Returning Unit
fun printMultipleOfFive(value: Int) {
	val fiveMultiple = value * 5
	println(" $value * 5 = $fiveMultiple" )
}

// Function Taking 2 Argument And Returning Unit
fun printMultipleOf(value: Int, multiplier: Int) {
	val result = value * multiplier

	println(" $value * $multiplier = $result ")
}

// Function Taking 2 Argument And Returning Unit
// 		and 2nd Argument multiplier Have Default Value
//		Default Argument Are Optional In Function Call
fun printMultipleOfDefaultValue( value: Int, multiplier: Int = 1 ) {
	val result = value * multiplier

	println(" $value * $multiplier = $result ")
}

fun playWithFunctionArguments() {
	printMultipleOfFive(10)

	// Function Calling With Named Argument Syntax
	printMultipleOf(value = 10, multiplier = 8)

	// Function Calling With Named Argument Syntax
	//		Passing Both Argumnets Values
	printMultipleOfDefaultValue(value = 10, multiplier = 8)

	// Function Calling With Named Argument Syntax
	//		Passing 1 Argumnet Value
	//		mutliplier Argument Default Value Will Be Taken
	printMultipleOfDefaultValue(value = 10)
}

// Function : playWithFunctionArguments
//  10 * 5 = 50
//  10 * 8 = 80 
//  10 * 8 = 80 
//  10 * 1 = 10 


//____________________________________________________________________

// MOMENT DONE FOLLOWING CODE, RAISE YOUR HANDS!!!


// Following Functions multiply and multiplyInferred are same
fun multiply(number: Int, multiplier: Int): Int {
    return number * multiplier
}

// Return Type of Following Function Is Inferred From RHS Expression Type
// number and mutliplier is Int Type and product will also be of Int Type
// Hence return type of function will be Int
fun multiplyInferred0(number: Int, multiplier: Int) = number * multiplier

// Explicitly Specified Return Type Int
fun multiplyInferred1(number: Int, multiplier: Int): Int = number * multiplier

fun multiplyAndDivide(number: Int, factor: Int) : Pair<Int, Int> {
    return Pair(number * factor, number / factor )
}

fun playWithFunctionReturnValues() {
	var result: Int

	result = multiply(4, 2)
	println(result)

	result = multiplyInferred0(4, 2)
	println(result)
	result = multiplyInferred1(4, 2)
	println(result)

	val resultAgain = multiplyAndDivide(9, 2)
	println("Result : $resultAgain")

	val (product, quotient) = multiplyAndDivide(14, 3)
	println("Product : $product, Quotient: $quotient")
}


//____________________________________________________________________

// MOMENT DONE FOLLOWING CODE, RAISE YOUR HANDS!!!

// By Default Function Arguments Are val i.e. Immutable 
fun incrementValue(value: Int) : Int {
	//value = value + 1 // error: val cannot be reassigned
	
	val newValue = value + 1
	return newValue
}

fun playWithIncrementValueFunction() {
	var value = 80
	
	println(value)
	value = incrementValue( value )
	println(value)
}


//____________________________________________________________________
// MOMENT DONE FOLLOWING CODE, RAISE YOUR HANDS!!!

// FUNCTION OVERLOADING
//		Functions With Same Name
//		Having Different Arguments Type and/or Different Numbers Of Arguments

// Overloaded Based On Type Of Arguments
fun getValue(value: Int) : Int {
	return value + 1
}

fun getValue(value: String) : String {
	return "You Said " + value
}

fun getValue(value: Int, secondValue: Int) : Int {
	return value + secondValue
}

fun playWithOverloadedGetValueFunctions() {
	val valueInt : Int 		 = getValue(900)
	val valueString : String = getValue("Good Morning!")

	println(valueInt)
	println(valueString)

	val value = getValue( 100, 300 )
	println(value)		
}


//____________________________________________________________________
// Overloaded Based On Number Of Arguments

fun add(a: Int, b: Int) : Int {
	return a + b
}

fun add(a: Int, b: Int, c: Int) : Int {
	return a + b + c
}

fun playWithOverloadedSumFunctions() {
	var result : Int

	result = add(100, 200)
	println("Sum : $result")

	result = add(100, 200, 400)
	println("Sum : $result")
}


//____________________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

fun lastChar(string : String) : Char {
	return string.get( string.length - 1 )
}

// Extension Function
//		Are Written Using ClassName Dot Followed By functionName
//			fun ClassName.functionName() { /*Function Body*/ }
//		Extension Functions Are Accessed Using Object Of Class
//		Extension Functions Behave Like Member Functions
//		lastCharacter Is Extention Function Over Class/Type String
fun String.lastCharacter() : Char {
	return this.get( this.length - 1 )
}

fun playWithLastChar() {
	println( lastChar("Hello World!") )
	println( lastChar("House No: #420") )

	// Extension Functions Are Accessed Using Object Of Class
	println( "Hello World!".lastCharacter() )
	println( "House No: #420".lastCharacter() )
}

//____________________________________________________________________

// Function Type
//		(Int, Int) -> Int
fun addFunction(a: Int, b: Int) : Int {
	return a + b
}

// Function Type
//		(Int, Int) -> Int
fun subFunction(a: Int, b: Int) : Int {
	return a - b
}

// addFunction And subFunction Are Objects Of Function Type (Int, Int) -> Int

fun playWithFunctionReferences() {
	val xx: Int = 100
	val yy: Int = 200

	var result: Int

	result = addFunction(xx, yy)
	println("Result : $result")

	result = subFunction(xx, yy)
	println("Result : $result")

	// :: Used For Getting Function Reference/Address
	// 		::addFunction Is Reference/Address Of addFunction
	//		::addFunction Refers To Starting Address Function
	// var operation : Int = ::addFunction 
	// error: initializer type mismatch: 
	//		expected 'Int', actual 'KFunction2<Int, Int, Int>'.

	var operation : (Int, Int) -> Int = ::addFunction 
	result = operation(xx, yy)
	println("Result : $result")

	// ::subFunction Is Reference/Address Of subFunction
	//		::subFunction Refers To Starting Address Function
	operation = ::subFunction
	result = operation(xx, yy)
	println("Result : $result")
}

//____________________________________________________________________

// Int Function Type
//		Return Type Is Specified Followed By ->

// Function Defintion
//	Return Type Is Specified At The End The Function Signature
//		Followed By :

// Function Type
//		(Int, Int) -> Int
fun addition(a: Int, b: Int) : Int {
	return a + b
}

// Function Type
//		(Int, Int) -> Int
fun substraction(a: Int, b: Int) : Int {
	return a - b
}

fun multiplication(a: Int, b: Int) = a * b

// Higher Order Function
//		Function Which Can Take Function As Argument
//		And/Or
//		Function Which Can Return Function 

// fun calculator( a: Int, b: Int, operation: (Int, Int) -> Int ) {
// 			error: return type mismatch: expected 'Unit', actual 'Int'

// Function Type
//		(Int, Int, (Int, Int) -> Int ) -> Int
fun calculator( a: Int, b: Int, operation: (Int, Int) -> Int ) : Int {
	return operation( a, b )
}

fun playWithCalculator() {
	val xx: Int = 500
	val yy: Int = 200

	var result: Int

	// ::addition, ::substraction, ::multiplication
	//		Are Reference/Pointer To Function addition
	result = calculator(xx, yy, ::addition )
	println("Result : $result")

	result = calculator(xx, yy, ::substraction )
	println("Result : $result")

	result = calculator(xx, yy, ::multiplication )
	println("Result : $result")

	// What Is The Type Of something?
	// val something : Int = ::calculator
	// error: initializer type mismatch: 
	//		expected 'Int', actual 'KFunction3<Int, Int, Function2<Int, Int, Int>, Int>'

	val something : (Int, Int, (Int, Int) -> Int ) -> Int = ::calculator
	result = something(xx, yy, ::addition )
	println("Result : $result")
}

//____________________________________________________________________


//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________


fun main() {
	println("\nFunction: playWithKotlinCollections")
	playWithKotlinCollections()

	println("\nFunction: playWithLastChar")
	playWithLastChar()

	println("\nFunction: ")
	playWithFunctionArguments()

	println("\nFunction: playWithFunctionReturnValues")
	playWithFunctionReturnValues()

	println("\nFunction: playWithIncrementValueFunction")
	playWithIncrementValueFunction()

	println("\nFunction: playWithOverloadedGetValueFunctions")
	playWithOverloadedGetValueFunctions()

	println("\nFunction: playWithOverloadedSumFunctions")
	playWithOverloadedSumFunctions()

	println("\nFunction: playWithFunctionReferences")
	playWithFunctionReferences()

	println("\nFunction: playWithCalculator")
	playWithCalculator()

	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
}

//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________


