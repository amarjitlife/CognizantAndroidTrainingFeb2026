
//____________________________________________________________________

/**** Run Following Commands
kotlinc 05KotlinFunctions.kt -include-runtime -d functions.jar
java -jar functions.jar
****/

//____________________________________________________________________

package learnKotlin


//____________________________________________________________________


//____________________________________________________________________

// Int Function Type
//		Return Type Is Specified Followed By ->

// Function Defintion
//	Return Type Is Specified At The End The Function Signature
//		Followed By :

// Function Type
//		(Int, Int) -> Int
fun addition(a: Int, b: Int) : Int {
	return a + b
}

// Function Type
//		(Int, Int) -> Int
fun substraction(a: Int, b: Int) : Int {
	return a - b
}

fun multiplication(a: Int, b: Int) = a * b

// Higher Order Function
//		Function Which Can Take Function As Argument
//		And/Or
//		Function Which Can Return Function 

// fun calculator( a: Int, b: Int, operation: (Int, Int) -> Int ) {
// 			error: return type mismatch: expected 'Unit', actual 'Int'

// Function Type
//		(Int, Int, (Int, Int) -> Int ) -> Int
fun calculator( a: Int, b: Int, operation: (Int, Int) -> Int ) : Int {
	return operation( a, b )
}

fun playWithCalculator() {
	val xx: Int = 500
	val yy: Int = 200

	var result: Int

	// ::addition, ::substraction, ::multiplication
	//		Are Reference/Pointer To Function addition
	result = calculator(xx, yy, ::addition )
	println("Result : $result")

	result = calculator(xx, yy, ::substraction )
	println("Result : $result")

	result = calculator(xx, yy, ::multiplication )
	println("Result : $result")

	// What Is The Type Of something?
	// val something : Int = ::calculator
	// error: initializer type mismatch: 
	//		expected 'Int', actual 'KFunction3<Int, Int, Function2<Int, Int, Int>, Int>'

	val something : (Int, Int, (Int, Int) -> Int ) -> Int = ::calculator
	result = something(xx, yy, ::addition )
	println("Result : $result")

	// plus Is Member Function Of Int Type
	//	Int::plus Will Reference Of plus Member Function Of Int Type
	result = calculator(xx, yy, Int::plus )
	println("Result : $result")
}

//____________________________________________________________________


fun playWithCalculatorAgain() {
	val a = 40
	val b = 20
	var result: Int

	// Lambda Expression
	// error: type mismatch: inferred type is (Int, Int) -> Int 
	// but Int was expected 
	// val sumLambda: Int = { x: Int, y: Int -> x + y }

	val sumLambda1  = { x: Int, y: Int -> x + y }
	result = calculator(a, b, sumLambda1)
	println("Result : $result")

	val sumLambda2 : (Int, Int) -> Int = { x: Int, y: Int -> x + y }
	result = calculator(a, b, sumLambda2)
	println("Result : $result")

	val subLambda = { x: Int, y: Int -> x - y }
	result = calculator(a, b, subLambda)
	println("Result : $result")

	result = calculator(a, b, { x: Int, y: Int -> x + y })
	println("Result : $result")

	result = calculator(a, b, { x: Int, y: Int -> x - y })
	println("Result : $result")

	val sumLambda3 : (Int, Int, Int) -> Int = { x: Int, y: Int, z: Int -> x + y + z }
	result = sumLambda3( 10, 20, 30 )
	println("Result : $result")

	val sumLambda4 : (Int, Int, Int) -> Int = { x, y, z -> x + y + z }
	result = sumLambda4( 10, 20, 30 )
	println("Result : $result")

	val sumLambda5 = { x: Int, y: Int, z: Int -> x + y + z }
	result = sumLambda5( 10, 20, 30 )
	println("Result : $result")
}


//____________________________________________________________________

class Person( val name: String, val age: Int )

fun playWithLambdas() {
	// What Is Type Of something
	val something: () -> Unit = { println(42) }
	something()

	val persons = listOf( Person("Alice", 20), Person("Gabbar", 35), 
		Person("Basanti", 24), Person("Veeru", 27), Person("Jay", 25) )

	val names = persons.joinToString( separator = " ", 
						transform = { person: Person -> person.name } 
					)
	println(names)

	val ages = persons.joinToString( separator = " ", 
						transform = { person: Person -> person.age.toString() } 
					)
	println(ages)

	var lambdaResult: Int
	var multiplyLambda : (Int, Int) -> Int

	val multiplyLambda0 = { a: Int, b: Int -> a * b }
	lambdaResult = multiplyLambda0( 10, 20 )
	println( lambdaResult )

	multiplyLambda = { a: Int, b: Int -> Int
		a * b
	}

	lambdaResult = multiplyLambda( 10, 20 )
	println( lambdaResult )

	multiplyLambda = { a, b -> 
		a * b
	}

	lambdaResult = multiplyLambda( 10, 20 )
	println( lambdaResult )

	var doubleLamda = { a: Int -> a * 2 }
	lambdaResult = doubleLamda( 25 )
	println( lambdaResult )

	// When Lambda Expression Takes Only One Argument
	//		For That Argument You Can Use it
	doubleLamda = { it * 2 }
	lambdaResult = doubleLamda( 25 )
	println( lambdaResult )

	val square1 = { number : Int -> number * number }
	lambdaResult = square1( 25 )
	println( lambdaResult )

	// val square2 = { it * it }
	val square2: (Int) -> Int = { it * it }
	lambdaResult = square2( 25 )
	println( lambdaResult )
}

//____________________________________________________________________

fun playWithLambdasAgain() {
	var result : Int

	// Higher Order Functions
	//		Function Which Takes Function Argument
	fun operate(a: Int, b: Int, operation: (Int, Int) -> Int): Int {
		val result = operation(a, b)
		return result
	}

	val addLambda = { a: Int, b: Int -> a + b }
	result = operate( 40, 20, operation = addLambda )
	println( result )

	fun addFunction(a: Int, b: Int) = a + b
	result = operate( 40, 20, operation = ::addFunction )
	println( result )	

	result = operate( 40, 20, operation = Int::plus )
	println( result )	

	result = operate( 40, 20, operation = { a: Int, b: Int -> a + b } )
	println( result )	

	result = operate( 40, 20, 
		operation = { a: Int, b: Int -> 
			a + b 
		} 
	)
	println( result )	

	result = operate( 40, 20, 
		operation = { a, b -> 
			a + b 
		} 
	)
	println( result )	

	result = operate( 40, 20, operation = { a, b -> a + b } )
	println( result )	

	result = operate( 40, 20, { a, b -> a + b } )
	println( result )	

	// Trailing Lambda
	result = operate( 40, 20 ) { a, b -> a + b } 
	println( result )	
			 // operate Logic

	result = operate( 40, 20 ) { // Extended Logic 
		a, b -> a + b 
	} 
	println( result )
}


//____________________________________________________________________

fun printMessageWithPrefix( messages: Collection<String>, prefix: String ) {
	// Following All Three Are Equivalent
	messages.forEach ( {
		println("$prefix $it")
	} )

	// Trailing Lambda Syntax
	messages.forEach() {
		println("$prefix $it")
	}

	// Trailing Lambda Syntax Without Parameter Paratheses
	messages.forEach {
		println("$prefix $it")
	}
}

fun playWithPrintMessages() {
	val errors = listOf("404 Not Found", "403 Forbidden")
	printMessageWithPrefix( errors, "Error: ")
}

//____________________________________________________________________

fun chooseSteps(backward: Boolean) : (Int) -> Int {
	// Function Type
	//		(Int) -> Int	
	fun moveForward(start: Int) : Int { return start + 1 }
	fun moveBackward(start: Int): Int { return start - 1 }

	return if ( backward ) ::moveBackward else ::moveForward
}

fun playWithChooseStepFunction() {
	// What Will Be Type Of something ???
	// Following Both Lines Are Equivalent
	val something1 = chooseSteps( backward = true )
	val something2 : (Int) -> Int = chooseSteps( backward = true )

	// What Will Be Type Of somethingAgain ???
	// Following Both Lines Are Equivalent
	val somethingAgain1 = something1( 99 )
	val somethingAgain2 : Int = something1( 99 )

	// What Will Be Type Of somethingMore ???
	// Following Both Lines Are Equivalent
	val somethingMore1 = ::chooseSteps
	val somethingMore2 : (Boolean) -> (Int) -> Int = ::chooseSteps

	// What Will Be Type Of somethingOnceMore ???
	// Following Both Lines Are Equivalent
	val somethingOnceMore1 = somethingMore1( false )
	val somethingOnceMore2 : (Int) -> Int = somethingMore1( false )
}


//____________________________________________________________________

fun playWithLambdasOnceAgain() {
	// What Will Be Type Of something?
	//				  Defining Lambda 			         // Calling Lambda Passing Parameters
	// Following Both Lines Are Equivalent
	val something1 = { a: String, b: String -> "$a $b" } ("Gabbar Singh", "Thakur") 
	val something2 : String = { a: String, b: String -> "$a $b" } ("Gabbar Singh", "Thakur") 

	println( something1 )
	println( something2 )

	// Following Both Lines Are Equivalent
	val somethingAgain1 = { a: String, b: String -> "$a $b" }
	val somethingAgain2 : (String, String) -> String = { a: String, b: String -> "$a $b" }

	println( somethingAgain1 )
	println( somethingAgain2 )

	// scenario-1
	val multiplyLambda1 = { a : Int , b: Int ->  
	    a * b
	}
 
	// scenario-2
	val multiplyLambda2 = { a : Int , b: Int -> Int
		 a * b 
	}

	// val multiplyLambda3 = { a : Int , b: Int -> Int a * b }
	val multiplyLambda3 = { a : Int , b: Int -> a * b }
}
 

//____________________________________________________________________


// fun operate( a : Int, b: Int, operation: (Int,Int) -> Int ) : Int {
//     val result = operation(a,b)
//     return result
// }
 
//     val addLambda = { a : Int , b: Int -> a+b}
//     result = operate( a = 10, b = 20, operation = addLambda )
//     println(result)
 
//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________


fun main() {
	println("\nFunction: playWithCalculator")
	playWithCalculator()
	
	println("\nFunction: playWithCalculatorAgain")
	playWithCalculatorAgain()

	println("\nFunction: playWithLambdas")
	playWithLambdas()

	println("\nFunction: playWithLambdasAgain")
	playWithLambdasAgain()

	println("\nFunction: playWithPrintMessages")
	playWithPrintMessages()

	println("\nFunction: playWithChooseStepFunction")
	playWithChooseStepFunction()
	
	println("\nFunction: playWithLambdasOnceAgain")
	playWithLambdasOnceAgain()

	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
}

//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________

