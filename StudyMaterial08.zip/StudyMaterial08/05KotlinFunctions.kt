
//____________________________________________________________________

/**** Run Following Commands
kotlinc 05KotlinFunctions.kt -include-runtime -d functions.jar
java -jar functions.jar
****/

//____________________________________________________________________

package learnKotlin


//____________________________________________________________________


fun playWithKotlinCollections() {
	val set 	= hashSetOf(1, 7, 53) 
	val list 	= arrayListOf(1, 7, 53) 
	val map 	= hashMapOf(1 to "one", 7 to "seven", 53 to "fifty-three")

    println( set.javaClass)
    println( list.javaClass)
    println( map.javaClass)

    val strings = listOf("first", "second", "fourteenth")
    println( map.javaClass)
    println(strings.last())
    val numbers = setOf(1, 14, 2)
    println(numbers.javaClass)

    //println(numbers.max())
    println(numbers.maxOrNull())

	val shapes1 = listOf("Triangle", "Square", "Circle" )
	println( shapes1 )
	println( shapes1.javaClass )

	val shapes2 : MutableList<String> = mutableListOf("Triangle", "Square", "Circle" )
	println( shapes2 )
	println( shapes2.javaClass )

	val readOnlyFruit = setOf("apple", "banana", "apple", "cherry", "cherry")
	println(readOnlyFruit)
	println(readOnlyFruit.javaClass)
	
	val fruit: MutableSet<String> = mutableSetOf("apple", "banana", "apple", "cherry", "cherry")
	println( fruit )
	println( fruit.javaClass )

	val readOnlyJuiceMenu = mapOf("apple" to 100, "kiwi" to 190, "orange" to 100)
	println( readOnlyJuiceMenu )
	println( readOnlyJuiceMenu.javaClass )

	val juiceMenu: MutableMap<String, Int> = mutableMapOf("apple" to 100, "kiwi" to 190, "orange" to 100)
	println( juiceMenu )
	println( juiceMenu.javaClass )
}

//____________________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

fun lastChar(string : String) : Char {
	return string.get( string.length - 1 )
}

// Extension Function
//		Are Written Using ClassName Dot Followed By functionName
//			fun ClassName.functionName() { /*Function Body*/ }
//		Extension Functions Are Accessed Using Object Of Class
//		Extension Functions Behave Like Member Functions
//		lastCharacter Is Extention Function Over Class/Type String
fun String.lastCharacter() : Char {
	return this.get( this.length - 1 )
}

fun playWithLastChar() {
	println( lastChar("Hello World!") )
	println( lastChar("House No: #420") )

	// Extension Functions Are Accessed Using Object Of Class
	println( "Hello World!".lastCharacter() )
	println( "House No: #420".lastCharacter() )
}

//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________

fun main() {
	println("\nFunction: playWithKotlinCollections")
	playWithKotlinCollections()

	println("\nFunction: playWithLastChar")
	playWithLastChar()

	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
}

//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________


