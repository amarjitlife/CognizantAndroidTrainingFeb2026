/*
kotlinc 10KotlinClassesAdvancedMore.kt -include-runtime -d advancedClasses.jar
java -jar advancedClasses.jar
*/

package learnKotlin

// _____________________________________________________
// Experiment Following Code, Moment Done >>> RAISE HAND!

// Class Defined Inside A Class
// 		In Kotlin
// 				Class Defined Inside A Class
//				By Default This Is Nested Class
// 				Nested Class CANN'T Access Properties Defined In Outer Class/Context 

// 		In Java
// 				Class Defined Inside A Class
//				By Default This Is Inner Class
// 				Inner Class CAN Also Access Properties Defined In Outer Class/Context 

// 		In Java
// 				Class Defined Inside A Class
//				To Make Class Nested Use static Keywork Before Class Name

//		In Kotlin
//			To Make Class Defined Inside A Class Inner Class 
//				Mark It With inner Keyword
// 				Inner Class CAN ALSO Access Properties Defined In Outer Class/Context 

// Nested Classes
//      Define Class Inside A Class
//          By Default Inside Class Is Nested Class
//      CANNOT Assess Outer Class Context In Inside Inner Class
class Car1(val carName: String) { // Outer Class
	val steering: Int = 0
	 // Car1 Have Two Property carName And steering
	 // and It's Defined In Outer Class Car1

	// Definining Class Inside Class     
	// 		In Kotlin By Default This Is Nested Class
	 class Engine(val engineName: String) { // Nested Class 
		// Engine Have One Property engineName and 
		// It's Defined In Engine Nested Class/Context 
		// Properties/Functions Defined Inside Class Can Be Accessed With In The Class
		// Nested Class CANNOT Access Properties Defined In Outer Class/Context   
		override fun toString(): String {
			// Can't Access Data From Outer Class
			// error: unresolved reference: carName
			// error: unresolved reference: steering
			// return "$engineName in a $carName have Steering Value: $steering"
			return "$engineName"
		}
	}
}

// Inner Classes
//      Define Class Inside A Class
//          By Default Inside Class Is Inner Class
//      CAN Assess Outer Class Members In Inside Inner Class
class Car2(val carName: String) { // Outer Class
	val steering: Int = 0
	 // Car2 Have Two Property carName And steering
	 // and It's Defined In Outer Class Car2

	// Definining Class Inside Class     
	// 		In Kotlin By Default This Is Nested Class
	//		To Make Inner Class Mark It With inner Keyword
	// 		Inner Class CAN ALSO Access Properties Defined In Outer Class/Context 
	 inner class Engine(val engineName: String) { // Inner Class 
		// Engine Have One Property engineName and 
		// It's Defined In Engine Inner Class/Context 
		// Properties/Functions Defined Inside Class Can Be Accessed With In The Class
		// Inner Class CAN ALSO Access Properties Defined In Outer Class/Context   
		override fun toString(): String {
			// CAN Access Data From Outer Class
			return "$engineName in a $carName have Steering Value: $steering"
		}
	}
}

fun playWithNestedAndInnerClasses() {
	val mazda1 = Car1("mazda")
	// To Access Nested Class Use Outer Class with Dot Operator
	val mazdaEngine1 = Car1.Engine("rotary")
	println(mazdaEngine1) // > rotary engine in a mazda

	val mazda = Car2("mazda")
	// To Access Innser Class Use Outer Class Object with Dot Operator
	val mazdaEngine = mazda.Engine("rotary")
	println(mazdaEngine) // > rotary engine in a mazda
}


//_______________________________________________________

// Interfaces Focus Is To Tell 
//		What To Do
interface Superpower {
	fun fly()
	fun saveWorld()
}

// Concrete lasses Focus Is To Tell 
//		How, When, Where, Which, Why To Do
class Spiderman : Superpower {	
	override fun fly() 		 { println("Fly Like Spiderman!") }
	override fun saveWorld() { println("SaveWorld Like Spiderman!") }	
}

class Superman: Superpower {
	override fun fly() 		 { println("Fly Like Superman!") }
	override fun saveWorld() { println("SaveWorld Like Superman!") }	
}

class Heman : Superpower {
	override fun fly() 		 { println("Fly Like Heman!") }
	override fun saveWorld() { println("SaveWorld Like Heman!") }	
}

//-------------------------------------------------------

// Here Human Is Delegator
class Human {
	// power Is Delegate
	var delegate: Superpower? = null 		
	fun fly() 		 { delegate?.fly()  	  /* if ( power != null ) power.fly() */ 		}
	fun saveWorld()  { delegate?.saveWorld()  /* if ( power != null ) power.saveWorld() */ 	}
}

fun playWithHuman() {
	val h = Human()
	h.delegate = Spiderman()
	h.fly()
	h.saveWorld()

	h.delegate = Superman()
	h.fly()
	h.saveWorld()

	h.delegate = Heman()
	h.fly()
	h.saveWorld()
}

//_______________________________________________________

// Delegation
// by Is Followed By Delegate
// Delegator Delegates The Work To Delegate
//		Here HumanAgain Is Delegator		
//		Here power Act As Delegate
//		Actual Work Will Be Done By Delegate i.e. power

// HumanAgain Is Delegator							  by Keyword Followed By Delegate
class HumanAgain( delegate: Superpower = Spiderman() ) : Superpower by delegate {
	// Compiler Will Generate Following Code 
	// val delegate: Superpower = Spiderman()
	// fun fly() 		 { delegate.fly() } 
	// fun saveWorld()   { delegate.saveWorld() } 
}


fun playWithHumanAgain() {
	println("\nHumanAgain :: Delegate Work To delegate Property")
	val hn1 = HumanAgain( Spiderman() )
	hn1.fly()
	hn1.saveWorld()

	val hn2 = HumanAgain( Superman() )
	hn2.fly()
	hn2.saveWorld()

	val hn3 = HumanAgain( Heman() )
	hn3.fly()
	hn3.saveWorld()
}

//_______________________________________________________
// import java.util.HashSet

// Delegation Patten
//		by Keyword Followed By Delegate
class CountingSet<T>( val innerSet: MutableCollection<T> = HashSet<T>() ) 
	: MutableCollection<T> by innerSet {

	var objectsCount = 0

	// Custom Methods Defintions Provided By Programmer
	//		Hence Compiler Will Not Generate It
	override fun add(element: T): Boolean {
		objectsCount++
		return innerSet.add(element)
	}

	// Custom Methods Defintions Provided By Programmer
	//		Hence Compiler Will Not Generate It
	override fun addAll(elements: Collection<T>): Boolean {
		objectsCount += elements.size
		return innerSet.addAll(elements)
	}

	// Rest All Methods Supported By MutableCollection 
	//		Compiler Wil Generate Corresponding Wrapper Methods
	//			And Internally Call Through Delegate innerSet
	//				i.e. innerSet.<MethodName>()

	// By Default Compiler Will Generate Following Logic For remove And removeAll Function
	// override fun remove(element: T): Boolean {
	// 		return innerSet.remove(element)
	// }

	// override fun removeAll(element: T): Boolean {
	// 		return innerSet.removeAll(element)
	// }

	// Custom Methods Defintions Provided By Programmer
	//		Hence Compiler Will Not Generate It
	// override fun remove(element: T): Boolean {
	// 		objectsCount--
	// 		return innerSet.remove(element)
	// }

	// Custom Methods Defintions Provided By Programmer
	//		Hence Compiler Will Not Generate It
	// override fun removeAll(elements: Collection<T>): Boolean {
	// 		objectsCount -= elements.size
	// 		return innerSet.removeAll(elements)
	// }

	override fun toString() =  innerSet.joinToString()
}


fun classDelegationUsingTheByKeyword() {
	val countingSet = CountingSet<Int>()
	println( countingSet )

	countingSet.addAll(listOf(10, 20, 22, 40, 55))
	println("Object Count :: ${countingSet.objectsCount}")
	println( countingSet )

	var result = countingSet.contains( 55 )
	println("Contains 55 : $result")
	result = countingSet.contains( 66 )
	println("Contains 66 : $result")

	countingSet.remove( 22 )
	println("Object Count :: ${countingSet.objectsCount}")
	println( countingSet )

	countingSet.removeAll( listOf( 40, 10 ) )
	println("Object Count :: ${countingSet.objectsCount}")
	println( countingSet )
}


// ____________________________________________________

class LateInitExample {
	// error: property must be initialized or be abstract
	// var some: String 

	var some: String = "" 

	// It Will Be Initialised Later To Value
	// 		Because I We Don't Know Value Right Now
	lateinit var tutorialName : String

	fun initializeTutorialName(){
		println( this::tutorialName.isInitialized )
		
		// initializing String Value To lateinit Varaible
		tutorialName = "Android Course"

		println( this::tutorialName.isInitialized )
		println( tutorialName )
	}

	override fun toString() = "LateInitExample(some=$some, tutorialName=$tutorialName)"
}

fun playWithLateInitExample() {
	val something = LateInitExample()
	// println( something.tutorialName )
	// Exception in thread "main" kotlin.UninitializedPropertyAccessException: 
	//	lateinit property tutorialName has not been initialized

	something.initializeTutorialName();
	println( something.tutorialName )

}

//_____________________________________________________

data class Email(val from: String, val to: String, val title: String)

fun loadEmails( name: String ) : List<Email> {
	println("Loading Emails Of : $name")
	val emails = listOf( 
		Email("gabbar@gmail.com", "samba@gmail.com", "Kitna Enam Rakhe Hai Sarkar!"),
		Email("gabbar@gmail.com", "samba@gmail.com", "Kya Kiya Jayee!"),
		Email("gabbar@gmail.com", "thakur@gmail.com", "Ye Haat Mujhe Dede Thakur!"),	
		Email("gabbar@gmail.com", "kalia@gmail.com", "Kitne Aadmi Thee"),		
	)
	return emails
}

// -------------------------------------------------------------

class PersonLazy1(val name: String) {
	private var _emails: List<Email>? = null
	// private var _emails: List<Email>? = loadEmails(name)

	// Lazily Loading emails Property
	//		At emails Property Access Time 
	val emails: List<Email>
		get() { // Custom Getter
			// Lazy Pattern : Lazily Loading
			//		Load Emails Only When Used
			if ( _emails == null ) { 
				_emails = loadEmails(name)
			}
			return _emails!!
		}
		// get() { return _emails ?: listOf() }
}

// -------------------------------------------------------------

class PersonLazy2(val name: String) {
	// Lazily Loading emails Property
	//		At emails Property Access Time 
	val emails by lazy { loadEmails(name) }
	// Compiler Will Generate Following Code For Above Line Of Code
	// private var _emails: List<Email>? = loadEmails(name)
	// val emails: List<Email>
		// get() {
		// 	// Lazy Pattern : Lazily Loading
		// 	//		Load Emails Only When Used
		// 	if ( _emails == null ) { 
		// 		_emails = loadEmails(name)
		// 	}
		// 	return _emails!!
		// }
}

fun playWithLazyPerson() {
	val gabbar1 = PersonLazy1(name = "Gabbar Singh")
	println( gabbar1.emails )

	val gabbar2 = PersonLazy2(name = "Gabbar Singh")
	println( gabbar2.emails )
}

// ____________________________________________________
// ____________________________________________________
// ____________________________________________________
// ____________________________________________________
// Experiment Following Code and THAN RAISE YOUR HAND!!


fun main() {
	println("\nFunction : playWithNestedAndInnerClasses")
	playWithNestedAndInnerClasses()

	println("\nFunction : playWithHuman")
	playWithHuman()

	println("\nFunction : playWithHumanAgain")
	playWithHumanAgain()

	println("\nFunction : classDelegationUsingTheByKeyword")
	classDelegationUsingTheByKeyword()

	println("\nFunction : playWithLateInitExample")
	playWithLateInitExample()

	// println("\nFunction : playWithLazyPerson")
	// playWithLazyPerson()

	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
}


