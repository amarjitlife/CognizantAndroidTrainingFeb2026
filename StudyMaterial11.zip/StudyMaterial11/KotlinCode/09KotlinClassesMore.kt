/*
kotlinc 04KotlinMoreClasses.kt -include-runtime -d moreClasses.jar
java -jar moreClasses.jar
*/

package learnKotlin

// ____________________________________________________

data class Grade(val letter: Char, val points: Double, val credits: Double)

// In Kotlin
//     All Classes Are Final By Default
//			Final Class Can't Be Inherited
//     All Members Are Also Final By Default
//			Final Members Can't Be Overridden In Child Classes

// In Java
//      All Classes Are Open By Default
//         	Open Class Can Be Inherited
//     	All Members Are Also Open By Default
//			Final Members Can Be Overridden In Child Classes

// class Person constructor(var firstName: String, var lastName: String) {

//				 Primary Constructor
//					Here constructor Keyword Is Optional
open class Person constructor(var firstName: String, var lastName: String) {
	// Member Function
	open fun fullName() = "$firstName $lastName"

	override fun toString() : String { return "Person(firstName=$firstName, lastName=$lastName)" }
}

// Student Is Child Class Of Person Parent Class
//      Student Is Inhertiting From Parent Class

open class Student(
	firstName: String, 
	lastName: String, 
	var grades: MutableList<Grade> = mutableListOf<Grade>()
) : Person(firstName, lastName) { 
	// error: this type is final, so it cannot be extended.

	// Calling Parent Class Constructor Also
	//		Passing Parent Class Constructor Arguments Also

	// Member Function
	open fun recordGrade(grade: Grade) {
		grades.add(grade)
	}

	override fun toString() = "Student(firstName=$firstName, lastName=$lastName)"

	// fun fullName() = "Student Full Name: $firstName $lastName"
	// error: 'fullName' hides member of supertype 'Person' and needs an 'override' modifier.

	override fun fullName() = "Student Full Name: $firstName $lastName"
	// error: 'fullName' in 'Person' is final and cannot be overridden.
}

fun playWithClassesAndObjects() {
	val john = Person(firstName = "Johnny", lastName = "Appleseed")
	val jane = Student(firstName = "Jane", lastName = "Appleseed")

	println( john )
	println( jane )

	println( john.fullName() )	// Johnny Appleseed
	println( jane.fullName() ) 	// Jane Appleseed

	val history = Grade(letter = 'B', points = 9.0, credits = 3.0)
	println( history )

	jane.recordGrade(history)
}

// ____________________________________________________

open class BandMember(firstName: String, lastName: String) : Student(firstName, lastName) {
	open val minimumPracticeTime: Int
		get() { return 2 }
}

class TablaPlayer(firstName: String, lastName: String) : BandMember(firstName, lastName) {
	override val minimumPracticeTime: Int = super.minimumPracticeTime * 2
}

class GuitarPlayer(firstName: String, lastName: String) : BandMember(firstName, lastName) {
	override val minimumPracticeTime: Int = super.minimumPracticeTime * 2
}

fun phonebookName(person: Person): String {
	return "${person.lastName}, ${person.firstName}"
}

fun playWithPhoneBookName() {
	val person = Person(firstName = "Johnny", lastName = "Appleseed")
	val tablaPlayer = TablaPlayer(firstName = "Jane", lastName = "Appleseed")
	val guitarPlayer = TablaPlayer(firstName = "Gabbar", lastName = "Singh")

	phonebookName(person) // Appleseed, Johnny
	phonebookName(tablaPlayer) // Appleseed, Jane
	phonebookName(guitarPlayer) // Appleseed, Jane
}

fun playWithRuntimeTypeCheck() {
	// Runtime hierarchy checks
	var hallMonitor: Student

	val tablaPlayer 	= TablaPlayer(firstName = "Jane", lastName = "Appleseed")
	val guitarPlayer 	= GuitarPlayer(firstName = "Gabbar", lastName = "Singh")

	hallMonitor = tablaPlayer

	println(hallMonitor is TablaPlayer) 
	println(hallMonitor !is TablaPlayer) 
	println(hallMonitor is BandMember) 
	println(hallMonitor is Student) 
	println(hallMonitor is Person) 

	val practiceTime = hallMonitor.minimumPracticeTime
	println( practiceTime )

	val someStudent 	= tablaPlayer as Student
	// val practiceTime1 	= someStudent.minimumPracticeTime
	// error: unresolved reference 'minimumPracticeTime
	// println( practiceTime1 )

	val bandMember 	= tablaPlayer as BandMember
	val practiceTime1 	= bandMember.minimumPracticeTime
	println( practiceTime1 )
}


// ____________________________________________________

// Invariance In System
//      Feature : Function Name

// Polymorphism
//      Using Mechanism : Function Overloading 

// Function Overloading
fun afterClassActivity(student: Student): String {
	return "Goes home!"
}

fun afterClassActivity(student: BandMember): String {
	return "Goes to practice!"
}

fun playWithAfterClassActivityFunction() {
	val tablaPlayer = TablaPlayer(firstName = "Jane", lastName = "Appleseed")

	println(afterClassActivity(tablaPlayer)) // Goes to practice!
	println(afterClassActivity(tablaPlayer as Student)) // Goes home!
}


// ____________________________________________________


class StudentAthlete(
	firstName: String, 
	lastName: String
) : Student(firstName, lastName) {

	val failedClasses = mutableListOf<Grade>()

	override fun recordGrade(grade: Grade) {
		super.recordGrade(grade)
		// Calling Function From Parent Class Using super Keyword
		
		if (grade.letter == 'F') {
			failedClasses.add(grade)
		}
	}

	val isEligible: Boolean
		get() = failedClasses.size < 3
}

fun playWithStudentAthlete() {
	val math 		= Grade(letter = 'B', points = 9.0, credits = 3.0)
	val science 	= Grade(letter = 'F', points = 9.0, credits = 3.0)
	val physics 	= Grade(letter = 'F', points = 9.0, credits = 3.0)
	val chemistry 	= Grade(letter = 'F', points = 9.0, credits = 3.0)

	val gabbar = StudentAthlete(firstName = "Gabbar", lastName = "Singh")
	gabbar.recordGrade(math)
	gabbar.recordGrade(science)

	gabbar.recordGrade(physics)
	println("${gabbar.fullName()} is ${if (gabbar.isEligible) "eligible" else "ineligible"}") // eligible

	gabbar.recordGrade(chemistry)
	println("${gabbar.fullName()} is ${if (gabbar.isEligible) "eligible" else "ineligible"}") // ineligible
}


// ____________________________________________________


class StudentAthlete2(firstName: String, lastName: String) : Student(firstName, lastName) {
	var failedClasses = mutableListOf<Grade>()

	override fun recordGrade(grade: Grade) {
		var newFailedClasses = mutableListOf<Grade>()
		for (grade in grades) {
			if (grade.letter == 'F') {
				newFailedClasses.add(grade)
			}
		}
		failedClasses = newFailedClasses

		// Calling Function From Parent Class Using super Keyword
		super.recordGrade(grade)
	}

	val isEligible: Boolean
		get() = failedClasses.size < 3
}


// ____________________________________________________

// Allowing inheritance

class FinalStudent(
	firstName: String, 
	lastName: String
) : Person(firstName, lastName)
	 // error: this type is final, so it cannot be extended.

// class FinalStudentAthlete(
//     firstName: String, 
//     lastName: String
// ): FinalStudent(firstName, lastName) // Build error!

open class AnotherStudent(
	firstName: String, 
	lastName: String
) : Person(firstName, lastName) {
	 // error: this type is final, so it cannot be extended.
	open fun recordGrade(grade: Grade) {}
	fun recordTardy() {}
}

class AnotherStudentAthlete(
	firstName: String, 
	lastName: String
) : AnotherStudent(firstName, lastName) {
	override fun recordGrade(grade: Grade) {} // OK
//  override fun recordTardy() {} // Build error!
}


// ____________________________________________________


abstract class Mammal(val birthDate: String) {
	abstract fun consumeFood()
}

// Concrete Class
class Human(birthDate: String) : Mammal(birthDate) {
	// Providing Implementation Of Abstract Method
	override fun consumeFood() {
		println("Human: consumeFood Called...")
	}
	
	fun createBirthCertificate() {
		println("Human: createBirthCertificate Called...")
	}
}

fun playWithHumanAndMammal() {
 	// val mammal = Mammal("1/1/2000") 
	// Error: Cannot create an instance of an abstract class

	val human = Human("1/1/2000")
	human.consumeFood()
	human.createBirthCertificate()
}



// ____________________________________________________

// Constructor Overloading

// Secondary Constructors
open class Shape {
	var fillColor: String
	var boundaryColor: String 
	// Secondary Constructors
	constructor( fillColor: String ) {
		this.fillColor 		= fillColor
		this.boundaryColor 	= "Black" 
	}

	// Secondary Constructors
	// this( ArgumentsList ) Calling Class Constructor In Same Class
	constructor( fillColor: String, boundaryColor: String) : this(fillColor) {
		this.fillColor 		= fillColor
		this.boundaryColor 	= boundaryColor
	}

	override fun toString() = "Shape(fillColor=$fillColor, boundaryColor=$boundaryColor)"
}

class Circle : Shape {
	var radius: Int
	// Secondary Constructors
	// super( ArgumentsList ) Calling Class Constructor From Parent Class
	constructor( fillColor: String ) : super(fillColor) {
		this.radius = 0
	}

	// Secondary Constructors
	constructor( fillColor: String, boundaryColor: String) : super(fillColor, boundaryColor) {
		this.radius = 0
	}

	// Secondary Constructors
	constructor( fillColor: String, boundaryColor: String, radius: Int) : super(fillColor, boundaryColor) {
		this.radius = radius
	}

	override fun toString() = "Shape(fillColor=$fillColor, boundaryColor=$boundaryColor, radius=$radius)"
}

fun playWithSecondaryConstructors() {
	val shape1 = Shape( fillColor = "Green" )
	println( shape1 )

	val shape2 = Shape( fillColor = "Blue", boundaryColor = "Red" )
	println( shape2 )

	val circle1 = Circle( fillColor = "Blue")
	println( circle1 )

	val circle2 = Circle( fillColor = "Blue", boundaryColor = "Red" )
	println( circle2 )

	val circle3 = Circle( fillColor = "Blue", boundaryColor = "Red", radius = 99 )
	println( circle3 )
}

// ____________________________________________________

// Visibility modifiers

data class Privilege(val id: Int, val name: String)

open class User(val username: String, private val id: String, protected var age: Int)

class PrivilegedUser(username: String, id: String, age: Int) : User(username, id, age) {
	private val privileges = mutableListOf<Privilege>()

	fun addPrivilege(privilege: Privilege) {
		privileges.add(privilege)
	}

	fun hasPrivilege(id: Int): Boolean {
		return privileges.map { it.id }.contains(id)
	}

	fun about(): String {
		// return "$username, $id" // Error: id is private
		return "$username, $age" // OK: age is protected
	}
}

fun playWithVisibilityModifiers() {
	val privilegedUser = PrivilegedUser(username = "sashinka", id = "1234", age = 21)
	val privilege = Privilege(1, "invisibility")
	privilegedUser.addPrivilege(privilege)
	println(privilegedUser.about()) // sashinka, 21
}

// ____________________________________________________

// Sealed Classes Are Used To Create Restricted Inheritance
//		You Can Inherit From Sealed Class Within Same File

sealed class Geometry {
	// Definining Class Inside A Class
	class Circle(val radius: Int) : Geometry()
	class Square(val sideLength: Int) : Geometry()
}

// Working With Sealed classes
fun sizeOfGeometery(geometry: Geometry): Int {

	return when (geometry) {
		is Geometry.Circle -> geometry.radius
		is Geometry.Square -> geometry.sideLength
	}
}

fun playWithGeometries() {
	val circle1 = Geometry.Circle(4)
	val circle2 = Geometry.Circle(2)
	val square1 = Geometry.Square(4)
	val square2 = Geometry.Square(2)
}


// _____________________________________________________
// Experiment Folloiwng Code, Moment Done >>> RAISE HAND!

// Object Classes
// 		Singleton Classes
// 			Singleton Class Having Only One Instance
//		object Classes Are Singleton Classes In Kotlin
// 			Will Define Singleton Named Class
//			Create One Unique Instance of It.
//			You Can Access Unique Instance With Class Name.

object Singleton {
	var member: String = "Unknown Value"
}


object X {
	var x = 0
}


fun playWithObjectClasses() {
	var value: String = Singleton.member

	println("Value Stored In Singleton : $value")
	println( X.x )

	Singleton.member = "Kotlin Is Great Language!"
	X.x = 9000

	value = Singleton.member
	println("Value Stored In Singleton : $value")
	println( X.x )

}

// _____________________________________________________
// Implement India Singleton Class In Kotlin

// Singleton Class With Unique Object and Object Is Accessed Using Class Name

object India {
	var name : String = "India"

	fun getStates() : List<String> {
		return listOf("Karnatka", "Jammu & Kashmir", "Punjab", "Gujrat", "Tamilnadu",
			"Bihar", "Uttar Pradesh", "Maharastra", "Kerala")		
	}

	fun decoratedName() : String {
		return "Country Name : $name"
	}
}

fun playWithIndia() {
	println( India.name )
	
	India.name = "Bharat"
	println( India.name )

	India.name = "Hindustan!"
	println( India.name )

	println( India.getStates())
	println( India.decoratedName())	
}

// ______________________________________________________
// Experiment Folloiwng Code, Moment Done >>> RAISE HAND!

data class Student3(val id: Int, val firstName: String, val lastName: String) {
	val fullName = "$lastName, $firstName"
}

// Singleton Class
object StudentRegistry {
	val allStudents = mutableListOf<Student3>()

	fun addStudent(student: Student3) {
		allStudents.add(student)
	}

	fun removeStudent(student: Student3) {
		allStudents.remove(student)
	}

	fun listAllStudents() {
		allStudents.forEach( { println(it.fullName) } )
	}
}

fun playWithStudentRegistry() {
	val marie = Student3(100, "Marie", "Curie")
	val albert = Student3(101, "Albert", "Einsein")
	val alice = Student3(102, "Alice", "Carol")

	StudentRegistry.addStudent(marie)
	StudentRegistry.addStudent(albert)
	StudentRegistry.addStudent(alice)

	StudentRegistry.listAllStudents()
}


// ______________________________________________________
// Experiment Folloiwng Code, Moment Done >>> RAISE HAND!

// Creating Class/Type Members In Kotlin

// Companions Objects
//		Companions Objects Members Are Class Members
//			i.e. Can Be Accessed Using Enclosing Class/Type

class TypeMember1 {
	// Companion Object Class Name Optional
	//		Companion Will Be Default Class For Companion Object
	companion object {
		fun doMagic() {
			println("Companion Object Member Called... Doing Magic")
		}
	}
} 

class TypeMember2 {
	// Companion Object Class Name Mentioned
	companion object Magician {
		fun doMagic() {
			println("Companion Object Member Called... Doing Magic")
		}
	}
} 

fun playWithCompanionObjects() {

	// Following Two Lines Of Code Are Equivalent
	TypeMember1.doMagic()
	TypeMember1.Companion.doMagic()

	// Following Two Lines Of Code Are Equivalent
	TypeMember2.doMagic()
	// TypeMember2.Companion.doMagic()
	TypeMember2.Magician.doMagic()
}

// ____________________________________________________
// ____________________________________________________
// ____________________________________________________
// ____________________________________________________
// ____________________________________________________
// ____________________________________________________
// ____________________________________________________
// Experiment Following Code and THAN RAISE YOUR HAND!!


fun main() {
	println("\nFunction : playWithClassesAndObjects")
	playWithClassesAndObjects()
	
	println("\nFunction : playWithRuntimeTypeCheck")
	playWithRuntimeTypeCheck()

	println("\nFunction : playWithAfterClassActivityFunction")
	playWithAfterClassActivityFunction()

	println("\nFunction : playWithStudentAthlete")
	playWithStudentAthlete()

	println("\nFunction : playWithHumanAndMammal")
	playWithHumanAndMammal()

	println("\nFunction : playWithSecondaryConstructors")
	playWithSecondaryConstructors()

	println("\nFunction : playWithVisibilityModifiers")
	playWithVisibilityModifiers()

	println("\nFunction : playWithGeometries")
	playWithGeometries()

	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
}




