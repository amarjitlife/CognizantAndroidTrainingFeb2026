_______________________________________________________________________________________

TODAY'S ASSIGNMENTS
DAY 01 + DAY 02 :: 27th February, 2026 + 02nd March, 2026
_______________________________________________________________________________________

	Assignment A1 : Reading, Thinking Assignment
		Chapter 02: Types, Operators And Expressions
		Chapter 05: Pointers and Arrays [ MUST MUST MUST ]
			Read, Understand and Experiment Code In Above Chapters

		Reference : The C Programming Language, 2nd Edition
			By Brian Kernigham and Dennis Ritchie

	Assignment A2 : Code, Practice and Experiment Kotlin Code In Class
		Practice and Experiment Kotlin Code Till Now Done!!

	Assignment A3 : Read, Code, Practice and Experiment Kotlin Code
		Chapter 01: Kotlin What and Why?
			Read, Understand and Experiment Code In Above ChaptersCode

		Reference : 
			1.  Kotlin in Action 2nd Edition
				Sebastian Aigner, Roman Elizarov, Svetlana Isakova, and Dmitry Jemerov
	
_______________________________________________________________________________________

DAY 03 :: 03rd March, 2026 :: COMPULSARY ASSIGNEMNTS
_______________________________________________________________________________________

	Assignment A1 : Study, Code, Practice and Experiment Kotlin Code Done In Class
		Practice and Experiment Kotlin Code Till Now Done In Class!!
			https://kotlinlang.org/docs/kotlin-tour-basic-types.html
			https://kotlinlang.org/docs/kotlin-tour-collections.html
			https://kotlinlang.org/docs/kotlin-tour-control-flow.html

	Assignment A2 : Reading, Thinking Assignment [ MUST MUST MUST ]
		Chapter 05: Pointers and Arrays 
			Read, Understand and Experiment Code In Above Chapters

		Reference : The C Programming Language, 2nd Edition
			By Brian Kernigham and Dennis Ritchie

_______________________________________________________________________________________

DAY 04 :: 04th March, 2026 :: COMPULSARY ASSIGNEMNTS
_______________________________________________________________________________________


	Assignment A1 : Study, Code, Practice and Experiment Kotlin Code Done In Class
		Practice and Experiment Kotlin Code Till Now Done In Class!!
			https://kotlinlang.org/docs/kotlin-tour-classes.html
			https://kotlinlang.org/docs/kotlin-tour-functions.html

	Assignment A2 : Reading, Thinking, Coding Assignment [ MUST MUST MUST ]
		Read, Code, Practice Following Chapters from Core Java for The Impatient
			1. Chapter 02 : Object-Oriented Programming  [ MUST MUST MUST ]
			2. Chapter 01 : Fundamental Programming Structures 

		Reference : Core Java for the Impatient by Cay Horstmann

	Assignment A3 : REVISIONS AND THINKING Assignment [ MUST MUST  ]
		Chapter 05: Pointers and Arrays 
			Read, Understand and Experiment Code In Above Chapters

		Reference : The C Programming Language, 2nd Edition
			By Brian Kernigham and Dennis Ritchie


_______________________________________________________________________________________

DAY 05 :: 05th March, 2026 :: COMPULSARY ASSIGNEMNTS
_______________________________________________________________________________________


	Assignment A1 : CODING, REVISIONS, THINKING Assignment [ MUST MUST MUST ]
		Chapter 05: Pointers and Arrays 
			Read, Understand and Experiment Code In Above Chapters

		Reference : The C Programming Language, 2nd Edition
			By Brian Kernigham and Dennis Ritchie

	Assignment A2 : Reading, Thinking, Coding Assignment [ MUST MUST MUST ]
		Read, Code, Practice Following Chapters from Core Java for The Impatient
			1. Chapter 02 : Object-Oriented Programming  [ MUST MUST MUST ]
			2. Chapter 01 : Fundamental Programming Structures 

		Reference : Core Java for the Impatient by Cay Horstmann

	Assignment A3 : Study, Code, Practice and Experiment Kotlin Code Done In Class
		Practice and Experiment Kotlin Code Till Now Done In Class!!
			https://kotlinlang.org/docs/kotlin-tour-classes.html
			https://kotlinlang.org/docs/kotlin-tour-functions.html

	Assignment A4 : Study Operating System Concepts [ OPTIONAL ]
		Chapter 03: Process Description and Control
			Read and Understand Concepts Related To Process
		Reference: Operating System Internals and Design Principles
					By William Stalling


_______________________________________________________________________________________

DAY 06 :: 06th March, 2026 :: COMPULSARY ASSIGNEMNTS
_______________________________________________________________________________________

	Assignment A1 : Study, Code, Practice and Experiment Kotlin Code Done In Class
		Practice and Experiment Kotlin Code Till Now Done In Class!!
			https://kotlinlang.org/docs/kotlin-tour-classes.html
			https://kotlinlang.org/docs/kotlin-tour-functions.html
			https://kotlinlang.org/docs/kotlin-tour-null-safety.html

	Assignment A2 : Reading, Thinking, Coding Assignment [ MUST MUST MUST ]
		Read, Code, Practice Following Chapters from Kotlin In Action
			1. Chapter 02 : Kotlin Basics [ MUST MUST MUST ]
			2. Chapter 01 : Kotlin What and Why?
		
		Read, Code, Practice Following Chapters from Core Java for The Impatient
			2. Chapter 02 : Object-Oriented Programming  [ MUST MUST MUST ]

		Reference : 
			1. Kotlin In Action, 2nd Edition
			2. Core Java for the Impatient by Cay Horstmann

	Assignment A3 : CODING, REVISIONS, THINKING Assignment [ MUST MUST MUST ]
		Chapter 05: Pointers and Arrays
			Read, Understand and Experiment Code In Above Chapters

		Reference : The C Programming Language, 2nd Edition
			By Brian Kernigham and Dennis Ritchie


	Assignment A4 : Study Operating System Concepts 
		Chapter 03: Process Description and Control
			Read and Understand Concepts Related To Process
		Reference: Operating System Internals and Design Principles
					By William Stalling

_______________________________________________________________________________________

DAY 07 :: 09th March, 2026 :: COMPULSARY ASSIGNEMNTS
_______________________________________________________________________________________

	Assignment A1 : Study, Code, Practice and Experiment Kotlin Code Done In Class
		Practice and Experiment Kotlin Code Till Now Done In Class!!
			https://kotlinlang.org/docs/kotlin-tour-classes.html
			https://kotlinlang.org/docs/kotlin-tour-functions.html
			https://kotlinlang.org/docs/kotlin-tour-null-safety.html

	Assignment A2 : Reading, Thinking, Coding and REVISION Assignment [ MUST MUST MUST ]
		Read, Code, Practice Following Chapters from Kotlin In Action
			1. Chapter 01 : Kotlin What and Why?
			2. Chapter 02 : Kotlin Basics [ MUST MUST MUST ]
		
		Reference : 
			1. Kotlin In Action, 2nd Edition
			2. Core Java for the Impatient by Cay Horstmann

_______________________________________________________________________________________

DAY 08 :: 10th March, 2026 :: COMPULSARY ASSIGNEMNTS
_______________________________________________________________________________________

	Assignment A1 : Study, Code, Practice and Experiment Kotlin Code Done In Class
		Practice and Experiment Kotlin Code Till Now Done In Class!!
			https://www.geeksforgeeks.org/kotlin/kotlin-extension-function/

	Assignment A2 : Study, Practice and Experiment Java Collections Code Examples
			https://www.geeksforgeeks.org/java/java-collection-tutorial/
			https://github.com/callicoder/java-collections-examples

	Assignment A3 : Reading, Thinking, Coding and REVISION Assignment 
		Read, Code, Practice Following Chapters From Kotlin In Action
			1. Chapter 02 : Kotlin Basics [ REVISION ]

		Read, Code, Practice Following Chapters From Core Java From Impatient
			2. Chapter 07 : Collections 
		
		Reference : 
			1. Kotlin In Action, 2nd Edition
			2. Core Java for The Impatient by Cay Horstmann

_______________________________________________________________________________________

DAY 09 :: 11th March, 2026 :: COMPULSARY ASSIGNEMNTS
_______________________________________________________________________________________

	Assignment A1 : Study, Code, Practice and Experiment Kotlin Code Done In Class
		
		Practice and Experiment Kotlin Code Till Now Done In Class!!
			https://medium.com/huawei-developers/kotlin-lambda-expressions-kotlin-anonymous-functions-example-tutorial-88a4b622f8b9
			https://www.scaler.com/topics/kotlin/lambda-expression-and-anonymous-functions-in-kotlin/

	Assignment A2 : Reading, Thinking, Coding Assignment 
		Read, Code, Practice Following Chapters From Kotlin In Action
			
			Chapter 03 : Defining and Calling Functions
				Full Chapter Reading, Coding and Thinking Assignment

			Chapter 05 : Programming with Lambdas
				Section 5.1: Lambda Expressions and Member References
			
			Chapter 10 : Higher-Order Functions
				Lambdas as Parameters and Return Values
				Section 10.1: Declaring Functions 
					Higher-Order Functions
						That Return Or Receive Other Functions: 
		
		Reference : 
			1. Kotlin In Action, 2nd Edition


_______________________________________________________________________________________

DAY 10 :: COMPULSARY ASSIGNEMNTS
_______________________________________________________________________________________


	Assignment A1 : Study, Code, Practice and Experiment Kotlin and Java Code Done In Class
		
		1. Practice and Experiment Kotlin Code Till Now Done In Class!!

		2. Read, Code, Practice Following Kotlin Notes
				└── KotlinNotes
				    ├── KotlinNotes3.Shared.pdf
				    ├── KotlinNotes5.Shared.pdf
				    ├── KotlinNotes6.Shared.pdf
				    ├── KotlinNotes7.Shared.pdf
				    ├── KotlinNotes10.Shared.pdf

		3. Study String and StringBuilder Classes And Member Functions
			1. Study String and StringBuilder In Java And Write Experiment Code In Kotlin

			2. Write Code To Experiment With Few More String Build In Functions In Kotlin

				https://kotlinlang.org/docs/strings.html
				https://www.geeksforgeeks.org/kotlin/kotlin-string/
				https://medium.com/@nachare.reena8/kotlin-strings-c4ccae7642c7
				https://www.baeldung.com/kotlin/string-extension-functions

	Assignment A2 : Reading, Thinking, Coding Assignment 

		Read, Code, Practice Following Chapters From Kotlin In Action

			Chapter 03 : Defining and Calling Functions
				Full Chapter Reading, Coding and Thinking Assignment

			Chapter 05 : Programming with Lambdas
				Section 5.1: Lambda Expressions and Member References
			
			Chapter 10 : Higher-Order Functions
				Lambdas as Parameters and Return Values
				Section 10.1: Declaring Functions Higher-Order Functions
						That Return Or Receive Other Functions: 
		
		Reference : 
			1. Kotlin In Action, 2nd Edition

_______________________________________________________________________________________

DAY 11 :: COMPULSARY ASSIGNEMNTS
_______________________________________________________________________________________

	Assignment A1 : Study, Code, Practice and Experiment Kotlin and Java Code Done In Class
		
		1. Practice and Experiment Kotlin Code Till Now Done In Class!!

		2. Read, Code, Practice Following Kotlin Notes

			└── KotlinNotes
			    ├── KotlinNotes8.Shared.pdf
			    |── KotlinNotes9.Shared.pdf
			    ├── KotlinNotes10.Shared.pdf


	Assignment A2 : Reading, Thinking, Coding Assignment 
		Read, Code, Practice Following Chapters From Kotlin In Action

			Chapter 04 : Classes, Objects, and Interfaces
				Full Chapter Reading, Coding and Thinking Assignment

	Assignment A3 : Reading, Thinking, Coding Assignment [ REVISION ]
		Read, Code, Practice Following Chapters From Kotlin In Action
			Revise All The Chapters, Kotlin Examples Done Till Date!!!
			
			Chapter 05 : Programming with Lambdas
				Section 5.1: Lambda Expressions and Member References
			
			Chapter 10 : Higher-Order Functions
				Lambdas as Parameters and Return Values
				Section 10.1: Declaring Functions Higher-Order Functions
						That Return Or Receive Other Functions: 
		
		Reference : 
			1. Kotlin In Action, 2nd Edition


_______________________________________________________________________________________
_______________________________________________________________________________________
_______________________________________________________________________________________
_______________________________________________________________________________________
_______________________________________________________________________________________
_______________________________________________________________________________________
_______________________________________________________________________________________


---------------------------------------------------------------------------------------
			+++ OPTIONAL ASSIGNEMNTS FOR ENERGETIC & ADVANCED LEARNERS +++
---------------------------------------------------------------------------------------

	Assignment A3 : Read, Code, Practice and Experiment Kotlin Code
		Chapter 01: Kotlin What and Why?
			Read, Understand and Experiment Code In Above ChaptersCode

		Reference : 
			1.  Kotlin in Action 2nd Edition
				Sebastian Aigner, Roman Elizarov, Svetlana Isakova, and Dmitry Jemerov


	Assignment A4 : Read, Code, Practice and Experiment Java Code
		Reference : 
			1. Core Java for the Impatient by Cay Horstmann
				Primary Book For Java Language: 
					It Covers Java Concepts Deeply
					It's An Intermediate Level Book

			2. Java: The Complete Reference, 13th Edition 
					by Herbert Schildt (Author), Dr Danny Coward (Author) 
				Seconday Book: This covers Java Syntax with Small Examples


	Assignment A5 : Study Data Strcutures and Algorithms 
		Chapter 09: Tables and Information Retrieval
			Hash Tables
		
		Reference:
			Data Structures and Program Design in C++ By Robert L. Kruse and Alexander J. Ryba

---------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------

