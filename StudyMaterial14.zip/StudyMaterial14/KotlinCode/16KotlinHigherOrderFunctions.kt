
//_______________________________________________________

/*
kotlinc -include-runtime Hello.kt -d hello.jar
java -jar nature.jar
*/

//_______________________________________________________

// Function Type
//		(Int, Int) -> Int
fun sum( a: Int, b: Int ): Int  = a + b
fun sub( a: Int, b: Int ): Int  = a - b

// Higher Order Function
//		Functions Which Takes And/Or Returns Functions

// Polymorphic Function
//		Mechanism : Passing A Behaviour To Behaviour

// Function Type
//		(Int, Int, (Int, Int) -> Int) -> Int
fun calculator( a: Int, b: Int, operation: (Int, Int) -> Int ) : Int {
	return operation( a, b )
}

fun playWithCalculator() {
	val a = 50
	val b = 20
	var result: Int = 0

	result = calculator( a, b, ::sum ) // Configuring with ::sum
	println("Result : $result")

	result = calculator( a, b, ::sub ) // Configuring with ::sum
	println("Result : $result")

	// Lambda
	//		Anonmous Functions
	val sumLambda: (Int, Int) -> Int  = { a: Int, b: Int -> a + b }
	result = calculator( a, b, sumLambda ) // Configuring with sumLambda
	println("Result : $result")

	// Function Type (Int, Int) -> Int
	val subLambda = { a: Int, b: Int -> a - b }
	result = calculator( a, b, subLambda ) // Configuring with subLambda
	println("Result : $result")

	result = calculator( a, b, { a: Int, b: Int -> a * b } ) // Configuring with subLambda
	println("Result : $result")

	// Trailing Lamba Syntax
	result = calculator( a, b ) { a: Int, b: Int -> a * b } // Configuring with subLambda
	println("Result : $result")

	result = calculator( a, b ) { 
		a: Int, b: Int -> a * b 
	} // Configuring with subLambda
	println("Result : $result")
}

//_______________________________________________________

fun twoAndThree(operation: (Int, Int) -> Int) {
    val result = operation(2, 3)
    println("The result is $result")
}

fun callingFunctionsPassedAsArguments() {
    twoAndThree { a, b -> a + b }
    twoAndThree { a, b -> a * b }
}

//_______________________________________________________

data class Person(val name: String, val age: Int)

fun findTheMax(people: List<Person> ) {
    var max = 0
    var theMaximum: Person? = null

    for (person in people) {
        if ( person.age > max ) {
            max = person.age
            theMaximum = person
        }
    }
    println(theMaximum)
}

fun playWithTheMax() {
    val people = listOf(Person("Alice", 29), Person("Bob", 31))
    findTheMax(people)
}

//_______________________________________________________

// Extension Function On Class/Type String
//      filter Is An Extension Function
//      Syntax
//      ClassName.FunctionName
//      Taking One Argument Of Type (Char) -> Boolean

// Higher Order Functions
//      Functions Which Takes And/Or Return Functions

// Higher Order Extension Function
//      Filter Taking Function As Argument

//                  Here predicate Is A Filtering Criteria
//                      This Filtering Criteria We Are Passing As Logic
fun String.filter( predicate: (Char) -> Boolean ): String {
    val sb = StringBuilder()
    for (index in 0 until length) {
        val element = get(index)
        if ( predicate(element) ) sb.append(element)
    }
    return sb.toString()
}

fun callingFunctionsPassedAsArguments1() {
    val smallCasesCriteria = { character : Char ->  character in 'a'..'z' }
    var result = "ab1c".filter( smallCasesCriteria )
    println("Result : $result")

    result = "ab1c".filter( { character : Char ->  character in 'a'..'z' } )
    println("Result : $result")

    result = "ab1c".filter( { it : Char ->  it in 'a'..'z' } )
    println("Result : $result")

    result = "ab1c".filter( ) { it : Char ->  it in 'a'..'z' }
    println("Result : $result")

    result = "ab1c".filter { it : Char ->  it in 'a'..'z' }
    println("Result : $result")

    println("ab1c".filter { it in 'a'..'z' })
    println("ab1cABCDEDF980".filter { it in 'A'..'Z' } )
    println("ab1cABCDEDF980".filter { it in '0'..'9' } )
}

//_______________________________________________________

//____________________________________________________________________

// Extension Function On Collection<T>
//      It Can Access Collection<T> Members Using this

// T Is Type Placeholder
fun <T> Collection<T>.joinToStringExtension(
    seperator: String = ", ",   // Parameter With Default Value
    prefix: String = "",        // Parameter With Default Value
    postfix: String = ""        // Parameter With Default Value
) : String {

    // Using StringBuilder To Create String Buffer Object
    //      String Buffer Object Is Used To Modfiy, Append The String
    //          Here We Are Appending String Object In The String Buffer
    val result = StringBuilder( prefix )

    for ( (index, element) in this.withIndex() ) {
        if ( index > 0 ) result.append( seperator )
        result.append( element )
    }

    result.append( postfix )
    // Getting String Object From String Buffer Object 
    return result.toString()
}

fun playWithJoinToStringExtensionFunction() {
    val names = listOf("Ding", "Dong", "Ting", "Tong")
    println( names.joinToStringExtension( ))
    println( names.joinToStringExtension( " : " ))
    println( names.joinToStringExtension( " : ", " >>>> " ))
    println( names.joinToStringExtension( " # ", " >>> ", " <<< " ))
    println( names.joinToStringExtension( " ## ", " [ ", " ] " ))

    val numbers = listOf(10, 20, 30, 40, 50)
    println( numbers.joinToStringExtension( ))
    println( numbers.joinToStringExtension( " : " ))
    println( numbers.joinToStringExtension( " : ", " >>>> " ))
    println( numbers.joinToStringExtension( " # ", " >>> ", " <<< " ))
    println( numbers.joinToStringExtension( " ## ", " [ ", " ] " ))
}

//____________________________________________________________________


// Higher Order Extension Function
fun <T> Collection<T>.joinToStringExtensionHOF(
        separator: String = ", ",
        prefix: String = "",
        postfix: String = "",
        transform: (T) -> String = { it.toString() } // Passing Function Default Value
): String {
    val result = StringBuilder(prefix)

    for ((index, element) in this.withIndex()) {
        if (index > 0) result.append(separator)
        result.append(transform(element))
    }

    result.append(postfix)
    return result.toString()
}

fun joinToStringExtensionHOF() {
    val letters = listOf("Alpha", "Beta")

    //error: cannot choose among the following candidates 
    // without completing type inference: 
    println(letters.joinToStringExtensionHOF())

    println(letters.joinToStringExtensionHOF { it.lowercase() } )
    println(letters.joinToStringExtensionHOF(separator = "! ", postfix = "! ",
           transform = { it.lowercase() }))

    println(letters.joinToStringExtensionHOF { it.uppercase() } )
    println(letters.joinToStringExtensionHOF(separator = "! ", postfix = "! ",
           transform = { it.uppercase() }))
}


//_______________________________________________________


enum class Delivery { STANDARD, EXPEDITED }

class Order(val itemCount: Int)

// Higher Order Function
//      Because It Returns Function Of Function Type (Order) -> Double

fun getShippingCostCalculator( delivery: Delivery ): (Order) -> Double {
    if (delivery == Delivery.EXPEDITED) {
        return { order -> 6 + 2.1 * order.itemCount }
    }

    return { order -> 1.2 * order.itemCount }
}

fun returningFunctionsFromFunctions() {
    val calculator =
        getShippingCostCalculator(Delivery.EXPEDITED)
    println("Shipping costs ${calculator(Order(3))}")
}


//_______________________________________________________

data class Person1(
    val firstName: String,
    val lastName: String,
    val phoneNumber: String?
)

class ContactListFilters {
    var prefix: String = ""
    var onlyWithPhoneNumber: Boolean = false

    // Higher Order Function
    //      Because It Returns Function 
    //          Of Function Type ( Person1 ) -> Boolean    
    fun getPredicate(): (Person1) -> Boolean {
        val startsWithPrefix = { p: Person1 ->
            p.firstName.startsWith(prefix) || p.lastName.startsWith(prefix)
        }

        if ( !onlyWithPhoneNumber ) {
            return startsWithPrefix
        }

        return { startsWithPrefix(it) && it.phoneNumber != null }
    }
}

fun returningFunctionsFromFunctions1() {
    val contacts = listOf(Person1("Dmitry", "Jemerov", "123-4567"),
                          Person1("Svetlana", "Isakova", null))
    val contactListFilters = ContactListFilters()
    with (contactListFilters) {
        prefix = "Dm"
        onlyWithPhoneNumber = true
    }
    println(contacts.filter(
        contactListFilters.getPredicate()))
}

// Function: returningFunctionsFromFunctions1
// [Person1(firstName=Dmitry, lastName=Jemerov, phoneNumber=123-4567)]

//_______________________________________________________
//_______________________________________________________
//_______________________________________________________
//_______________________________________________________
//_______________________________________________________
//_______________________________________________________


fun main() {
	println("\nFunction: returningFunctionsFromFunctions1")
	returningFunctionsFromFunctions1()

    println("\nFunction: callingFunctionsPassedAsArguments1")
    callingFunctionsPassedAsArguments1()

    println("\nFunction: playWithJoinToStringExtensionFunction")
    playWithJoinToStringExtensionFunction()

    println("\nFunction: joinToStringExtensionHOF")
    joinToStringExtensionHOF()

    println("\nFunction: returningFunctionsFromFunctions1")
    returningFunctionsFromFunctions1()
      
    // println("\nFunction: ")  
    // println("\nFunction: ")
    // println("\nFunction: ")  
	// println("\nFunction: ")	
	// println("\nFunction: ")
}


//_______________________________________________________
//_______________________________________________________


