/*
kotlinc 09.GenericsMore.kt -include-runtime -d genericsMore.jar
java -jar genericsMore.jar 
*/
package learnKotlin;

import java.util.Random

//_______________________________________________________________


// Polymorphic Function
// 		Function With Default Arguments
fun <T> Collection<T>.joinToStringFinal(
	separator: String = ", ",
	prefix: String = "",
	postfix: String = ""
) : String {

	val result = StringBuilder( prefix ) // Java StringBuilder
	// collections.withIndex() Will Generate List Of Tuples
	//		Where Tuple (index, Value), index belongs to [ 0, length( collection ) - 1 ]
	for( (index, element) in this.withIndex() ) {
		if ( index > 0 ) result.append( separator )
		result.append( element )
	}

	result.append( postfix )
	return result.toString()
}

fun playWithJoinToStringFinal() {
	// Type Inferencing and Binding Happening
	val list = listOf( 10, 20, 30, 40, 50 ) // ArrayList<Integer>
	println( list.joinToStringFinal( " ; ", "( ", " )" ) )
	println( list.joinToStringFinal( ) )
	println( list.joinToStringFinal( " : ") )
	println( list.joinToStringFinal( " : ", "[ " ) )
	println( list.joinToStringFinal( " : ", "[ ", " ]" ) )

	// Type Inferencing and Binding Happening
	val names = listOf("Alice", "Martin", "Chandan", "Ashish" ) // ArrayList<String>
	println( names.joinToStringFinal( " ; ", "( ", " )" ) )
	println( names.joinToStringFinal(  ) )	
	println( names.joinToStringFinal( " : " ) )	
	println( names.joinToStringFinal( " : ", "[ " ) )	
	println( names.joinToStringFinal( " : ", "[ ", " ]" ) )	
}

//_______________________________________________________________


fun <T> T.applyThenReturn( lambdaExprn : (T) -> Unit ) : T {
    lambdaExprn( this )
    return this
}

// Lambda With Receiver 
// 										// T Place Holder Act As Receiver For Lambda
fun <T> T.applyThenReturnAgain( lambdaExprnWithReceier : T.() -> Unit ): T {
    lambdaExprnWithReceier() // or this.lambdaExprnWithReceier()
    return this
}

fun playWithExtensionFunction() {
	var name: String

	name = "Baeldung".applyThenReturn { n -> println(n.uppercase()) }
	println( name )

	name = "Baeldung".applyThenReturn { println( it.uppercase() ) }
	println( name )

	var nameAgain = "Baeldung".applyThenReturnAgain { 
		println( uppercase() ) 
	}
	println( nameAgain )
}

//_______________________________________________________________


// E Is Type Place Holder
// MutableStack Is Generic Type i.e. Template

//	Generics Are Templates Programming
//		In Mathematics It's Callled Parameterised Types
//		Write Code To Generate Code
//		Compile Time Polymorphism

class MutableStack<E>( vararg items: E ) {              // 1
  private val elements = items.toMutableList()
  fun push(element: E) = elements.add(element)        // 2
  fun peek(): E = elements.last()                     // 3
  fun pop(): E = elements.removeAt(elements.size - 1)
  fun isEmpty() = elements.isEmpty()
  fun size() = elements.size
  override fun toString() = "MutableStack(${elements.joinToString()})"
}

// // Compiler Generated Code On Demand Basis
// //		Based On The Usage
// class MutableStack<Int>( vararg items: Int ) {              // 1
//   private val elements = items.toMutableList()
//   fun push(element: Int) = elements.add(element)        // 2
//   fun peek(): Int = elements.last()                     // 3
//   fun pop(): Int = elements.removeAt(elements.size - 1)
//   fun isEmpty() = elements.isEmpty()
//   fun size() = elements.size
//   override fun toString() = "MutableStack(${elements.joinToString()})"
// }

// // Compiler Generated Code On Demand Basis
// //		Based On The Usage
// class MutableStack<String>( vararg items: String ) {              // 1
//   private val elements = items.toMutableList()
//   fun push(element: String) = elements.add(element)        // 2
//   fun peek(): String = elements.last()                     // 3
//   fun pop(): String = elements.removeAt(elements.size - 1)
//   fun isEmpty() = elements.isEmpty()
//   fun size() = elements.size
//   override fun toString() = "MutableStack(${elements.joinToString()})"
// }

fun playWithMutableStack() {
	// Type Inferred and Substitued At Type Place Holder <E> At Compile Time
	val stackInts = MutableStack<Int>( 10, 20, 30 )
	println( stackInts.size() ) 
	stackInts.push( 100 )
	stackInts.push( 200 )
	println( stackInts.size() ) 
	println( stackInts.pop() )	

	val stackStrings = MutableStack<String>( "Ding", "Dong" )
	println( stackStrings.size() ) 
	stackStrings.push( "Ting" )
	stackStrings.push( "Tong" )
	println( stackStrings.size() ) 
	println( stackStrings.pop() )	
}

//_______________________________________________________________
// Experiment Following Code, MOMENT DONE >>> RAISE YOUR HANDS!!!

class Temperature(var tempInCelsius: Float)

// Extension Properties 

var Temperature.tempInFahrenheit: Float
    get() = (tempInCelsius * 9 / 5) + 32
    set(value) {
        tempInCelsius = (value - 32) * 5 / 9
    }

fun playWithExtensionProperties() {
    val temp = Temperature(32f)
	println(temp.tempInFahrenheit)

	temp.tempInFahrenheit = 90f
	println(temp.tempInCelsius)
}

//_______________________________________________________________
// Experiment Following Code, MOMENT DONE >>> RAISE YOUR HANDS!!!

val String.lastChar : Char 
	get() = get( length - 1 ) 


var StringBuilder.lastChar : Char 
	get() = get( length - 1 ) 
	set( value : Char ) {
		this.setCharAt( length -1 , value )
	}

fun playWithLastCharacterProperties() {
	println( "Hello World".lastChar )
	println( "Good Morning!".lastChar )

	val sb = StringBuilder("Good Afternoon!")
	println( sb )
	println( sb.lastChar )
	
	sb.lastChar = '#'
	println( sb )
	println( sb.lastChar )
}

//_______________________________________________________________
// Experiment Following Code, MOMENT DONE >>> RAISE YOUR HANDS!!!

// Generic Extention Property

val <T> List<T> .penultimate: T
	get() = this[ size - 2 ]


fun playWithGenericProperty() {
	val list = listOf( 10, 20, 30, 40)
	println( "Value : ${ list.penultimate }")

	val listAgain = listOf( "Ding", "Dong", "Ting", "Tong")
	println( "Value : ${ listAgain.penultimate }")
}

//_______________________________________________________________

// fun <T : Number> oneHalf( value: T ) : Double {
// 	return ( value / 2.0 )
// }

// fun playWithOneHalf() {
// 	val something = 90.0

// 	println( oneHalf( something ) )
// 	println( oneHalf( 150.0 ) )
// }

//_______________________________________________________________
// Experiment Following Code, MOMENT DONE >>> RAISE YOUR HANDS!!!

open class Animal( val type : String  ) 

open class Pet( val name : String, type: String ) : Animal( type )

class Cat( name : String, type: String ) : Pet( name, type ) 
open class Dog( name : String, type: String ) : Pet( name, type ) 
class GermanShaperd( name : String, type: String ) : Dog( name, type ) 


open class Human( val name: String )
class Owner( name : String ) : Human( name )

// Type Constraints
//		T Is Place Holder With Constraint Where Type Will Be Substituded
//			T Type Which Are Pet Or Subtypes of Pet
fun <T : Pet> chooseFavorite(pets: List<T> ): T {
	val random = Random()
    val favorite = pets[ random.nextInt( pets.size ) ]
    println("${favorite.name} is the favorite")
    return favorite
}

// fun <T> chooseFavoriteAgain( animals: List<T> ): T {
// 	val random = Random()
//     val favorite : Animal = animals[ random.nextInt( animals.size ) ]
//     println("${favorite.name} is the favorite")
//     return favorite
// }

fun chooseFavoriteNonGeneric( pets: List<Pet> ) : Pet {
	val random = Random()
    val favorite = pets[ random.nextInt( pets.size ) ]
    println("${favorite.name} is the favorite")
    return favorite
}

fun playWithChooseFavorite() {
	val cats: List<Cat> = listOf( Cat("Whiskers", "Cat"), Cat("Rosie", "Cat") )
	val favorite = chooseFavorite( cats )
	println( "Favorite Name : ${ favorite.name }" )

	val catsAgain: List<Cat> = listOf( Cat("Whiskers", "Cat"), Cat("Rosie", "Cat") )
	val favoriteAgain = chooseFavoriteNonGeneric( catsAgain )
	println( "Favorite Name : ${ favoriteAgain.name }" )

	// val animals: List<Animal> = listOf( Animal("Fish"), Animal("Bird"), Animal("Mammal") )
 // 	for (animal in animals) println( animal.type )
 	// error: type mismatch: inferred type is Animal but Pet was expected
	// val favoriteAgain = chooseFavorite( animals )
	// print( favoriteAgain )
}

//_______________________________________________________________
// Experiment Following Code, MOMENT DONE >>> RAISE YOUR HANDS!!!

// Boundless Generic Function
//		i.e. T Place Holder Can Be Substited With Any Type T
fun <T> equalsResult( first: T, second : T ) : Boolean  {
	return first == second
}

fun playWithEqualResults() {
	val first0 = 10
	val second0 = 100

	println( equalsResult( first0, second0 ) )

	val first1 = 10.90
	val second1 = 100.90

	println( equalsResult( first1, second1 ) )

	val first2 = Cat("Catie", "Cat")
	val second2 = Cat("Batie", "Cat")

	println( equalsResult( first2, second2 ) )
}

//_______________________________________________________________
// Experiment Following Code, MOMENT DONE >>> RAISE YOUR HANDS!!!


fun < T : Comparable<T> > max( first: T, second : T ) : T {
	return if ( first > second ) first else second
}

fun playWithGenericMax() {
	val maxValue0 = max( "Kotlin", "Java" )
	println( maxValue0 )

	val maxValue1 = max( 900, 100 )
	println( maxValue1 )

	val maxValue2 = max( 90.90, 100.100 )
	println( maxValue2 )
}

//_______________________________________________________________
// Experiment Following Code, MOMENT DONE >>> RAISE YOUR HANDS!!!

// Mutiple Type Parameters viz. T and U
fun < T : Pet, U : Human > chooseFavoriteMultiples( pets: List<T>, owners : List<U> ) : T {
	val random = Random()
	val owner = owners[ random.nextInt( owners.size ) ]
    val favorite = pets[ random.nextInt( pets.size ) ]

    println("${ favorite.name } is ${ owner.name } Favorite")
    return favorite
}

fun playWithChooseFavoriteMultiples() {
	val cats: List<Cat> = listOf( Cat("Whiskers", "Cat"), Cat("Rosie", "Cat") )
	val owners: List<Owner> = listOf( Owner("Himnanshu"), Owner("Shubra") )

	val favorite = chooseFavoriteMultiples( cats, owners )
	println( "Favorite Name : ${ favorite.name }" )
}

//_______________________________________________________________

fun <T> chooseFavoriteWhere(pets: List<T>): T where T : Pet {
	val random = Random()
    val favorite = pets[random.nextInt(pets.size)]
    println("${favorite.name} is the favorite")
    return favorite
}

fun <T, U> chooseFavoriteMultiplesWhere(pets: List<T>, owners: List<U>): T where T : Pet, U : Human {
    val random = Random()
    val owner = owners[random.nextInt(owners.size)]
    val favorite = pets[random.nextInt(pets.size)]
    println("${favorite.name} is ${owner.name}'s favorite")
    return favorite
}

// “If a type parameter has multiple constraints, 
// they all need to be placed in the ‘where’ clause” 

// fun <T : Animal> chooseFavorite(pets: List<T>): T where T : Named { /* ... */ }

//_______________________________________________________________
//_______________________________________________________________
//_______________________________________________________________
//_______________________________________________________________
//_______________________________________________________________
//_______________________________________________________________
//_______________________________________________________________
//_______________________________________________________________
//_______________________________________________________________
//_______________________________________________________________
// Experiment Following Code, MOMENT DONE >>> RAISE YOUR HANDS!!!

fun main() {
	println("\nFunction : playWithMutableStack")
	playWithMutableStack()

	println("\nFunction : playWithExtensionProperties")
	playWithExtensionProperties()

	println("\nFunction : playWithGenericProperty")
	playWithGenericProperty()

	println("\nFunction : playWithLastCharacterProperties")
	playWithLastCharacterProperties()

	// println("\nFunction : playWithOneHalf")
	// playWithOneHalf()

	println("\nFunction : playWithChooseFavorite")
	playWithChooseFavorite()

	println("\nFunction : playWithEqualResults")
	playWithEqualResults()

	println("\nFunction : playWithGenericMax")
	playWithGenericMax()

	println("\nFunction : playWithChooseFavoriteMultiples")
	playWithChooseFavoriteMultiples()

	// println("\nFunction : ")	
	// println("\nFunction : ")
	// println("\nFunction : ")
}

/*
kotlinc 09.GenericsMore.kt -include-runtime -d genericsMore.jar
java -jar genericsMore.jar 
*/