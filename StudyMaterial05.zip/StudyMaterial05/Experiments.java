

//____________________________________________________________________
// EXCERCISE :: Write Following Equivalent Code In Java

/*
class Customer

class Person( val name: String, val age: Int )

fun playWithClassesAndObjects() {
	// Calling Customer Constructor
	//		This Constructor Takes No Arguments
	val customer = Customer()
	println( customer ) // Printing customer Object

	val person = Person( name = "Gabbar Singh", age = 33 )
	println( person ) 		// Printing person Object
	println( person.name )  // Accessing name Property
	println( person.age ) 	// Accessing age Property
}
*/
//____________________________________________________________________


class Customer {
	
}

class Person {
	int id;
	int age;

	Person( int id, int age ) {
		this.id 	= id;
		this.age  	= age;
	}
}

public class Experiments {

	public static void playWithClassesAndObjects() {
		Customer customer = new Customer();
		System.out.println( customer );

		// Person person = new Person( );
		// In Java
		// Here po Is Not Person Object
		//		Rather po Address/Reference/Pointer Of Person Object Allocated At Heap
						// Person Object Allocated At Heap
		Person po = new Person( 101 , 33 );
		
		// In Kotlin
		// val Makes Reference/Address/Pointer To Object Is Immutable
		// val po = Person( 101, 33 );

		// var Makes Reference/Address/Pointer To Object Is Mmutable
		// var po = Person( 101, 33 );
		
		/*
		// In C
		  	// Java new Operator Calls malloc Internally
		  	//		It Returns Starting Address/Reference/Pointer Of Object Allocated At Heap Memory 
			Person * p = ( Person * ) malloc( sizeof( Person ) );
			
			// Intialisation Logic
			( *po ).name = "Gabbar Singh";
			( *po ).age  = 33;
		*/

		// 	error: constructor Person in class Person cannot be applied to given types;

		// Reference/Address/Pointer Assignment
		Person poc = po;

		System.out.println( po );
		System.out.println( poc );

		System.out.println( po.id );
		System.out.println( po.age );
		System.out.println( poc.id );
		System.out.println( poc.age );

		poc.age = 44;

		System.out.println( po.id );
		System.out.println( po.age );
		System.out.println( poc.id );
		System.out.println( poc.age );

		Person pon = new Person( 101 , 33 );
		System.out.println( po );
		System.out.println( poc );
		System.out.println( pon );

// Function : playWithClassesAndObjects
// Person@7344699f
// Person@7344699f
// Person@6b9597

// Person@7344699f
// Person@7344699f
// 101
// 33
// 101
// 33

// 101
// 44
// 101
// 44
	}

	public static void main( String[] args ) {
		System.out.println("\nFunction : playWithClassesAndObjects");
		playWithClassesAndObjects();

		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");		
	}
}

