

//____________________________________________________________________
// EXCERCISE :: Write Following Equivalent Code In Java

/*
class Customer

class Person( val name: String, val age: Int )

fun playWithClassesAndObjects() {
	// Calling Customer Constructor
	//		This Constructor Takes No Arguments
	val customer = Customer()
	println( customer ) // Printing customer Object

	val person = Person( name = "Gabbar Singh", age = 33 )
	println( person ) 		// Printing person Object
	println( person.name )  // Accessing name Property
	println( person.age ) 	// Accessing age Property
}
*/
//____________________________________________________________________


class Customer {
	
}

class Person {
	String name;
	int age;

	Person( String name, int age ) {
		this.name = name;
		this.age  = age;
	}
}

public class Experiments {
	public static void playWithClassesAndObjects() {
		Customer customer = new Customer();
		System.out.println( customer );

		// Person person = new Person( );

		Person person = new Person( "Gabbar Singh", 33 );
		// 	error: constructor Person in class Person cannot be applied to given types;

		System.out.println( person );
		System.out.println( person.name );
		System.out.println( person.age );

	}

	public static void main( String[] args ) {
		System.out.println("\nFunction : playWithClassesAndObjects");
		playWithClassesAndObjects();

		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");		
	}
}

