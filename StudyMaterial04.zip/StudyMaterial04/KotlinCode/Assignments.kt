_______________________________________________________________________________________

TODAY'S ASSIGNMENTS
DAY 01 + DAY 02 :: 27th February, 2026 + 02nd March, 2026
_______________________________________________________________________________________

	Assignment A1 : Reading, Thinking Assignment
		Chapter 02: Types, Operators And Expressions
		Chapter 05: Pointers and Arrays [ MUST MUST MUST ]
			Read, Understand and Experiment Code In Above Chapters

		Reference : The C Programming Language, 2nd Edition
			By Brian Kernigham and Dennis Ritchie

	Assignment A2 : Code, Practice and Experiment Kotlin Code In Class
		Practice and Experiment Kotlin Code Till Now Done!!

	Assignment A3 : Read, Code, Practice and Experiment Kotlin Code
		Chapter 01: Kotlin What and Why?
			Read, Understand and Experiment Code In Above ChaptersCode

		Reference : 
			1.  Kotlin in Action 2nd Edition
				Sebastian Aigner, Roman Elizarov, Svetlana Isakova, and Dmitry Jemerov
	
_______________________________________________________________________________________

DAY 03 :: 03rd March, 2026 :: COMPULSARY ASSIGNEMNTS
_______________________________________________________________________________________

	Assignment A1 : Study, Code, Practice and Experiment Kotlin Code Done In Class
		Practice and Experiment Kotlin Code Till Now Done In Class!!
			https://kotlinlang.org/docs/kotlin-tour-basic-types.html
			https://kotlinlang.org/docs/kotlin-tour-collections.html
			https://kotlinlang.org/docs/kotlin-tour-control-flow.html

	Assignment A2 : Reading, Thinking Assignment [ MUST MUST MUST ]
		Chapter 05: Pointers and Arrays 
			Read, Understand and Experiment Code In Above Chapters

		Reference : The C Programming Language, 2nd Edition
			By Brian Kernigham and Dennis Ritchie

_______________________________________________________________________________________

DAY 04 :: 04th March, 2026 :: COMPULSARY ASSIGNEMNTS
_______________________________________________________________________________________


	Assignment A1 : Study, Code, Practice and Experiment Kotlin Code Done In Class
		Practice and Experiment Kotlin Code Till Now Done In Class!!
			https://kotlinlang.org/docs/kotlin-tour-classes.html
			https://kotlinlang.org/docs/kotlin-tour-functions.html

	Assignment A2 : Reading, Thinking, Coding Assignment [ MUST MUST MUST ]
		Read, Code, Practice Following Chapters from Core Java for The Impatient
			1. Chapter 02 : Object-Oriented Programming  [ MUST MUST MUST ]
			2. Chapter 01 : Fundamental Programming Structures 

		Reference : Core Java for the Impatient by Cay Horstmann

	Assignment A3 : REVISIONS AND THINKING Assignment [ MUST MUST  ]
		Chapter 05: Pointers and Arrays 
			Read, Understand and Experiment Code In Above Chapters

		Reference : The C Programming Language, 2nd Edition
			By Brian Kernigham and Dennis Ritchie


_______________________________________________________________________________________
_______________________________________________________________________________________
_______________________________________________________________________________________
_______________________________________________________________________________________
_______________________________________________________________________________________
_______________________________________________________________________________________
_______________________________________________________________________________________


---------------------------------------------------------------------------------------
			+++ OPTIONAL ASSIGNEMNTS FOR ENERGETIC & ADVANCED LEARNERS +++
---------------------------------------------------------------------------------------

_______________________________________________________________________________________

DAY 03 + 04 :: 03rd, 04th March, 2026 :: OPTIONAL ASSIGNEMNTS
_______________________________________________________________________________________


	Assignment A3 : Read, Code, Practice and Experiment Kotlin Code
		Chapter 01: Kotlin What and Why?
			Read, Understand and Experiment Code In Above ChaptersCode

		Reference : 
			1.  Kotlin in Action 2nd Edition
				Sebastian Aigner, Roman Elizarov, Svetlana Isakova, and Dmitry Jemerov


	Assignment A4 : Read, Code, Practice and Experiment Java Code
		Reference : 
			1. Core Java for the Impatient by Cay Horstmann
				Primary Book For Java Language: 
					It Covers Java Concepts Deeply
					It's An Intermediate Level Book

			2. Java: The Complete Reference, 13th Edition 
					by Herbert Schildt (Author), Dr Danny Coward (Author) 
				Seconday Book: This covers Java Syntax with Small Examples


	Assignment A5 : Study Data Strcutures and Algorithms 
		Chapter 09: Tables and Information Retrieval
			Hash Tables
		
		Reference:
			Data Structures and Program Design in C++ By Robert L. Kruse and Alexander J. Ryba

---------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------

