   
//____________________________________________________________________

// Choudhary, Suresh Sujaram (Cognizant)    
fun playWithExperiemntQuery01() {
    var list2 : MutableList<Int> = mutableListOf(1,2,4,5,6) // MutableList<Int>
    list2.add(5)
    println("list2 of int : ${list2}")
    println( list2 )
 
    // Inferred Type Of RHS Is MutableList<String>
    //      But LHS Type Is MutableList<Int>
    //      Hence Type Mismatch Will Happen
    list2 = mutableListOf("hello","jone","jack") // MutableList<String>
    // error: assignment type mismatch: 
    //      actual type is 'MutableList<String>', 
    //      but 'MutableList<Int>' was expected

    println( list2 )

    // Inferred Type Of RHS Is // MutableList<String>
    var list3 : MutableList<String> = mutableListOf("hello","jone","jack") // MutableList<String>
}

//____________________________________________________________________

// Kotlin has the following collections for grouping items:

// Collection Type   Description
// -----------------------------------------------------------------------
// Lists             Ordered collections of items
// Sets              Unique unordered collections of items
// Maps              Sets of key-value pairs where keys are unique and map to only one value

// Each collection type can be mutable or read only.

//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________

fun main() {
    println("\nFunction: playWithExperiemntQuery01")
    playWithExperiemntQuery01()

    // println("\nFunction: ")
    // println("\nFunction: ")
    // println("\nFunction: ")
    // println("\nFunction: ")
    // println("\nFunction: ")
    // println("\nFunction: ")
    // println("\nFunction: ")
}

//____________________________________________________________________
//____________________________________________________________________