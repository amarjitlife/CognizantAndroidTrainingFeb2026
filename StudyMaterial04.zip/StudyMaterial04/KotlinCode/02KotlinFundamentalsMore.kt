
/*
1. Compiling Kotlin Code
	kotlinc 02KotlinFundamentalsMore.kt -include-runtime -d fundamentals.jar

2. Running Compiled Code
	java -jar fundamentals.jar
*/

//____________________________________________________________________

// Created Function
//		It Takes No Arguments
//		And Returns Default Unit Value Of Unit Type 

// If your function doesn't return a useful value 
//		Then its return type is Unit. 
//		Unit is a type with only one value – Unit. 
//		You don't have to declare that Unit is returned explicitly in your function body. 
//		This means that you don't have to use the return keyword or declare a return type:

fun helloWorld() {
	println("Hello World!!!")
}

//____________________________________________________________________

// Function Overloading
//		Can Be Done Based On Following Rules
//		1. Number Of Arguments
//		2. Types Of Arguments

// Function Taking Two Int Arguments And Returning Int Value
fun sum( x: Int, y: Int ) : Int {
	return x + y
}

// Function Taking Three Int Arguments And Returning Int Value
fun sum( x: Int, y: Int, z: Int ) : Int {
	return x + y + z
}

// Function Taking Two Float Arguments And Returning Float Value
fun sum( x: Float, y: Float ) : Float {
	return x + y
}

fun playWithFunctions() {
	val result0 = helloWorld() // Result = kotlin.Unit
	println( "Result = $result0" )

	val result1 = sum( 100, 200 )
	println("Result = $result1 ")

	// val result2 = sum( 99.99, 10.10 )
	// error: none of the following candidates is applicable:
	//  	fun sum(x: Int, y: Int): Int
	// 		fun sum(x: Float, y: Float): Float

	val result2 = sum( 99.99F, 10.10F )
	println("Result = $result2 ")

	val result3 = sum( 100, 200, 99 )
	println("Result = $result3 ")
}

//____________________________________________________________________
//
// NAMED ARGUMENTS
//____________________________________________________________________


// Function Takes Two String Arguments And Returns Default Unit Value
//		Named Agruments: Both Arguments Have Names
//		Hence You Call Function With Named Arugments
fun printMessagewithPrefix( message: String, prefix: String ) {
	val newMessage = prefix + " " + message

	println( newMessage )
}

fun playWithFunctionNamedArguments() {
	// Calling Function Without Named Arguments
	//		Values Passed Get Assigned To Arguments In Order Which They Comes
	printMessagewithPrefix( "Good Afternoon!", "Gabbar Singh" )

	printMessagewithPrefix( message = "Good Afternoon!", "Gabbar Singh" )
	printMessagewithPrefix( "Good Afternoon!", prefix = "Gabbar Singh" )

	printMessagewithPrefix( message = "Good Afternoon!", prefix = "Gabbar Singh" )
	printMessagewithPrefix( prefix = "Gabbar Singh", message = "Good Afternoon!" )
}

// You can skip specific parameters with default values, 
//		rather than omitting them all. 
//		However, after the first skipped parameter, 
//		you must name all subsequent parameters.

// We recommend in our coding conventions that you name functions starting 
//		with a lowercase letter and use camel case with no underscores.

// If a function doesn't return anything useful, the return type and return keyword 
//		can be omitted. Learn more about this in Functions without return.


//____________________________________________________________________

fun summation1( x: Int, y: Int ) : Int {
	return x + y
}

// Single Expression Function Body Can Written Like As Follows
fun summation2( x: Int, y: Int ) : Int = x + y

// Return Type Of Function Inferred From RHS
fun summation3( x: Int, y: Int ) = x + y


fun playWithFunctionsAgain() {
	println( summation1( 90, 10 ) )
	println( summation2( 90, 10 ) )
	println( summation3( 90, 10 ) )	
}

// If you use {} curly braces to declare your function body, 
//		you must declare the return type unless it is the Unit type.

//____________________________________________________________________

// Global Variables/Values
//		Variables/Values Created Outside Of Function At File Level
//		Can Be Accessed In Any Function Defined Within File

// A list of registered usernames
val registeredUsernames = mutableListOf("Thakur", "Veeru")

// A list of registered emails
val registeredEmails = mutableListOf("thakur@example.com", "veeru@example.com")

fun registerUser(username: String, email: String): String {
    // Early return if the username is already taken
    if (username in registeredUsernames) {
        return "Username already taken. Please choose a different username."
    }

    // Early return if the email is already registered
    if (email in registeredEmails) {
        return "Email already registered. Please use a different email."
    }

    // Proceed with the registration if the username and email are not taken
    registeredUsernames.add(username)
    registeredEmails.add(email)

    return "User Registered Successfully: $username"
}

fun playWithFunctionEarlyReturns() {
    println(registerUser("Gabbar Singh", "gabbar@example.com"))
    // Username already taken. Please choose a different username.
    println(registerUser("Basanti", "basanti@example.com"))
    // User registered successfully: new_user
}

//____________________________________________________________________

fun playWithLambaExpression() {
	// Local Function
	//		Function Defined Inside A Function
	fun sum( x : Int, y : Int ) : Int {
		return x + y
	}

	fun sub( x : Int, y : Int ) : Int {
		return x - y
	}

	var result = sum( 999, 500 )
	println("	Result : $result ")

	result = sub( 999, 500 )
	println("	Result : $result ")

	// Lambda Expression Start And End With { } Braces
	//		Syntax :: { Comma Seperated Arguments List With Type -> Body }
	//												After Arrow Code Logic	
	val sumLambda = { x : Int, y : Int  -> x + y  }
	result = sumLambda( 999, 500 )
	println("	Result : $result ")

	val subLambda = { x : Int, y : Int  -> x - y  }
	result = subLambda( 999, 500 )
	println("	Result : $result ")
}

//____________________________________________________________________

fun playWithLambaExpressionAgain() {
	
	fun uppercaseString(text: String): String {
	    return text.uppercase()
	}

    println( uppercaseString("hello") )

 	val uppercaseStringLambda = { text: String -> text.uppercase() }
    println( uppercaseStringLambda("hello") )


	//	If you declare a lambda without parameters, 
	//		then there is no need to use ->. For example:

	val someLambda = { println("Log message") }
	someLambda()
}


//____________________________________________________________________

// In Kotlin
// 		Function Arguments Are Immutable By Default
//		Hence Arguments To Function Are val 

// In Java/C/C++
// 		Function Arguments Are Mutable By Default

fun someFunction( some: Int ) {
	// some = some + 10 // error: 'val' cannot be reassigned.
	var some = some
	some = some + 100
	println( some )
} 

fun playWithFunctionArgumentsMutability() {
	val x = 99

	someFunction( some = x )
	someFunction( x )
}


//____________________________________________________________________

fun playWithLambaExpressionOnceAgain() {

	val numbers = listOf( 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, -11, -99, 88 )
	println( numbers )

	val evenNumbersLambda = { x : Int  -> x % 2 == 0 }
	val oddNumbersLambda  = { x : Int  -> x % 2 != 0 }

	// Passing Lambda Expression To Function
	//		Passing Logic To Function
	val evenNumbers = numbers.filter( evenNumbersLambda )
	val oddNumbers  = numbers.filter( oddNumbersLambda )

	println( evenNumbers )
	println( oddNumbers )

	// Passing Lambda Expression To Function
	//		Passing Logic To Function
	val evenNumbersAgain = numbers.filter( { x : Int  -> x % 2 == 0 } )
	val oddNumbersAgain  = numbers.filter( { x : Int  -> x % 2 != 0 } )

	println( evenNumbers )
	println( oddNumbers )

	val evenNumbersAgain1 = numbers.filter( { x -> x % 2 == 0 } )
	val oddNumbersAgain1  = numbers.filter( { x -> x % 2 != 0 } )

	println( evenNumbersAgain1 )
	println( oddNumbersAgain1 )

	val positiveNumbers  = numbers.filter( { x : Int  -> x > 0 } )
	val negativeNumbers  = numbers.filter( { x : Int  -> x < 0 } )

	println( positiveNumbers )
	println( negativeNumbers )

	val squareLambda = { x : Int -> x * x }
	
	val squares1 = numbers.map( squareLambda )
	println( squares1 )

	val squares2 = numbers.map( { x : Int -> x * x } )
	println( squares2 )

	val cubesLambda = { x : Int -> x * x * x }
	
	val cubes1 = numbers.map( cubesLambda )
	println( cubes1 )

	val cubes2 = numbers.map( { x : Int -> x * x * x } )
	println( cubes2 )
}


//____________________________________________________________________
// EXCERCISE :: Write Following Equivalent Code In Java

class Customer

// In Kotlin
//		Compiler Will Generate Following Things
//		1. It Will Generate Memberwise Initialer
//				i.e. Constructor Taking Two Arguments
//		2. It Will Generate Getters For val Properties
//				Getters Name Will Be Same As Properties Name
//		3. It Will Generate Setters For var Properties
//				Setters Name Will Be Same As Properties Name

// In Kotlin
// Person Class Constructor With Two Arguments String And Int Type
			// Constructor
// Person Class Have Two val (Immutable) Properties 
//		1. name Of Type String
//      2. age of Type Int
//		Compiler Will Generate Getters For Immutable Properties
class Person( val name: String, val age: Int )

fun playWithClassesAndObjects() {
	// Calling Customer Constructor
	//		This Constructor Takes No Arguments
	val customer = Customer()
	println( customer ) // Printing customer Object

	val person = Person( name = "Gabbar Singh", age = 33 )
	println( person ) 		// Printing person Object
	println( person.name )  // Calling name Property Getter
	println( person.age ) 	// Calling age Property Getter
}

//____________________________________________________________________

// Class Contact Have Three Properties
//		Class Contact Constructor Takes Two Arguments Of Type Int And String
//		id Is Immutable And email, category Are Mutable

class Contact( val id: Int, var email: String ) {
	var category: String = "" // Initialised With Default Value Of Empty String
}

fun playWithClassProperties() {
	// co Is An Object Of Type Contact Class Type
	//		 Constructor Call Of Contact Class
	//			Constructor Taking Two Arguments
	val co = Contact( 101, email = "contact@cognizant.com" )

	println( co )
	println( co.id )
	println( co.email )
	println( co.category )

	// contact.id 			= 999 // error: 'val' cannot be reassigned.
	co.email 		= "contact@examples.com"
	co.category 	= "Employee" 

	println( co.id )
	println( co.email )
	println( co.category )
}


// The content contained within parentheses () is called the class header.
// You can use a trailing comma when declaring class properties.

//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________


fun main() {
	println("\nFunction: playWithFunctions")
	playWithFunctions()

	println("\nFunction: playWithFunctionNamedArguments")
	playWithFunctionNamedArguments()

	println("\nFunction: playWithFunctionsAgain")
	playWithFunctionsAgain()

	println("\nFunction: playWithFunctionEarlyReturns")
	playWithFunctionEarlyReturns()

	println("\nFunction: playWithLambaExpression")
	playWithLambaExpression()

	println("\nFunction: playWithLambaExpressionAgain")
	playWithLambaExpressionAgain()

	println("\nFunction: playWithFunctionArgumentsMutability")
	playWithFunctionArgumentsMutability()

	println("\nFunction: playWithLambaExpressionOnceAgain")
	playWithLambaExpressionOnceAgain()

	println("\nFunction: playWithClassesAndObjects")
	playWithClassesAndObjects()

	println("\nFunction: playWithClassProperties")
	playWithClassProperties()

	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
}

//____________________________________________________________________
//____________________________________________________________________

