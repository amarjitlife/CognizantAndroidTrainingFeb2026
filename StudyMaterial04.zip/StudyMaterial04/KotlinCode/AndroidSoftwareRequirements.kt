
I am sharing Lab Setup Details for your reference.

Software/Hardware Requirements
Computer/Laptop Hardware:
16GB+ RAM and Minimum Intel 6+ Core Processor, 200 GB Free Hard Disk Space
with Hardware Virtualization Enabled i.e. VT-x and VT-d Flags Enabled In BIOS

Operating System: Ubuntu 24.04 64 Bit or Windows 11+ 64 Bit or Latest Mac OS X
Preferably Ubuntu 24.04 64 Bit As Host Operating System
1. Android Emulator runs faster and better in Ubuntu/Linux
2. Android Is Also Linux At Lower Layer,
So It's Better To Provide Development Environment also Ubuntu Linux for better Learning
https://ubuntu.com/download/desktop

SDKs and Compilers Required with Download Links
Oracle Java Development Kit(JDK) 17+

Kotlin Compiler Latest
https://kotlinlang.org/docs/command-line.html

IDE: Android Studio Latest
https://developer.android.com/studio

Gradle Build System Latest
    https://gradle.org/releases/

Code Editors: Sublime Text 4 and Visual Studio Code
https://www.sublimetext.com/download
https://code.visualstudio.com/download

Android SDK Required:
Android 9 SDK (API Level 28) ,
Android 11 SDK (API Level 30)
Android 13 SDK (API Level 33)
Android 15 SDK (API Level 35)
Android 15 SDK (API Level 36)

Android NDK Latest
Android Command Line Tools
Android Emulator
Android Build Tools
Build Tools
Platform Tools
   
Ktor and SpringBoot for Writing REST APIs
    https://ktor.io/
    https://spring.io/projects/spring-boot

Tools and Frameworks
Jenkin
GitHub
Git Command Line
Jira
JUnit, Mockito, Roboelectric

Following Things Are Also Needed In Addition To Above
1. Active and Good Internet Connection with Minimum 8MBPS+ Speed
Internet On Devices Needed.


NOTE :: PLEASE NOTE THAT ANDROID APPLICATION BUILDING DOWNLOADS A LOT OF PACKAGES INTERNALLY FROM A LOT MANY LINKS FROM GOOGLE REPOSITORIES, MAVEN REPOSITORIES, GRADLE REPOSITORIES. IT's NOT POSSIBLE TO PREPARE LIST OF ALL LINKS OF THESE PACAKAGES AS THERE ARE SO MANY DEEP DEPENDENDCIES IN PACKAGES AND MOREOVER THESE LINKS AND DEPENDENDIES KEEP ON CHANGING.


Thanks and Regards,
Amarjit Singh
+91 9980 777 145

