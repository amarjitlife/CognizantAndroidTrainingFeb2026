/*
1. Compiling Kotlin Code
	kotlinc 03KotlinFundamentalsOnceMore.kt -include-runtime -d fundamentals.jar

2. Running Compiled Code
	java -jar fundamentals.jar
*/

//____________________________________________________________________

package learnKotlin

import java.util.Random
import java.util.TreeMap


//____________________________________________________________________

class Human( var name: String, var age: Int )

// In Java
// public static void doChange( Human hu ) {
// 		hu.name = "Gabbar Singh";
// 		hu.age 	= 99;
// }

// In Kotlin
fun doChange( hu : Human ) {
	hu.name = "Gabbar Singh"
	hu.age 	= 99
}

// In Java
// 		Parameters To Functions Are MUTABLE By Default In C/C++/Java
// public static void doChangeAgain( Human hu ) {
// 		hu = new Human( "Gabbar Singh Ramgarh", 500000 );
// }

// In Kotlin
// 		Parameters To Functions Are IMMUTABLE By Default In Kotlin
fun doChangeAgain( hu : Human ) {
	// hu = Human( "Gabbar Singh Ramgarh", 500000 )
	// 	error: 'val' cannot be reassigned.
	val huLocal = Human( "Gabbar Singh Ramgarh", 500000 )
}

fun playWithHumanObject() {
	val h = Human( name = "Gabbar", age = 33 )

	println( h.name )
	println( h.age )

	doChange( h )

	println( h.name )
	println( h.age )

	doChangeAgain( h )

	println( h.name )
	println( h.age )
}


//____________________________________________________________________

// Creatibg Person Class 
//		Having Two Properties viz. name And isMarried
//		name Property Is IMMUTABLE And isMarried Property Is MUTABLE
//		These Properties Are Defined In Constructor Parameters Using val/var Keywords

// In Java
//	Java Compiler Will Generate Default Constructor For Every Java Class
//		Default Constructor Is Constructor With No Arguments/Parameters

// In Kotlin
// 	Kotlin Compiler Will Generate Follwing Things For Person Class
//		1. It Will Generate A Default Constructor 
//			Constructor With Memberwise Initialiser 
//				Taking Two Arguments/Parameters Viz. name And isMarried
//				i.e. Person( name: String, isMarried: Boolean )	
//		2. name And isMarried Are Properties
//			For Each Property Kotlin Compiler Will Generate 1 Member Variable
//			For Each Property Kotlin Compiler Will Generate Getter/Setter Methods
//			NOTE :: 
// 				For IMMUTABLE Property Only Getter Generated
//				For MUTABLE Property Both Getter and Setter Generated

class Person( val name: String, var isMarried: Boolean )

// In Kotlin
// 	Kotlin Compiler Will Generate Follwing Things For PersonAgain Class
//		1. It Will Generate A Default Constructor 
//			Constructor With No Parameters/Arguements

class PersonAgain {
	// error: property must be initialized or be abstract.
	// val name: String 		
 	// var isMarried : Boolean

	// Initialing Properties Using Default Values
	var name: String 		= "Unknown" // Default Value
 	var isMarried : Boolean = false  	// Default Value
}

fun playWithClassPropertiesMutability() {
	// Here gabbar Is Reference/Address/Pointer To Object Of Person1 Type
	// Here val Makes gabbar Reference/Pointer Immutable
	// NOTE:: Reference/Address/Pointer Immutable Doesn't Mean Object Also Become Immutable
	val gabbar = Person( "Gabbar Singh", false )
	// gabbar = Person( "Gabbar Singh", false ) //  error: 'val' cannot be reassigned.
	println( gabbar )
	
	println( gabbar.name )
	println( gabbar.isMarried )

	// Person1 Type Object Property Getting Modified
	//		Hence Person1 Object Is Mutable
	// gabbar.name 		= "Gabbar" // error: 'val' cannot be reassigned.
	gabbar.isMarried 	= true

	println( gabbar.name )
	println( gabbar.isMarried )

	// Compilation Error Because Constructor With No Arguments Not Generated
	// val someone = Person() 
	// error: no value passed for parameter 'name'.
	// error: no value passed for parameter 'isMarried'.

	//error: too many arguments for 'constructor(): PersonAgain'.
	// val basanti1 = PersonAgain( "Gabbar Singh", false )
	// val basanti2 = PersonAgain( "Gabbar Singh" )
	val basanti = PersonAgain()

	println( basanti )
	
	println( basanti.name )
	println( basanti.isMarried )

	basanti.name 		= "Basanti"
	basanti.isMarried 	= true

	println( basanti.name )
	println( basanti.isMarried )
}


//____________________________________________________________________

// In Kotlin
// 		Kotlin Compiler Will Generate Following Things For Rectangle Class
//		1. It Will Generate A Default Constructor 
//			Constructor With Memberwise Initialiser 
//				Taking Two Arguments/Parameters Viz. height And width
//				i.e. Rectangle( height: Int, width: Int )
//		2. Rectangle Class Have Three Properties Getting Defined
//			viz. height, width And isSquure Immutable Properties
//			For Each Property Kotlin Compiler Will Generate 1 Member Variable
//			For Each Property Kotlin Compiler Will Generate Getter/Setter Methods
//			NOTE :: 
// 				height And width Property Getter Will Be Generated
//				isSquare Property Custom Getter Will Be Used
//					If Programmer Provides Getter/Setter Than Compiler Will Not Generate

class Rectangle( val height: Int, val width: Int ) {
	// error: property must be initialized or be abstract.
	// val isSquare : Boolean = true // Default Value
	//		For Above Line Of Code
	//		Compiler Will Generate Getter For val Property With Initial Value

	// isSquare Property With Custom Getter
	val isSquare : Boolean
	 	get() { // Custom Getter Will Be Used
	 		println("Property isSquare: Getter Called...")
	 		return width == height
	 	}
}

//	  Primary Constructor
class RectangleAgain( val height: Int, val width: Int ) {
	// error: property must be initialized or be abstract.
	// val isSquare : Boolean = true // Default Value
	//		For Above Line Of Code
	//		Compiler Will Generate Getter For val Property With Initial Value

	// isSquare Property With Custom Getter
	val isSquare : Boolean
	 	get() { // Custom Getter Will Be Used
	 		println("Property isSquare: Getter Called...")
	 		return width == height
	 	}

		// error: a 'val' property cannot have a setter.
	 	// set(newValue) { // Custom Getter Will Be Used
	 	// 		println("Property isSquare: Setter Called...")
	 	// 		field = newValue
	 	// }
}

class RectangleOnceAgain {
	// error: property must be initialized or be abstract.
	// val isSquare : Boolean = true // Default Value
	//		For Above Line Of Code
	//		Compiler Will Generate Getter For val Property With Initial Value
	val height: Int
	val width: Int
	// isSquare Property With Custom Getter
	val isSquare : Boolean
		// Custom Getter Provided By Programmer Hence Compiler Will Not Generate
	 	get() { 
	 		println("Property isSquare: Getter Called...")
	 		return width == height
	 	}

		// error: a 'val' property cannot have a setter.
	 	// set(newValue) { // Custom Getter Will Be Used
	 	// 		println("Property isSquare: Setter Called...")
	 	// 		field = newValue
	 	// }

	// Custom Constructor
	// 		Customized Constructor Provided By The Programmer
	//		Hence Compiler Will Not Generate This One
	constructor( height: Int, width: Int ) {
	 	println("RectangleOnceAgain Constructor Called...")		 	
	 	this.height = height
	 	this.width  = width
	}
}

// Rectangle, RectangleAgain and RectangleOnceAgain Are Equivalent

fun playWithRectangleClassProperties() {
	val rectangle1 = Rectangle( height = 100, width = 200 )
	println( rectangle1.width )
	println( rectangle1.height )
	println( rectangle1.isSquare )	

	val rectangle2 = Rectangle( height = 50, width = 50 )
	println( rectangle2.width )
	println( rectangle2.height )
	println( rectangle2.isSquare )

	val rectangle3 = RectangleAgain( height = 50, width = 50 )
	println( rectangle3.width )
	println( rectangle3.height )
	println( rectangle3.isSquare )

	val rectangle4 = RectangleAgain( height = 50, width = 50 )
	println( rectangle4.width )
	println( rectangle4.height )
	println( rectangle4.isSquare )
}

//____________________________________________________________________

// import java.util.Random

fun playWithRandomRectangle() {
	// Calling Java Code From Kotlin
	//		Using Random Java Class From java.util Package Inside Kotlin

	val random = Random() // error: unresolved reference 'Random'

	val rectangle1 = Rectangle( height = random.nextInt(), width = random.nextInt() )
	println( rectangle1.width )
	println( rectangle1.height )
	println( rectangle1.isSquare )	

	val rectangle2 = Rectangle( height = random.nextInt(), width = random.nextInt() )
	println( rectangle2.width )
	println( rectangle2.height )
	println( rectangle2.isSquare )
}

//____________________________________________________________________

enum class Colour {
	RED, GREEN, BLUE ;

	fun colourMethod() {
		println("Colour Enum Class Method Called... " )
	}
}

fun playWithEnumClasses() {
	val co : Colour = Colour.RED

	println("Colour: $co")
	println( Colour.RED )
	println( Colour.GREEN )
	println( Colour.BLUE )	

	co.colourMethod()
}

//____________________________________________________________________

//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

// Pattern Matching
fun fizzBuzz(i: Int) = when {
    i % 15 == 0 -> "FizzBuzz "
    i % 3 == 0 -> "Fizz "
    i % 5 == 0 -> "Buzz "
    else -> "$i "
}

fun playWithFizzBuzz() {
    for (i in 1..100) { // [1, 100] Closed Interval
        print(fizzBuzz(i))
    }

    for (i in 100 downTo 1 step 2) {
        print(fizzBuzz(i))
    }
}

//_____________________________________________________

// import java.util.TreeMap


fun iteratingOverMaps() {
	// Using Java TreeMap From java.util Package
	val binaryRepresenation = TreeMap<Char, String>()

	for ( character in 'A'..'F' ) {
		val binary = Integer.toBinaryString( character.code )
		binaryRepresenation[ character ] = binary
	}

	for ( (letter, binary) in binaryRepresenation ) {
		println("$letter = $binary")
	}
}


//_____________________________________________________

fun isLetter(c: Char) = c in 'a'..'z' || c in 'A'..'Z'
fun isNotDigit(c: Char) = c !in '0'..'9'

fun usingInCheck() {
    println(isLetter('q'))
    println(isNotDigit('x'))
}

fun recognize(c: Char) = when (c) {
    in '0'..'9' -> "It's a digit!"
    in 'a'..'z', in 'A'..'Z' -> "It's a letter!"
    else -> "I don't know..."
}

fun usingInCheckWithWhen() {
    println(recognize('8'))
}


//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________


fun main() {
	println("\nFunction: playWithClassPropertiesMutability")
	playWithClassPropertiesMutability()

	println("\nFunction: playWithHumanObject")
	playWithHumanObject()

	println("\nFunction: playWithRectangleClassProperties")
	playWithRectangleClassProperties()

	println("\nFunction: playWithRandomRectangle")
	playWithRandomRectangle()

	println("\nFunction: playWithEnumClasses")
	playWithEnumClasses()

	println("\nFunction: playWithFizzBuzz")
	playWithFizzBuzz()

	println("\nFunction: iteratingOverMaps")
	iteratingOverMaps()

	println("\nFunction: usingInCheckWithWhen")
	usingInCheckWithWhen()

	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
}

//____________________________________________________________________
//____________________________________________________________________

