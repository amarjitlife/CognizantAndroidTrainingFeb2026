
   
//____________________________________________________________________

// Choudhary, Suresh Sujaram (Cognizant)    
fun playWithExperiemntQuery01() {
    var list2 : MutableList<Int> = mutableListOf(1,2,4,5,6) // MutableList<Int>
    list2.add(5)
    println("list2 of int : ${list2}")
    println( list2 )
 
    // Inferred Type Of RHS Is MutableList<String>
    //      But LHS Type Is MutableList<Int>
    //      Hence Type Mismatch Will Happen
    list2 = mutableListOf("hello","jone","jack") // MutableList<String>
    // error: assignment type mismatch: 
    //      actual type is 'MutableList<String>', 
    //      but 'MutableList<Int>' was expected

    println( list2 )

    // Inferred Type Of RHS Is // MutableList<String>
    var list3 : MutableList<String> = mutableListOf("hello","jone","jack") // MutableList<String>
}

//____________________________________________________________________

// Kotlin has the following collections for grouping items:

// Collection Type   Description
// -----------------------------------------------------------------------
// Lists             Ordered collections of items
// Sets              Unique unordered collections of items
// Maps              Sets of key-value pairs where keys are unique and map to only one value

// Each collection type can be mutable or read only.

//____________________________________________________________________

________________________________________________________________________________________

ADD YOUR QUESTIONS AND QUERIES HERE
________________________________________________________________________________________

1. Sri Ram Kumar
Date: 05 March, 2026
    
    Q 01.1: Is there any memory overflow in Kotlin?    
    Q 01.2: In class variables are declared. 
    We want to access member variables?
            class Person {
                val age: Int
                println( age ) // You can call function like this in Class
            }
    Q 01.3: Pointer Substraction
            It Can Be Used To Find The Number Of Elements In Array. Please Explain...

    Q 01.4: Explain Default Constructor/Memberwise Initialiser In Kotlin
            What Compiler Will Generate?

2. Anurag Das 
Date: 05 March, 2026
    Q 02.1 : mutableMapOf, mutableListOf Function And Using val To Make Immutable
        It looks like contradictory 
        val list : MutableList<String> = mutableListOf("hello","jone","jack")

3. Debasish Sahoo
Date: 05 March, 2026
    Q 03.1: Using Lambda In Filter Function
                   When To Declare Data Type In Lambda?

    Q 03.2: What Happens With Empty String, Empty List, 0, 0.0 etc…
Can We Check bool( Expression ) Like in Python
            Zero Of Type
    Q 03.3: What is trailing Lambda and 
What is the difference between Normal Lambda and trailing Lambda.

4. Suresh Sujaram
Date: 05 March, 2026
    Q 04.1: Do we have the String Pool concept in Kotlin Similar To In Java?
    Q 04.2: In Kotlin All Types Are Object Type
            In Java Primitive Types Are Stored In Stack and 
Non-Primitive Are Stored In Heap
            How Are These Things In Kotlin?

5. Asish Baral
Date: 05 March, 2026
  Q 05.1: In Java Class Create Member Variables/Constants
        When You Print Object It Prints Object Reference
            Implement toString() Function 
To Print Member Variables/Constants Values

        In Kotlin How It Is?
Q 05.2 : It is easy to take user input( like integer , string ) in java , 
How can we do this using kotlin?

6. Bishal Rawani
Date: 05 March, 2026
    Q 06.1: How Memory Management Happens In Kotlin?
 
7. Sumit Ganesh Dhage
Date: 05 March, 2026
    Q 07.1: How to Create Threads In Kotlin?

8. Aaron Jain
Date: 05 March, 2026
    Q 08.1: What are the advantages of using Kotlin over other 
programming languages for android development
Why do we prefer Kotlin?

9. Atharva Hamdapure
Date: 05 March, 2026
Q 09.1: If kotlin already has null safety, why does it allow nullable types?

10. Priyanshu tripathi
Date: 05 March, 2026
Q 10.1:Is there a singleton class in kotlin?

11. Naman Raj Purohit
Date: 05 March, 2026
Q 11.1:in c++ we have a destructor that is called when an object 
is no longer needed. 
Does kotlin have something similar?

12. Sameer Gonde
Date: 05 March, 2026
Q 12.1:Does Kotlin Have Any Abstract Class Concept?

13. Ranjit Raj Nahak
Date: 05 March, 2026
Q 13.1: Can a Map having key value pairs(Any, Null) be created?
    Why cannot we add a new pair(String key, Null value) to a Map of (String, Int)?

14. Abhimanyu Giri
Date: 05 March, 2026
    Q 1 : What Kotlin features help reduce android crashes?
    Q 14.2 : High Order functions in kotlin?

15. S Vishnu Teja
Date: 05 March, 2026
Q 15.1: In C we have extension functions concept 
Can Kotlin support the same concept

16. Vidyasagar
Date: 05 March, 2026
Q 16.1: How are data classes useful in kotlin And 
  when we have to use data classes?
         How does kotlin implement OOP differently compared to java?

17. Manjusha Shinde
Date: 05 March, 2026
Q 17.1: What is null safety in kotlin that java does not have?

18. Rozina
Date: 05 March, 2026
Q 18.1: In kotlin how does the compiler internally handle null safety 
and smart casting?

19. Sumit Kumar Dubey 
Date: 05 March, 2026
Q 19.1:Does kotlin support call by reference?
If not then why does java and kotlin not support it?

20. NAME: 
Date: 05 March, 2026


21. NAME:
Date: 05 March, 2026


22. NAME:
Date: 05 March, 2026

//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________

fun main() {
    println("\nFunction: playWithExperiemntQuery01")
    playWithExperiemntQuery01()

    // println("\nFunction: ")
    // println("\nFunction: ")
    // println("\nFunction: ")
    // println("\nFunction: ")
    // println("\nFunction: ")
    // println("\nFunction: ")
    // println("\nFunction: ")
}

//____________________________________________________________________
//____________________________________________________________________

