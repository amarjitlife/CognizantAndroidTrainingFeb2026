/*
1. Compiling Kotlin Code
	kotlinc 01KotlinFundamentals.kt -include-runtime -d fundamentals.ja

2. Running Compiled Code
	java -jar fundamentals.jar
*/

//____________________________________________________________________

// Created Function
//		It Takes No Arguments
//		And Returns Default Unit Value Of Unit Type 
fun helloWorld() {
	println("Hello World!!!")
}

//____________________________________________________________________

fun playWithConstantsAndVariables() {
	// Immutable State
	// Using val Creating Constants
	val price = 50.99
	val customers = 20
	val greeting = "Good Evening!!!"

	println( price )
	println( customers )
	println( greeting )

	// price = 99.99 // error: 'val' cannot be reassigned.
	// println( price )

	// Mutable State
	// Using var Creating Variables
	var priceAgain = 50.99
	var customersAgain = 20
	var greetingAgain = "Good Evening!!!"

	println( priceAgain )
	println( customersAgain )
	println( greetingAgain )

	priceAgain = 99.99
	println( priceAgain )	
}


//____________________________________________________________________


fun playWithStringInterpolation() {
	// Using val Creating Constants
	val price = 50.99
	val customers = 20
	val greeting = "Good Evening!!!"

	// String Interpolation
	//		Values Of Identifiers Can Be Substituted In String
	//		Using $ Symbol
	println( "Price 	: $price" )
	println( "Customer 	: $customers" )
	println( "Greeting 	: $greeting" )

	println( "Increased Price : ${ price + 11.10 }" )
}

//____________________________________________________________________

fun playWithMathematicalAssignmentOperator() {
	var customers = 10

	// Some customers leave the queue
	customers = 8

	customers = customers + 3 // Example of addition: 11
	customers += 7            // Example of addition: 18
	customers -= 3            // Example of subtraction: 15
	customers *= 2            // Example of multiplication: 30
	customers /= 3            // Example of division: 10

	println(customers) // 10
}


//____________________________________________________________________

// BEST PRACTICE
//		Variables/Constant/Objects Must Be Initialised To Valid Values

fun playWithInitialisation() {
	// val d
	// var something
	// error: this variable must either have an explicit type or be initialized.

	// Type Annotation
	// Explicitly Annotating Type Of Identifiers
	val d : Int 
	var something: String

	val d1 = 90
	var something1 = "Good Evening!"

	// println( d ) 		 // error: variable 'd' must be initialized.
	// println( something ) // error: variable 'something' must be initialized.

	d = 99
	something = "Good Good!"
	println( d )
	println( something )		

	println( d1 )
	println( something1 )		
}

//____________________________________________________________________

fun playWithTypeInferrencingAndBinding() {
	// 1. Type Is Inferred From RHS Is Int
	// 2. Inferred Type Is Binded To LHS Is Int
	val something = 99 // 99 Default Type Is Int
	println( something )

	val somethingAgain: Int = 99 // 99 Default Type Is Int
	println( somethingAgain )

	// 1. Type Is Inferred From RHS Is String
	// 2. Inferred Type Is Binded To LHS Is String
	val greeting = "Good Afternoon!"
	println( greeting )

	val greetingAgain : String = "Good Afternoon!"
	println( greetingAgain )

	val marks = 90.99 // 90.99 Default Type Is Double
	println( marks )

	val marksAgain: Double = 90.99 // 90.99 Default Type Is Double
	println( marksAgain )

	// val marks1 : Float = 90.99 // 90.99 Default Type Is Double
	// error: initializer type mismatch: expected 'Float', actual 'Double'.
	val marks1 : Float = 90.99F // 90.99F Type Is Float
	println( marks1 )
}

//____________________________________________________________________

fun playWithListCollections() {
	// Creates Immutable List
	val shapes1 = listOf("Triangle", "Square", "Circle" )
	// val shapes1 : ???? = listOf("Triangle", "Square", "Circle" )
	println( shapes1 )

	val shapes2 : List<String> = listOf("Triangle", "Square", "Circle" )
	println( shapes2 )
	// shapes2.add( "Hexagon" ) // error: unresolved reference 'add'.
	// println( shapes2 )

	// var Creates Immutable ???
	val shapes3 : MutableList<String> = mutableListOf("Triangle", "Square", "Circle" )
	println( shapes3 )
	shapes3.add( "Hexagon" )
	shapes3.add( "Pentagon" )
	println( shapes3 )

	shapes3.remove( "Circle" )
	println( shapes3 )

	println( "Circle" in shapes1 )
	println( "Circle" in shapes3 )

	println( shapes1.count() )
	println( shapes2.count() )
	println( shapes3.count() )

	// To prevent unwanted modifications, 
	//		you can create a read-only view of a mutable list by assigning it to a List:

	val shapes: MutableList<String> = mutableListOf("triangle", "square", "circle")
	val shapesLocked: List<String>  = shapes
	// Here MutableList<String> Can Be Assigned To List<String>
	//		Type Casting Will Applied Hence Result Will Be List<String>
	// This is also called casting.

	println( shapes )
	shapes.add( "Hexagon" )
	println( shapes )

	println( shapesLocked )
	// shapesLocked Is Of Type List<String> Hence Immutable
	// shapesLocked.add("Some Figure") // error: unresolved reference 'add'.

	// Here MutableList<String> Can Be Assigned To List<String>
	//		Type Casting Will Applied Hence Result Will Be List<String>
	// This is also called casting.

	// Lists are ordered so to access an item in a list, 
	//		use the indexed access operator []

	val readOnlyShapes = listOf("triangle", "square", "circle")
	println("The 1st item in the list is: ${readOnlyShapes[0]}")
	println("The 2nd item in the list is: ${readOnlyShapes[1]}")

	println( readOnlyShapes.first() )
	println( readOnlyShapes.last() )

	val someImmutableList : List<String> = listOf("One", "Two", "Three")
	println( someImmutableList )
	// someImmutableList.add("Ten") // error: unresolved reference 'add'

	// var someMutableList : MutableList<String> = someImmutableList
	//  	error: initializer type mismatch: expected 'MutableList<String>', actual 'List<String>'.
	// println( someMutableList )
	// someMutableList.add("Ten")
	// println( someMutableList )
}

// NOTE :: IN KOTLIN
// 		Mutable Types Can Be Type Casted To Immutable Types
//		But Immutable Types Can't Be Type Casted To Mutable Types
//		e.g. MutableList<String> Can Be Type Casted To List<String> But Not Vice-Versa
//		e.g. MutableSet<String> Can Be Type Casted To Set<String> But Not Vice-Versa

//____________________________________________________________________

fun playWithSetCollections() {
	// Read-only set
	val readOnlyFruit = setOf("apple", "banana", "apple", "cherry", "cherry")
	println(readOnlyFruit)
	// [apple, banana, cherry]
	
	// Mutable set with explicit type declaration
	val fruit: MutableSet<String> = mutableSetOf("apple", "banana", "apple", "cherry", "cherry")
	println( fruit )

	println("This set has ${fruit.count()} items")
	// This set has 3 items

	fruit.add("dragonfruit")    // Add "dragonfruit" to the set
	println(fruit)              // [apple, banana, cherry, dragonfruit]
	println("This set has ${ fruit.count() } items")

	fruit.remove("dragonfruit") // Remove "dragonfruit" from the set
	println(fruit) 
	println("This set has ${ fruit.count() } items")

	// To prevent unwanted modifications, 
	//		you can create a read-only view of a MutableSet by assigning it to a Set:
	//		you can create a read-only view of a MutableList by assigning it to a List:
	//			Because Set, List Is Immutable Hence You Can't Add Elements
	val fruitAgain: MutableSet<String> = mutableSetOf("apple", "banana", "cherry", "cherry")
	println( fruitAgain )
	fruitAgain.add("Blueberry")
	println( fruitAgain )

	// Following Code Will Type Cast MutableSet<String> To Set<String>
	//		Set<String> Is Immutable Hence You Can't Add Elements
	val fruitLocked: Set<String> = fruitAgain
	// fruitLocked.add("Blackberry") //  error: unresolved reference 'add'.
	println( fruitLocked )

	// As sets are unordered, you can't access an item at a particular index.
	println("Count: ${ fruitAgain.count() }")

	// To get the number of items in a set, use the .count() function:
	val readOnlyFruitAgain = setOf("apple", "banana", "cherry", "cherry")
	println("This set has ${ readOnlyFruitAgain.count() } items")

	println( readOnlyFruitAgain.first() )
	println( readOnlyFruitAgain.last() )
}


//____________________________________________________________________
//
// Kotlin has the following collections for grouping items:

// Collection Type   Description
// -----------------------------------------------------------------------
// Lists             Ordered collections of items
// Sets              Unique unordered collections of items
// Maps              Sets of key-value pairs where keys are unique and map to only one value

// Each collection type can be mutable or read only.

// List
// Lists store items in the order that they are added, and allow for duplicate items.
// 		To create a read-only list (List), use the listOf() function.
//	To create a mutable list (MutableList), use the mutableListOf() function.

// When creating lists, Kotlin can infer the type of items stored. 
//		To declare the type explicitly, add the type within angled brackets <> 
//		after the list declaration:

// To prevent unwanted modifications, 
//		you can create a read-only view of a mutable list by assigning it to a List:

val shapes: MutableList<String> = mutableListOf("triangle", "square", "circle")
val shapesLocked: List<String>  = shapes

// Here MutableList<String> Can Be Assigned To List<String>
//		Type Casting Will Applied Hence Result Will Be List<String>

// This is also called casting.

// Lists are ordered so to access an item in a list, use the indexed access operator []
// As sets are unordered, you can't access an item at a particular index.

//____________________________________________________________________

// Map
// 		Maps store items as key-value pairs. 
//		You access the value by referencing the key. 
//			You can imagine a map like a food menu. 
//				You can find the price (value), by finding the food (key) you want to eat.

//		Maps are useful if you want to look up a value 
//			without using a numbered index, like in a list.

// Every key in a map must be unique so that Kotlin can understand which value you want to get.
// 		You can have duplicate values in a map.
// 		To create a read-only/Immutable map (Map), use the mapOf() function.
// 		To create a Mutable map (MutableMap), use the mutableMapOf() function.


// When creating maps, Kotlin can infer the type of items stored. 
//		To declare the type explicitly, 
//		Add the types of the keys and values within angled brackets <> after the map declaration. 
//		For example: MutableMap<String, Int>. The keys have type String and the values have type Int.

//____________________________________________________________________

fun playWithMapCollection() {
	// Read-only map
	val readOnlyJuiceMenu = mapOf("apple" to 100, "kiwi" to 190, "orange" to 100)
	println( readOnlyJuiceMenu ) // {apple=100, kiwi=190, orange=100}

	println( readOnlyJuiceMenu["apple"] )
	println( readOnlyJuiceMenu["orange"] )

	// Mutable map with explicit type declaration
	// 		MutableMap<String, Int> Here String Is Key Type and Int Is Value Type 
	val juiceMenu: MutableMap<String, Int> = mutableMapOf("apple" to 100, "kiwi" to 190, "orange" to 100)
	println( juiceMenu ) // {apple=100, kiwi=190, orange=100}

	// To access a value in a map, use the indexed access operator [] with its key:
	println( juiceMenu["apple"] )
	println( juiceMenu["kiwi"] )

	// If you try to access a key-value pair with a key that doesn't exist 
	//		in a map, you see a null value:
	println( juiceMenu["blackberry"] )

	// To prevent unwanted modifications, you can create a read-only view of 
	//		a mutable map by assigning it to a Map:
	val juiceMenuAgain: MutableMap<String, Int> = mutableMapOf("apple" to 100, "kiwi" to 190, "orange" to 100)
	val juiceMenuLocked: Map<String, Int> = juiceMenuAgain
	println( juiceMenuAgain )

	// You can also use the indexed access operator [] to add items to a mutable map:
	juiceMenuAgain["blueberry"] = 999
	println( juiceMenuAgain )

	println( juiceMenuLocked )
	// juiceMenuLocked["blueberry"] = 888 
	// println( juiceMenuLocked )

	// To remove items from a mutable map, use the .remove() function:
	juiceMenu.remove("orange")    // Remove key "orange" from the map
	println(juiceMenu)

	// juiceMenu["Unknown"] = null
	// 		error: null cannot be a value of a non-null type 'Int'.
	println( "Count :  ${ juiceMenu.count() }" )

	// To check if a specific key is already included in a map, use the .containsKey() function:
	println( juiceMenu.containsKey("kiwi") )
	println( juiceMenu.containsKey("blueberry") )
	println( juiceMenu.containsKey("blackberry") )

	println(juiceMenu.keys)
	println(juiceMenu.values)

	println("kiwi" in juiceMenu.keys)
	println(100 in juiceMenu.values)

	println("blueberry" in juiceMenu.keys)
	println( 999 in juiceMenu.values)
}

//____________________________________________________________________

fun playWithIfElse() {
	val d: Int
	val check = true

	if (check) {
		d = 1
	} else {
		d = 2
	}

	println( d )
	println( check )
}

//____________________________________________________________________

fun playWithWhenExpression() {
	val message = "Hello"

	when ( message ) {
		// Checks whether obj equals to "1"
		"1" 	-> println("One")
		// Checks whether obj equals to "Hello"
		
		"Hello" -> println("Greeting")
		// Default statement
		
		else 	-> println("Unknown")     
	}

	// val message1 = "Something"
	val message1 = "Hello"

	val result = when ( message1 ) {
		// Checks whether obj equals to "1"
		"1" 	-> 	"One"
		// Checks whether obj equals to "Hello"	    
		"Hello" ->  "Greeting"
		// Default statement
		else 	->  "Unknown"
	}

	println("Result : $result" )
}

// Note that all branch conditions are checked sequentially until 
//		one of them is satisfied. 
//		So only the first suitable branch is executed.
//		when Branches Have Implicit break
//		An expression returns a value that can be used later in your code.

//____________________________________________________________________

fun playWithWhenExpressionBooleanMatching() {
	val trafficLightState = "Red" // This can be "Green", "Yellow", or "Red"

	val trafficAction = when {
		// Pattern Matching Can Be Used For Boolean Expression
		trafficLightState == "Green" 	-> "Go"
		trafficLightState == "Yellow" 	-> "Slow down"
		trafficLightState == "Red" 		-> "Stop"
		else 							-> "Malfunction"
	}

	println(trafficAction)

	//--------------------------------------
	val trafficLightState1 = "Red" // This can be "Green", "Yellow", or "Red"

	val trafficAction1 = when ( trafficLightState1 ) {
		"Green" 	-> "Go"
		"Yellow" 	-> "Slow down"
		"Red" 		-> "Stop"
		else 		-> "Malfunction"
	}

	println(trafficAction1)  
	// Stop
}

//____________________________________________________________________

fun playWithWhenExpressionReturnValue() {
	val num = 2;
	 
	// val operation = "add"
	val operation = "sub"
	 
	val result = when(operation){
	 
		"add" -> {
			num + 2
			num + 3
			num + 4 // Last Expression Evaluated Will Become Value Of Block { }
		}
	 
		"sub" -> {
			num - 2
			num - 1
			num - 3 // Last Expression Evaluated Will Become Value Of Block { }
		}
	
		else -> println("Unknown Values...") 
	}

	println( "Result : $result " )
}


//____________________________________________________________________

fun playWithForLoop() {

	// For Used For Iterating Over Range
	// 1..5 Means Inclusive Range Operator Will Gives Values 1, 2, 3, 4, 5
	for (number in 1..5) { 
		// number is the iterator and 1..5 is the range
		print(number)
	}
	// 12345


	val cakes = listOf("carrot", "cheese", "chocolate")

	// For Used For Iterating Over Collection
	for (cake in cakes) {
		println("Yummy, it's a $cake cake!")
	}
}

//____________________________________________________________________

fun playWithWhileLoop() {
	var cakesEaten = 0
	var cakesBaked = 0

	println( cakesEaten )
	println( cakesBaked )

	while (cakesEaten < 3) {
		println("Eat a cake")
		cakesEaten++
	}


	do {
		println("Bake a cake")
		cakesBaked++
	} while (cakesBaked < cakesEaten)

	println( cakesEaten )
	println( cakesBaked )
}

//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________


fun main() {
	println("\nFunction: helloWorld")
	helloWorld()

	println("\nFunction: playWithConstantsAndVariables")
	playWithConstantsAndVariables()

	println("\nFunction: playWithStringInterpolation")
	playWithStringInterpolation()

	println("\nFunction: playWithMathematicalAssignmentOperator")
	playWithMathematicalAssignmentOperator()

	println("\nFunction: helloWorldAferMain")
	helloWorldAferMain()

	println("\nFunction: playWithInitialisation")
	playWithInitialisation()

	println("\nFunction: playWithTypeInferrencingAndBinding")
	playWithTypeInferrencingAndBinding()

	println("\nFunction: playWithListCollections")
	playWithListCollections()

	println("\nFunction: playWithSetCollections")
	playWithSetCollections()
	
	println("\nFunction: playWithMapCollection")
	playWithMapCollection()

	println("\nFunction: playWithIfElse")
	playWithIfElse()
	
	println("\nFunction: playWithWhenExpression")
	playWithWhenExpression()

	println("\nFunction: playWithWhenExpressionBooleanMatching")
	playWithWhenExpressionBooleanMatching()

	println("\nFunction: playWithForLoop")
	playWithForLoop()

	println("\nFunction: playWithWhileLoop")
	playWithWhileLoop()

	println("\nFunction: playWithWhenExpressionReturnValue")
	playWithWhenExpressionReturnValue()

	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
}

//____________________________________________________________________

// Function Definition
fun helloWorldAferMain(){
	println("Hello World After Main!!")
}
 
//____________________________________________________________________

