
/*
1. Compiling Kotlin Code
	kotlinc 03KotlinFundamentalsOnceMore.kt -include-runtime -d fundamentals.jar

2. Running Compiled Code
	java -jar fundamentals.jar
*/

//____________________________________________________________________

package learnKotlin

//____________________________________________________________________

class Person( val name: String, var isMarried: Boolean )

fun playWithClassPropertiesMutability() {
	// Here gabbar Is Reference/Address/Pointer To Object Of Person1 Type
	// Here val Makes gabbar Reference/Pointer Immutable
	// NOTE:: Reference/Address/Pointer Immutable Doesn't Mean Object Also Become Immutable
	val gabbar = Person( "Gabbar Singh", false )
	// gabbar = Person( "Gabbar Singh", false ) //  error: 'val' cannot be reassigned.
	println( gabbar )
	
	println( gabbar.name )
	println( gabbar.isMarried )

	// Person1 Type Object Property Getting Modified
	//		Hence Person1 Object Is Mutable
	// gabbar.name 		= "Gabbar" // error: 'val' cannot be reassigned.
	gabbar.isMarried 	= true

	println( gabbar.name )
	println( gabbar.isMarried )
}

//____________________________________________________________________

class Human( var name: String, var age: Int )

fun doChange( hu : Human ) {
	hu.name = "Gabbar Singh"
	hu.age 	= 99
}

fun playWithHumanObject() {
	val h = Human( name = "Gabbar", age = 33 )

	println( h.name )
	println( h.age )

	doChange( h )

	println( h.name )
	println( h.age )
}

// In Java/Kotlin/Python
//		All Objects Pass By Reference
//		Hence Objects Mutable Properties Can Be Modified
//		Those Modification Will Reflect Back

// Function: playWithHumanObject
// Gabbar
// 33
// Gabbar Singh
// 99


//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________

fun main() {
	println("\nFunction: playWithClassPropertiesMutability")
	playWithClassPropertiesMutability()

	println("\nFunction: playWithHumanObject")
	playWithHumanObject()

	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
}

//____________________________________________________________________
//____________________________________________________________________

