
--------------------------------------------------------------------------
JAVA ENVIRONMENT
--------------------------------------------------------------------------

	1. Run Following Command To Check Version Of Java Compiler Installed
			javac --version

	2. Run Following Command To Check Version Of Java JVM Installed
			java  --version


--------------------------------------------------------------------------
KOTLIN ENVIRONMENT
--------------------------------------------------------------------------


1. Download kotlin-compiler-2.3.10.zip File In Download Directory
2. Create Compilers Directory Inside Documents Directory
3. Copy kotlin-compiler-2.3.10.zip In USER_DIRECTORY/Documents/Compilers/
4. Unzip kotlin-compiler-2.3.10.zip File 
5. Add YOUR_PATH/kotlin-compiler-2.3.10/kotlinc/bin Path To PATH Environment Variable
6. Restart Command Prompt
7. Test Kotlin Compiler Running For Any Path
		kotlinc  -version


--------------------------------------------------------------------------
VS CODE EDITOR SETUP
--------------------------------------------------------------------------

1. Download VS Code Editor In Documents/Softwares/
2. Run VS Code Editor From Documents/Softwares/


--------------------------------------------------------------------------
KOTLIN CODING, COMPILATION AND RUNNING
--------------------------------------------------------------------------

	1. Create Hello.kt File With Following Code

			fun main() {
				val hello   = "Hello Kotlin!!!"
				val welcome = "Welcome To Visual Studio Code!!!"

				println( hello )
				println( welcome )
			}

	2. Save Hello.kt File In Following Directory

		YOUR_PATH/Documents/AndroidTraining/LearnKotlin/Hello.kt

	3. Open Command Prompt and Change Directory

		cd YOUR_PATH/Documents/AndroidTraining/LearnKotlin/

	4. Command To Compile Code

		kotlinc Hello.kt -include-runtime -d hello.jar

	5. Command To Run Code 

		java -jar hello.jar

--------------------------------------------------------------------------
--------------------------------------------------------------------------
--------------------------------------------------------------------------
--------------------------------------------------------------------------


