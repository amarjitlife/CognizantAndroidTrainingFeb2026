
#include <stdio.h>
#include <stdlib.h>

//____________________________________________________________________
//____________________________________________________________________

struct Customer {
	
};

	// In Java/C/C++
	//		All References and Object's Members Are Mutable By Default
	// 		In Java To Make References And/Or Object's Members Immutable Use final Keyword
	//		In C/C++ To Make References And/Or Object's Members Immutable Use const Keyword

	// In Kotlin
	//		Most of Things Are Immutable By Default
	//		Or You Can Make Mutable/Immutable References And/Or Object's Members 
	//			Using var And val Keywords

void playWithCustomerStructAndObject() {
	// In Java
	// Here co Is Not Customer Object
	//		Rather co Is Address/Reference/Pointer To Customer Object Allocated At Heap
	// 			 RHS Customer Object Allocated At Heap
	// LHS co Is Reference/Address/Pointer To Object Of Customer Type
	struct Customer co =  { };
	printf( "\nStruct Address Of co:  %p", &co );
}

//____________________________________________________________________

typedef struct person_type {
	int id; 				// Mutable Member Variable
	int age; 				// Mutable Member Variable
	// const char name[20];  	// Immutable Member Variable

} Person;

void playWithOnePersonObjectAndTwoReferences() {
	// In C/C++
	// Here po Is Object Type Person With id =101 and age = 33
	Person po = { 101, 33 };

	// In C/C++
	// Variable/Object Assignment Assignment
	//		Note Following Is Full Copy Of The Object Created
	Person poc = po;

	printf( "\nStruct Address Of po:   %p", &po );
	printf( "\nStruct Address Of poc:  %p", &poc );

	printf( "\n%d", po.id );
	printf( "\n%d", po.age );
	printf( "\n%d", poc.id );
	printf( "\n%d", poc.age );

	poc.age = 44;

	printf( "\n%d", po.id );
	printf( "\n%d", po.age );
	printf( "\n%d", poc.id );
	printf( "\n%d", poc.age );

	printf("\n\nSimulating Java/Kotlin Internals Understanding");

// In Java/Kotlin Things Happens As Follows Internally
	// Making Code Similar To Java/Kotlin	
	// Here rpo Is Reference/Pointer To Object Of Person Type With id =101, age = 33, name ="Uknown"
	Person * rpo = ( Person * ) malloc( sizeof( Person ) );
	rpo -> id 	= 101;
	rpo -> age 	= 33;
	// rpo -> name = "Unknown";

	// Similar To Java/Kotlin
	// 		Reference/Address/Pointer Assignment
	//		Note Following Is Not Copying Of The Object Created
	// Here rpoc Is Reference/Pointer To Object Of Person Type With id =101, age = 33, name ="Uknown"
	Person * rpoc = rpo;

	printf( "\nStruct Address Of po:   %p", rpo  );
	printf( "\nStruct Address Of poc:  %p", rpoc );

	printf( "\n%d",	rpo -> id );
	printf( "\n%d", rpo -> age );
	printf( "\n%d", rpoc -> id );
	printf( "\n%d", rpoc -> age );

	rpoc -> age = 44;

	printf( "\n%d",	rpo -> id );
	printf( "\n%d", rpo -> age );
	printf( "\n%d", rpoc -> id );
	printf( "\n%d", rpoc -> age );
}


/*
	public static void playWithTwoPersonObjectsAndOneReference() {
		// Here po Is Reference/Pointer To Object Of Person Type With id =101 and age = 33
		Person po = new Person( 101 , 33 ); // RHS 1st Person Object
		printf( po );
		printf( po.id );
		printf( po.age );

		// Here po Is Reference/Pointer To New Object Of Person Type With id =111 and age = 55
		po = new Person( 111 , 55 ); // RHS 2nd Person Object

		// Person po = new Person( 111 , 55 ); // RHS 2nd Person Object
 		//		error: variable po is already defined

		printf( po );
		printf( po.id );
		printf( po.age );

		// What Happened To 1st Person Object With id =101 and age = 33
		//		It Will Get Deallocated
	}

	public static void playWithTwoPersonObjectsAndTwoReferences() {
		// Here po Is Reference/Pointer To Object Of Person Type With id =101 and age = 33
		Person po = new Person( 101 , 33 ); // RHS 1st Person Object

		// Here pon Is Reference/Pointer To New Object Of Person Type With id =101 and age = 33
		Person pon = new Person( 101 , 33 ); // RHS 2nd Person Object

		// Following Lines Will Print Two Different Addreses/References/Pointers
		printf( po );
		printf( pon );

		printf( po.id );
		printf( po.age );

		printf( pon.id );
		printf( pon.age );
	}

	public static void playWithUnderstandingObjectAndReferences() {
		// Person person = new Person( );
		// In Java
		// Here po Is Not Person Object
		//		Rather po Address/Reference/Pointer To Person Object Allocated At Heap
						// Person Object Allocated At Heap
		// In Java Reference/Address/Pointer To Object Of Person Type Is Mutable By Default
		//		Similar To var po = Person( 101, 33 ) In Kotlin
		Person po = new Person( 101 , 33 );
		printf( po );	
		printf( po.id );
		printf( po.age );

		po.id 	= 999;
		po.age 	= 333;

		printf( po.id );
		printf( po.age );

		po = new Person( 111 , 333 );
		printf( po );	
		printf( po.id );
		printf( po.age );
		printf( po.name );
		
		// In Java
		// 		Here pon Is Reference/Address/Pointer To Object Of Person Type 
		//		And To Make It Immutable Use final Keyword
		// In Kotlin 
		//		It's Similar To val pon = Person( 101, 33 )
		final Person pon = new Person( 101 , 33 );
		printf( pon );	
		printf( pon.id );
		printf( pon.age );
		printf( pon.name );

		// pon Reference/Address/Pointer To Object Is Immutable
		// pon = new Person( 111 , 333 ); // error: cannot assign a value to final variable pon

		pon.id 		= 888;
		pon.age 	= 444;
		// pon.name 	= "Gabbar Singh"; // error: cannot assign a value to final variable name

		printf( pon );	
		printf( pon.id );
		printf( pon.age );
		printf( pon.name );
		
		// In Kotlin
		// val Makes Reference/Address/Pointer To Object Of Type Person Is Immutable
		// val po = Person( 101, 33 )

		// var Makes Reference/Address/Pointer To Object Of Type Person Is Mmutable
		// var po = Person( 101, 33 )
		
		// In C/C++
			Person * p = ( Person * ) malloc( sizeof( Person ) );
			
			// Intialisation Logic
			po -> name = "Gabbar Singh";
			po -> age  = 33;
	
		// In Java new Operator Calls malloc Internally
		//		It Returns Starting Address/Reference/Pointer Of Object Allocated At Heap Memory 

*/

int main() {
	printf("\n\nFunction : playWithCustomerStructAndObject");
	playWithCustomerStructAndObject();

	printf("\n\nFunction : playWithOnePersonObjectAndTwoReferences");
	playWithOnePersonObjectAndTwoReferences();

	// printf("\n\nFunction : playWithTwoPersonObjectsAndOneReference");
	// playWithTwoPersonObjectsAndOneReference();

	// printf("\n\nFunction : playWithTwoPersonObjectsAndTwoReferences");
	// playWithTwoPersonObjectsAndTwoReferences();

	// printf("\n\nFunction : playWithUnderstandingObjectAndReferences");
	// playWithUnderstandingObjectAndReferences();

	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	return 0;
}

